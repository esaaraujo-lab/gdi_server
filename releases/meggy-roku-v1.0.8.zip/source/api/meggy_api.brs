' ===============================================================
' Meggy API Client - Roku BrightScript (v1.0.8)
' Comunicacao com backend educa.eu.org
' * v1.0.8: cookie extraido do Set-Cookie (login persiste),
'   getUserState no path certo (/userstate), update check
'   via /api/apps/latest (sempre a ultima versao do GitHub)
' ===============================================================

function MeggyAPI() as Object
  if m._api = invalid
    m._api = {
      BASE_URL: "https://educa.eu.org"
      cookie: ""

      ' Single roUrlTransfer instance + EnableCookies: cookies do
      ' login sao enviados nas requisicoes seguintes (mesma sessao)
      _urlTransfer: invalid

      _getTransfer: function() as Object
        if m._urlTransfer = invalid
          m._urlTransfer = CreateObject("roUrlTransfer")
          m._urlTransfer.AddHeader("User-Agent", "MeggyRoku/1.0.8")
          m._urlTransfer.EnableCookies()
        end if
        return m._urlTransfer
      end function

      ' === AUTH ===
      login: function(username as String, password as String) as Boolean
        encodedUser = m._urlEncode(username)
        encodedPass = m._urlEncode(password)
        params = "username=" + encodedUser + "&password=" + encodedPass
        r = m._post("/login", params, "application/x-www-form-urlencoded")
        if r <> invalid and r.code = 200
          ' Guarda o cookie de sessao (primeiro par do Set-Cookie)
          if r.cookie <> ""
            m.cookie = r.cookie
          end if
          return true
        end if
        return false
      end function

      ' === COURSES ===
      getCourses: function() as Object
        r = m._get("/api/courses/list")
        if r <> invalid and r.code = 200
          json = ParseJSON(r.text)
          if json <> invalid and json.ok
            return json.courses
          end if
        end if
        return []
      end function

      getCourseLessons: function(coursePath as String) as Object
        body = FormatJson({coursePath: coursePath})
        r = m._post("/api/courses/scan-progress", body, "application/json")
        if r <> invalid and r.code = 200
          json = ParseJSON(r.text)
          if json <> invalid and json.ok
            return json.lessons
          end if
        end if
        return []
      end function

      ' === APP UPDATE (regra de ouro: sempre a ultima versao do GitHub) ===
      ' O worker resolve a ultima release roku-v* no GitHub e devolve
      ' versao + link de download. Publico, nao precisa de login.
      getLatestAppVersion: function() as Object
        r = m._get("/api/apps/latest?platform=roku")
        if r <> invalid and r.code = 200
          json = ParseJSON(r.text)
          if json <> invalid and json.ok and json.version <> invalid
            return {version: json.version, tag: json.tag, download_url: json.download_url}
          end if
        end if
        return invalid
      end function

      getInstalledVersion: function() as String
        info = CreateObject("roAppInfo")
        if info <> invalid
          return info.GetVersion()
        end if
        return "1.0.8"
      end function

      ' Compara "1.0.9" > "1.0.8" segmento a segmento (numerico)
      isNewerVersion: function(latest as String, current as String) as Boolean
        if latest = "" or current = "" then return false
        if latest = current then return false
        lParts = latest.Split(".")
        cParts = current.Split(".")
        maxN = lParts.Count()
        if cParts.Count() > maxN then maxN = cParts.Count()
        for i = 0 to maxN - 1
          l = 0
          c = 0
          if i < lParts.Count() then l = Val(lParts[i])
          if i < cParts.Count() then c = Val(cParts[i])
          if l > c then return true
          if l < c then return false
        end for
        return false
      end function

      ' === AI ===
      getCoachAnalysis: function() as Object
        r = m._post("/api/ai/coach", FormatJson({action: "analyze"}), "application/json")
        if r <> invalid and r.code = 200
          return ParseJSON(r.text)
        end if
        return invalid
      end function

      getAiStatus: function() as Object
        r = m._get("/api/ai/status")
        if r <> invalid and r.code = 200
          return ParseJSON(r.text)
        end if
        return {enabled: false}
      end function

      chat: function(message as String) as String
        body = FormatJson({message: message, messages: []})
        r = m._post("/api/ai", body, "application/json")
        if r <> invalid and r.code = 200
          json = ParseJSON(r.text)
          if json <> invalid and json.ok
            return json.response
          end if
        end if
        return "Desculpe, nao consegui responder agora."
      end function

      ' === D1 ===
      getD1Status: function() as Object
        r = m._get("/api/d1/status")
        if r <> invalid and r.code = 200
          return ParseJSON(r.text)
        end if
        return {ok: false}
      end function

      ' === USER STATE (retomar entre aparelhos: web, Android, TV) ===
      ' GET /userstate (path certo; /userstate/get nao existe no worker)
      getUserState: function() as Object
        r = m._get("/userstate")
        if r <> invalid and r.code = 200
          return ParseJSON(r.text)
        end if
        return {}
      end function

      saveUserState: function(data as Object) as Boolean
        body = FormatJson(data)
        r = m._post("/userstate/save", body, "application/json")
        if r <> invalid and r.code = 200
          return true
        end if
        return false
      end function

      ' === HTTP HELPERS ===
      _get: function(path as String) as Object
        url = m.BASE_URL + path
        r = m._getTransfer()
        r.SetUrl(url)
        r.AddHeader("User-Agent", "MeggyRoku/1.0.8")
        if m.cookie <> ""
          r.AddHeader("Cookie", m.cookie)
        end if
        port = CreateObject("roMessagePort")
        r.SetMessagePort(port)
        ok = r.AsyncGetToString()
        if not ok then return invalid
        msg = wait(30000, port)
        if msg <> invalid and type(msg) = "roUrlEvent"
          return {code: msg.GetResponseCode(), text: msg.GetString(), cookie: m._extractCookie(msg)}
        end if
        return invalid
      end function

      _post: function(path as String, body as String, contentType as String) as Object
        url = m.BASE_URL + path
        r = m._getTransfer()
        r.SetUrl(url)
        r.AddHeader("Content-Type", contentType)
        r.AddHeader("User-Agent", "MeggyRoku/1.0.8")
        if m.cookie <> ""
          r.AddHeader("Cookie", m.cookie)
        end if
        port = CreateObject("roMessagePort")
        r.SetMessagePort(port)
        ok = r.AsyncPostFromString(body)
        if not ok then return invalid
        msg = wait(30000, port)
        if msg <> invalid and type(msg) = "roUrlEvent"
          return {code: msg.GetResponseCode(), text: msg.GetString(), cookie: m._extractCookie(msg)}
        end if
        return invalid
      end function

      ' Le o Set-Cookie dos headers (case-insensitive) e devolve
      ' so o primeiro par "nome=valor" — o resto sao atributos.
      _extractCookie: function(msg as Object) as String
        headers = msg.GetResponseHeaders()
        if headers = invalid then return ""
        for each key in headers
          if LCase(key) = "set-cookie"
            raw = headers.Lookup(key)
            if raw = invalid or raw = "" then return ""
            parts = raw.Split(";")
            if parts.Count() > 0
              return parts[0].Trim()
            end if
            return raw
          end if
        end for
        return ""
      end function

      ' === URL ENCODER ===
      _urlEncode: function(s as String) as String
        if s = "" then return ""
        result = ""
        for i = 0 to Len(s) - 1
          c = Mid(s, i + 1, 1)
          if (c >= "A" and c <= "Z") or (c >= "a" and c <= "z") or (c >= "0" and c <= "9") or c = "-" or c = "_" or c = "." or c = "~"
            result = result + c
          else
            result = result + "%" + m._hex(Asc(c))
          end if
        end for
        return result
      end function

      _hex: function(n as Integer) as String
        hexChars = "0123456789ABCDEF"
        hi = Int(n / 16)
        lo = n mod 16
        return Mid(hexChars, hi + 1, 1) + Mid(hexChars, lo + 1, 1)
      end function
    }
  end if
  return m._api
end function
