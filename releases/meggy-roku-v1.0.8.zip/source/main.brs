' ===============================================================
' Meggy - Roku TV App
' Plataforma de estudos: videoaulas, resumos, questes
' Backend: educa.eu.org (Cloudflare Worker)
' ===============================================================

sub Main()
  ' Inicializa tela principal
  screen = CreateObject("roSGScreen")
  port = CreateObject("roMessagePort")
  screen.setMessagePort(port)

  ' Cria cena inicial (Login ou Home se ja logado)
  scene = screen.CreateScene("MainScene")
  screen.Show()

  ' Loop de eventos
  while true
    msg = wait(0, port)
    if type(msg) = "roSGScreenEvent"
      if msg.isScreenClosed() then return
    end if
  end while
end sub
