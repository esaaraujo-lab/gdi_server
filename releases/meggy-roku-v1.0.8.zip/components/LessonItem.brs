' LessonItem - item component for lessons RowList (v1.0.6)
sub init()
    m.itemIcon = m.top.findNode("itemIcon")
    m.itemTitle = m.top.findNode("itemTitle")
    m.top.observeField("content", "onContentChanged")
end sub

sub onContentChanged()
    if m.top.content = invalid then return
    if m.itemTitle <> invalid
        m.itemTitle.text = m.top.content.title
    end if
    if m.itemIcon <> invalid and m.top.content.hdPosterUrl <> invalid and m.top.content.hdPosterUrl <> ""
        m.itemIcon.uri = m.top.content.hdPosterUrl
    end if
end sub
