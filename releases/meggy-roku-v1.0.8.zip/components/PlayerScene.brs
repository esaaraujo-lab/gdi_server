' ===============================================================
' PlayerScene - Player de video com controles Roku (v1.0.8)
' * v1.0.8: cookie de volta no HttpAgent (videos precisam de
'   login); salva posicao a cada 10s; tempo decorrido/total;
'   HLS (.m3u8) suportado; sem apagar o resume no fim
' ===============================================================

sub init()
  m.videoPlayer = m.top.findNode("videoPlayer")
  m.lessonNameLabel = m.top.findNode("lessonNameLabel")
  m.timeLabel = m.top.findNode("timeLabel")
  m.overlayRect = m.top.findNode("overlayRect")
  m.controlsLabel = m.top.findNode("controlsLabel")

  m.top.observeField("lessonPath", "onLessonPathChanged")
  m.top.observeField("lessonName", "onLessonNameChanged")

  if m.videoPlayer <> invalid
    m.videoPlayer.observeField("state", "onVideoState")
    m.videoPlayer.observeField("position", "onVideoPosition")
  end if

  m.seekInterval = 10  ' 10 segundos por seek
  m.lastSavedPos = 0
  m.lastShownSecond = -1
end sub

sub onLessonNameChanged()
  if m.lessonNameLabel <> invalid and m.top.lessonName <> invalid
    m.lessonNameLabel.text = m.top.lessonName
  end if
end sub

sub onLessonPathChanged()
  if m.videoPlayer = invalid then return
  if m.top.api = invalid then return
  if m.top.lessonPath = invalid then return

  ' Constroi URL completa
  videoUrl = m.top.api.BASE_URL + m.top.lessonPath

  ' Configura content
  content = CreateObject("roSGNode", "ContentNode")
  content.url = videoUrl
  if m.top.lessonName <> invalid
    content.title = m.top.lessonName
  end if
  ' HLS para .m3u8, MP4 para o resto
  if Right(LCase(videoUrl), 5) = ".m3u8"
    content.streamformat = "hls"
  else
    content.streamformat = "mp4"
  end if

  ' O Video node precisa do cookie para acessar o Drive autenticado
  cookie = m.top.api.cookie
  if cookie <> ""
    port = CreateObject("roMessagePort")
    agent = CreateObject("roHttpAgent")
    agent.SetPort(port)
    agent.AddHeaders([{
      name: "Cookie"
      value: cookie
    }])
    m.videoPlayer.SetHttpAgent(agent)
  end if

  ' Configura Video node
  m.videoPlayer.content = content

  ' Tenta restaurar posicao salva (Registry local primeiro, depois servidor)
  savedPos = ReadRegistry("pos_" + m.top.lessonPath)
  if savedPos = "" and m.top.api <> invalid
    state = m.top.api.getUserState()
    if state <> invalid and state.resume <> invalid
      resumeMap = state.resume
      link = m.top.lessonPath
      if resumeMap.DoesExist(link)
        savedPos = resumeMap.Lookup(link).ToStr()
      end if
    end if
  end if
  if savedPos <> ""
    posFloat = Val(savedPos)
    if posFloat > 5
      m.videoPlayer.seek = Int(posFloat)
    end if
  end if

  ' Inicia reproducao
  m.videoPlayer.control = "play"
  m.videoPlayer.setFocus(true)
end sub

sub onVideoState()
  if m.videoPlayer = invalid then return
  state = m.videoPlayer.state
  if state = "playing"
    ' Mostra overlay
    if m.overlayRect <> invalid then m.overlayRect.visible = true
    if m.lessonNameLabel <> invalid then m.lessonNameLabel.visible = true
    if m.timeLabel <> invalid then m.timeLabel.visible = true
    if m.controlsLabel <> invalid then m.controlsLabel.visible = true
  else if state = "finished"
    ' Marca como assistida (o save faz merge — nao apaga resume/history)
    WriteRegistry("pos_" + m.top.lessonPath, "0")
    if m.top.api <> invalid
      link = m.top.lessonPath
      watched = CreateObject("roAssociativeArray")
      watched.AddReplace(link, true)
      m.top.api.saveUserState({watched: watched})
    end if
  else if state = "error"
    if m.lessonNameLabel <> invalid
      m.lessonNameLabel.text = "Erro ao reproduzir: " + m.top.lessonName
    end if
  end if
end sub

sub onVideoPosition()
  if m.videoPlayer = invalid then return
  curPos = m.videoPlayer.position
  posInt = Int(curPos)
  ' Mostra tempo decorrido / total (so quando o segundo muda)
  if posInt <> m.lastShownSecond
    m.lastShownSecond = posInt
    if m.timeLabel <> invalid
      dur = Int(m.videoPlayer.duration)
      if dur > 0
        m.timeLabel.text = fmtTime(posInt) + " / " + fmtTime(dur)
      else
        m.timeLabel.text = fmtTime(posInt)
      end if
    end if
  end if
  ' Salva posicao a cada 10 segundos (evita salvar a cada frame)
  if posInt - m.lastSavedPos >= 10
    WriteRegistry("pos_" + m.top.lessonPath, posInt.ToStr())
    m.lastSavedPos = posInt
  end if
end sub

function fmtTime(seconds as Integer) as String
  total = seconds
  h = Int(total / 3600)
  mins = Int((total mod 3600) / 60)
  s = total mod 60
  if h > 0
    return h.ToStr() + ":" + Right("0" + mins.ToStr(), 2) + ":" + Right("0" + s.ToStr(), 2)
  end if
  return mins.ToStr() + ":" + Right("0" + s.ToStr(), 2)
end function

function onKeyEvent(key as String, press as Boolean) as Boolean
  if not press then return false
  if m.videoPlayer = invalid then return false

  if key = "OK" or key = "play"
    if m.videoPlayer.state = "playing"
      m.videoPlayer.control = "pause"
    else if m.videoPlayer.state = "paused"
      m.videoPlayer.control = "resume"
    end if
    return true

  else if key = "rewind" or key = "left"
    newPos = Int(m.videoPlayer.position) - m.seekInterval
    if newPos < 0 then newPos = 0
    m.videoPlayer.seek = newPos
    return true

  else if key = "fastforward" or key = "right"
    newPos = Int(m.videoPlayer.position) + m.seekInterval
    m.videoPlayer.seek = newPos
    return true

  else if key = "back"
    ' Salva posicao antes de sair (local + servidor)
    posInt = Int(m.videoPlayer.position)
    WriteRegistry("pos_" + m.top.lessonPath, posInt.ToStr())
    if m.top.api <> invalid
      resumeMap = CreateObject("roAssociativeArray")
      resumeMap.AddReplace(m.top.lessonPath, posInt)
      m.top.api.saveUserState({resume: resumeMap})
      ' Tambem salva no historico (ultimas 4)
      state = m.top.api.getUserState()
      history = []
      if state <> invalid and state.history <> invalid
        history = state.history
      end if
      entry = CreateObject("roAssociativeArray")
      entry.AddReplace("name", m.top.lessonName)
      entry.AddReplace("path", m.top.lessonPath)
      entry.AddReplace("link", m.top.lessonPath)
      history.Push(entry)
      if history.Count() > 4
        ' Mantem as ultimas 4
        while history.Count() > 4
          history.Shift()
        end while
      end if
      m.top.api.saveUserState({history: history})
    end if
    m.videoPlayer.control = "stop"
    ' Volta para CourseDetailScene (MainScene cuida de remover)
    return false
  end if

  return false
end function

function ReadRegistry(key as String) as String
  sec = CreateObject("roRegistrySection", "meggy")
  if sec.Exists(key)
    return sec.Read(key)
  end if
  return ""
end function

sub WriteRegistry(key as String, value as String)
  sec = CreateObject("roRegistrySection", "meggy")
  sec.Write(key, value)
  sec.Flush()
end sub
