' ===============================================================
' MainScene - Cena principal do app Meggy Roku (v1.0.8)
' Gerencia: Login -> Home (Continuar assistindo, Minha Lista,
'   Seus Cursos, Conta) -> Detalhe -> Player
' * v1.0.8: sem auto-login de teste; cookie persiste de verdade;
'   selecao por linha+item (rowItemFocus [linha, item]);
'   Minha Lista (tecla *); Continuar assistindo (servidor);
'   aviso de nova versao (sempre a ultima do GitHub); Sair
' ===============================================================

sub init()
  m.loginBg = m.top.findNode("loginBg")
  m.loginTitle = m.top.findNode("loginTitle")
  m.loginSubtitle = m.top.findNode("loginSubtitle")
  m.userLabel = m.top.findNode("userLabel")
  m.usernameInput = m.top.findNode("usernameInput")
  m.passLabel = m.top.findNode("passLabel")
  m.passwordInput = m.top.findNode("passwordInput")
  m.loginButton = m.top.findNode("loginButton")
  m.loginError = m.top.findNode("loginError")
  m.versionLabel = m.top.findNode("versionLabel")

  m.homeBg = m.top.findNode("homeBg")
  m.homeHeader = m.top.findNode("homeHeader")
  m.homeTitle = m.top.findNode("homeTitle")
  m.homeSubtitle = m.top.findNode("homeSubtitle")
  m.updateLabel = m.top.findNode("updateLabel")
  m.coursesRowList = m.top.findNode("coursesRowList")
  m.hintLabel = m.top.findNode("hintLabel")
  m.statusLabel = m.top.findNode("statusLabel")

  m.api = MeggyAPI()
  m.cachedCourses = []
  m.resumeItems = []
  m.myList = ReadMyList()
  m.rowKinds = []
  m.updateAvailable = false

  ' Versao instalada no rodape do login
  if m.versionLabel <> invalid
    m.versionLabel.text = "Versao " + m.api.getInstalledVersion()
  end if

  ' Foco inicial no input de usuario
  if m.usernameInput <> invalid
    m.usernameInput.setFocus(true)
  end if

  ' Sessao salva? Entra direto; senao, mostra o login
  savedCookie = ReadRegistry("meggy_cookie")
  if savedCookie <> ""
    m.api.cookie = savedCookie
    showHome()
  else
    showLoginNodes(true)
  end if

  ' Setup do RowList de cursos
  if m.coursesRowList <> invalid
    m.coursesRowList.observeField("rowItemSelected", "onCourseSelected")
    m.coursesRowList.content = CreateObject("roSGNode", "ContentNode")
  end if
end sub

' === LOGIN ===
sub onLoginButton()
  if m.usernameInput = invalid or m.passwordInput = invalid then return

  username = m.usernameInput.text
  password = m.passwordInput.text

  if username = "" or password = ""
    showLoginError("Preencha usuario e senha")
    return
  end if

  if m.loginButton <> invalid then m.loginButton.text = "Entrando..."
  if m.loginError <> invalid then m.loginError.visible = false

  if m.api.login(username, password)
    ' Salva cookie de verdade para as proximas execucoes
    WriteRegistry("meggy_cookie", m.api.cookie)
    WriteRegistry("meggy_user", username)
    showHome()
  else
    showLoginError("Credenciais invalidas")
    if m.loginButton <> invalid then m.loginButton.text = "[ Entrar ]"
  end if
end sub

sub showLoginError(msg as String)
  if m.loginError <> invalid
    m.loginError.text = "[X] " + msg
    m.loginError.visible = true
  end if
  if m.loginButton <> invalid then m.loginButton.text = "[ Entrar ]"
end sub

sub showLoginNodes(visible as Boolean)
  nodes = [m.loginBg, m.loginTitle, m.loginSubtitle, m.userLabel, m.usernameInput, m.passLabel, m.passwordInput, m.loginButton, m.versionLabel]
  for each n in nodes
    if n <> invalid then n.visible = visible
  end for
  if m.loginError <> invalid then m.loginError.visible = false
  if visible and m.usernameInput <> invalid then m.usernameInput.setFocus(true)
end sub

sub showHomeNodes(visible as Boolean)
  nodes = [m.homeBg, m.homeHeader, m.homeTitle, m.homeSubtitle, m.coursesRowList, m.hintLabel, m.statusLabel]
  for each n in nodes
    if n <> invalid then n.visible = visible
  end for
  ' O aviso de update so aparece se houver versao nova
  if m.updateLabel <> invalid then m.updateLabel.visible = visible and m.updateAvailable
end sub

' === HOME ===
sub showHome()
  showLoginNodes(false)
  showHomeNodes(true)
  if m.coursesRowList <> invalid then m.coursesRowList.setFocus(true)

  if m.statusLabel <> invalid then m.statusLabel.text = "Carregando cursos..."

  ' Cursos do aluno
  courses = m.api.getCourses()
  if courses = invalid then courses = []
  m.cachedCourses = courses

  ' Continuar assistindo: historico do servidor (mesmo entre aparelhos)
  m.resumeItems = []
  state = m.api.getUserState()
  if state <> invalid and state.history <> invalid
    for each h in state.history
      entry = {}
      if h.name <> invalid then entry.name = h.name
      if h.link <> invalid then entry.path = h.link
      if h.path <> invalid and entry.path = invalid then entry.path = h.path
      if entry.name <> invalid and entry.path <> invalid then m.resumeItems.Push(entry)
    end for
  end if

  displayCourses()

  ' Aviso de nova versao (sempre a ultima do GitHub)
  checkForUpdate()

  ' Status do D1 no rodape
  d1 = m.api.getD1Status()
  if d1 <> invalid and d1.ok
    counts = d1.counts
    if counts <> invalid
      lessonsStr = "0"
      summariesStr = "0"
      if counts.lessons <> invalid then lessonsStr = counts.lessons.ToStr()
      if counts.shared_summaries <> invalid then summariesStr = counts.shared_summaries.ToStr()
      if m.statusLabel <> invalid then m.statusLabel.text = "Aulas: " + lessonsStr + " | Resumos: " + summariesStr + " | Meggy v" + m.api.getInstalledVersion()
    else
      if m.statusLabel <> invalid then m.statusLabel.text = "Meggy v" + m.api.getInstalledVersion() + " - educa.eu.org"
    end if
  else
    if m.statusLabel <> invalid then m.statusLabel.text = "Meggy v" + m.api.getInstalledVersion() + " - educa.eu.org"
  end if
end sub

sub checkForUpdate()
  latest = m.api.getLatestAppVersion()
  if latest = invalid then return
  installed = m.api.getInstalledVersion()
  if m.api.isNewerVersion(latest.version, installed)
    m.updateAvailable = true
    if m.updateLabel <> invalid
      m.updateLabel.text = "Nova versao " + latest.version + " disponivel - baixe em github.com/esaaraujo-lab/gdi_server/releases"
      m.updateLabel.visible = true
    end if
  end if
end sub

sub displayCourses()
  if m.coursesRowList = invalid then return

  content = CreateObject("roSGNode", "ContentNode")
  m.rowKinds = []

  ' Linha 1: Continuar assistindo (se houver historico no servidor)
  if m.resumeItems.Count() > 0
    row = content.CreateChild("ContentNode")
    row.title = "Continuar assistindo"
    for each entry in m.resumeItems
      item = row.CreateChild("ContentNode")
      item.title = entry.name
      item.description = entry.path
      item.hdPosterUrl = "pkg:/images/video-icon.png"
    end for
    m.rowKinds.Push("resume")
  end if

  ' Linha 2: Minha Lista (se houver itens salvos)
  if m.myList.Count() > 0
    row = content.CreateChild("ContentNode")
    row.title = "Minha Lista"
    for each entry in m.myList
      item = row.CreateChild("ContentNode")
      item.title = entry.name
      item.description = entry.path
      item.hdPosterUrl = "pkg:/images/course-default.png"
    end for
    m.rowKinds.Push("mylist")
  end if

  ' Linha 3: Seus Cursos
  row = content.CreateChild("ContentNode")
  row.title = "Seus Cursos"
  for each course in m.cachedCourses
    item = row.CreateChild("ContentNode")
    if course.courseName <> invalid
      item.title = course.courseName
    else if course.name <> invalid
      item.title = course.name
    else
      item.title = "Curso"
    end if
    if course.coursePath <> invalid
      item.description = course.coursePath
    else if course.path <> invalid
      item.description = course.path
    else
      item.description = ""
    end if
    item.hdPosterUrl = "pkg:/images/course-default.png"
  end for
  m.rowKinds.Push("courses")

  ' Linha 4: Conta
  row = content.CreateChild("ContentNode")
  row.title = "Conta"
  item = row.CreateChild("ContentNode")
  item.title = "Sair da conta"
  item.description = "__logout__"
  item.hdPosterUrl = "pkg:/images/file-icon.png"
  m.rowKinds.Push("conta")

  m.coursesRowList.content = content
end sub

sub onCourseSelected()
  if m.coursesRowList = invalid then return
  ' rowItemFocus = [linha, item] — o item e o segundo elemento
  focus = m.coursesRowList.rowItemFocus
  if focus = invalid or focus.Count() < 2 then return
  rowIdx = focus[0]
  itemIdx = focus[1]
  if rowIdx < 0 or itemIdx < 0 then return
  if rowIdx >= m.rowKinds.Count() then return

  row = m.coursesRowList.content.GetChild(rowIdx)
  if row = invalid then return
  if itemIdx >= row.GetChildCount() then return
  item = row.GetChild(itemIdx)
  if item = invalid then return

  kind = m.rowKinds[rowIdx]
  if kind = "conta"
    doLogout()
  else if kind = "resume"
    openPlayer(item.description, item.title)
  else
    openCourseDetail(item.description, item.title)
  end if
end sub

sub openCourseDetail(coursePath as String, courseName as String)
  detailScene = CreateObject("roSGNode", "CourseDetailScene")
  detailScene.coursePath = coursePath
  detailScene.courseName = courseName
  detailScene.api = m.api
  m.top.appendChild(detailScene)
  detailScene.setFocus(true)
  showHomeNodes(false)
end sub

sub openPlayer(lessonPath as String, lessonName as String)
  playerScene = CreateObject("roSGNode", "PlayerScene")
  playerScene.lessonPath = lessonPath
  playerScene.lessonName = lessonName
  playerScene.api = m.api
  m.top.appendChild(playerScene)
  playerScene.setFocus(true)
  showHomeNodes(false)
end sub

sub doLogout()
  WriteRegistry("meggy_cookie", "")
  WriteRegistry("meggy_user", "")
  m.api.cookie = ""
  ' Descarta o transfer (o jar de cookies em memoria vai junto)
  m.api._urlTransfer = invalid
  m.cachedCourses = []
  m.resumeItems = []
  showHomeNodes(false)
  showLoginNodes(true)
  if m.usernameInput <> invalid
    m.usernameInput.text = ""
    m.passwordInput.text = ""
  end if
end sub

' === MINHA LISTA (tecla *) ===
sub toggleMyList()
  if m.coursesRowList = invalid then return
  focus = m.coursesRowList.rowItemFocus
  if focus = invalid or focus.Count() < 2 then return
  rowIdx = focus[0]
  itemIdx = focus[1]
  if rowIdx < 0 or itemIdx < 0 then return
  if rowIdx >= m.rowKinds.Count() then return

  kind = m.rowKinds[rowIdx]
  if kind = "resume" or kind = "conta" then return

  row = m.coursesRowList.content.GetChild(rowIdx)
  if row = invalid then return
  if itemIdx >= row.GetChildCount() then return
  item = row.GetChild(itemIdx)
  if item = invalid then return

  coursePath = item.description
  courseName = item.title
  msg = ""
  if kind = "mylist"
    ' Remover da lista
    newList = []
    for each e in m.myList
      if e.path <> coursePath then newList.Push(e)
    end for
    m.myList = newList
    msg = "Removido da Minha Lista"
  else
    ' Adicionar (sem duplicar)
    found = false
    for each e in m.myList
      if e.path = coursePath then found = true
    end for
    if not found
      entry = {name: courseName, path: coursePath}
      m.myList.Push(entry)
      msg = "Adicionado a Minha Lista"
    else
      msg = "Ja esta na Minha Lista"
    end if
  end if
  WriteMyList()
  displayCourses()
  if m.coursesRowList <> invalid then m.coursesRowList.setFocus(true)
  if m.statusLabel <> invalid then m.statusLabel.text = msg
end sub

' === REMOTE HANDLER ===
function onKeyEvent(key as String, press as Boolean) as Boolean
  if not press then return false

  ' Back: fecha detalhe/player e volta para a home
  if key = "back"
    childCount = m.top.getChildCount()
    if childCount > 0
      for i = childCount - 1 to 0 step -1
        child = m.top.getChild(i)
        if child <> invalid
          if child.Subtype() = "CourseDetailScene" or child.Subtype() = "PlayerScene"
            m.top.removeChild(child)
          end if
        end if
      end for
      showHomeNodes(true)
      if m.coursesRowList <> invalid then m.coursesRowList.setFocus(true)
      return true
    end if
    return false
  end if

  ' Tecla * (options): adicionar/remover da Minha Lista
  if key = "options"
    if m.homeBg <> invalid and m.homeBg.visible = true
      toggleMyList()
      return true
    end if
  end if

  ' OK na tela de login: tenta entrar
  if key = "OK"
    if m.loginBg <> invalid and m.loginBg.visible = true
      onLoginButton()
      return true
    end if
  end if

  return false
end function

' === REGISTRY HELPERS ===
function ReadRegistry(key as String) as String
  sec = CreateObject("roRegistrySection", "meggy")
  if sec.Exists(key)
    return sec.Read(key)
  end if
  return ""
end function

sub WriteRegistry(key as String, value as String)
  sec = CreateObject("roRegistrySection", "meggy")
  sec.Write(key, value)
  sec.Flush()
end sub

function ReadMyList() as Object
  raw = ReadRegistry("mylist")
  if raw = "" then return []
  parsed = ParseJSON(raw)
  if parsed = invalid then return []
  return parsed
end function

sub WriteMyList()
  WriteRegistry("mylist", FormatJson(m.myList))
end sub
