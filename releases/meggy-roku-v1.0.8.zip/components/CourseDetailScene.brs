' ===============================================================
' CourseDetailScene - Lista de aulas de um curso (v1.0.8)
' * v1.0.8: selecao certa (rowItemFocus [linha, item]);
'   [x] nas aulas assistidas + tempo de retomada (servidor);
'   PDF nao abre na TV (aviso em vez de player quebrado)
' ===============================================================

sub init()
  m.courseNameLabel = m.top.findNode("courseNameLabel")
  m.coursePathLabel = m.top.findNode("coursePathLabel")
  m.lessonsList = m.top.findNode("lessonsList")
  m.loadingLabel = m.top.findNode("loadingLabel")
  m.userState = {}

  ' Observa mudancas nos campos
  m.top.observeField("courseName", "onCourseNameChanged")
  m.top.observeField("coursePath", "onCoursePathChanged")

  m.lessonsList.observeField("rowItemSelected", "onLessonSelected")
  m.lessonsList.content = CreateObject("roSGNode", "ContentNode")
end sub

sub onCourseNameChanged()
  m.courseNameLabel.text = m.top.courseName
end sub

sub onCoursePathChanged()
  m.coursePathLabel.text = m.top.coursePath
  loadLessons()
end sub

sub loadLessons()
  if m.top.api = invalid
    m.loadingLabel.text = "[X] API nao configurada"
    return
  end if

  m.loadingLabel.text = "Carregando aulas..."
  m.loadingLabel.visible = true

  ' Busca aulas do curso
  lessons = m.top.api.getCourseLessons(m.top.coursePath)

  if lessons.Count() = 0
    m.loadingLabel.text = "Nenhuma aula encontrada para este curso"
    return
  end if

  ' Estado do aluno (assistidas + posicoes) para marcar a lista
  m.userState = m.top.api.getUserState()
  watched = {}
  resume = {}
  if m.userState <> invalid
    if m.userState.watched <> invalid then watched = m.userState.watched
    if m.userState.resume <> invalid then resume = m.userState.resume
  end if

  m.loadingLabel.visible = false

  ' Popula lista
  content = CreateObject("roSGNode", "ContentNode")
  row = content.CreateChild("ContentNode")
  row.title = "Aulas (" + lessons.Count().ToStr() + ")"

  for i = 0 to lessons.Count() - 1
    lesson = lessons[i]
    item = row.CreateChild("ContentNode")
    title = lesson.name
    ' [x] se ja assistida; tempo se ha posicao salva
    if watched.DoesExist(lesson.path) and watched.Lookup(lesson.path) = true
      title = "[x] " + title
    else if resume.DoesExist(lesson.path)
      posSec = Val(resume.Lookup(lesson.path).ToStr())
      if posSec > 5
        title = title + "  (continuar " + fmtTime(posSec) + ")"
      end if
    end if
    item.title = title
    item.description = lesson.path
    if lesson.type = "video"
      item.hdPosterUrl = "pkg:/images/video-icon.png"
    else if lesson.type = "pdf"
      item.hdPosterUrl = "pkg:/images/pdf-icon.png"
    else
      item.hdPosterUrl = "pkg:/images/file-icon.png"
    end if
  end for

  m.lessonsList.content = content
  m.lessonsList.setFocus(true)
end sub

sub onLessonSelected()
  focus = m.lessonsList.rowItemFocus
  if focus = invalid or focus.Count() < 2 then return
  ' rowItemFocus = [linha, item] — o item e o segundo elemento
  idx = focus[1]
  if idx < 0 then return

  row = m.lessonsList.content.GetChild(0)
  if row = invalid then return
  if idx >= row.GetChildCount() then return
  item = row.GetChild(idx)
  if item <> invalid
    lessonPath = item.description
    ' PDF nao abre no player da TV — avisa em vez de quebrar
    if Right(LCase(lessonPath), 4) = ".pdf"
      m.loadingLabel.text = "PDF nao abre na TV - use o site ou o app Android"
      m.loadingLabel.visible = true
      return
    end if
    openPlayer(lessonPath, item.title)
  end if
end sub

sub openPlayer(lessonPath as String, lessonName as String)
  ' Cria cena do player
  playerScene = CreateObject("roSGNode", "PlayerScene")
  playerScene.lessonPath = lessonPath
  playerScene.lessonName = lessonName
  playerScene.api = m.top.api
  m.top.appendChild(playerScene)
  playerScene.setFocus(true)
end sub

function fmtTime(seconds as Float) as String
  total = Int(seconds)
  h = Int(total / 3600)
  mins = Int((total mod 3600) / 60)
  s = total mod 60
  if h > 0
    return h.ToStr() + ":" + Right("0" + mins.ToStr(), 2) + ":" + Right("0" + s.ToStr(), 2)
  end if
  return mins.ToStr() + ":" + Right("0" + s.ToStr(), 2)
end function

function onKeyEvent(key as String, press as Boolean) as Boolean
  if not press then return false
  if key = "back"
    ' Volta para home (MainScene cuida disso)
    return false
  end if
  return false
end function
