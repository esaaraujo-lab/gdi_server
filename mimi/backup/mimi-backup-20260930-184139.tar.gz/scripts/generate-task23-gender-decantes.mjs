// Task ID 23 — Generate 14 gender-colored 5ml decante (sample atomizer) images
// for the Mimi Mimos luxury perfume catalog.
//
// Categories:
//   FEMININO  (6)  → rose / pink / purple / red / rose-gold / magenta / pink-champagne
//   MASCULINO (4)  → black / deep blue / charcoal grey / midnight blue
//   UNISSEX/ARABE (4) → amber / golden / warm brown / beige cream (neutral luxury)
//
// Output: /home/z/my-project/public/perfumes/dec-{fem,masc,uni}-0N.jpg
// Spec : 1024x1024, JPG q=92 (mozjpeg, 4:4:4), dark obsidian bg, gold accents
//
// Usage: node scripts/generate-task23-gender-decantes.mjs
import ZAI from 'z-ai-web-dev-sdk';
import fs from 'fs';
import path from 'path';
import sharp from 'sharp';

const OUT_DIR = '/home/z/my-project/public/perfumes';
const TMP_DIR = '/home/z/my-project/scripts/tmp';
fs.mkdirSync(OUT_DIR, { recursive: true });
fs.mkdirSync(TMP_DIR, { recursive: true });

const LUX_STYLE =
  'ultra-luxurious editorial product photography, high-end parfumerie catalog, dramatic cinematic lighting, soft golden rim light, fine art still life, ultra-detailed, photorealistic, 8k, depth of field, reflective polished black obsidian surface, luxury gold accents';
const BG =
  'pure obsidian solid black background (#090a0f), deep matte black, no other objects, no text, no logos, no visible labels with text';

// 5ml atomizer decant description (consistent across all images)
const DECANT_BODY =
  'a small 5ml miniature perfume decant sample atomizer spray bottle, slim cylindrical glass vial about 7cm tall, slender travel atomizer size, small gold metallic spray nozzle cap on top, fine mist pump, tiny pocket-size sample bottle, NOT a full size bottle, proportions of a small tester sample';

const JOBS = [
  // ── FEMININE DECANTES (rose / pink / purple / red) ─────────────────────
  {
    id: 'dec-fem-01',
    name: 'Feminine decante — pink liquid, rose-themed bottle',
    prompt: `Realistic product photograph of ${DECANT_BODY}, filled with translucent blush pink liquid, delicate rose-petal pink tinted glass body, small gold rose motif embossed on the bottle, elegant feminine romantic design, soft rose-floral mood, ${BG}, single bottle centered vertical composition, ${LUX_STYLE}`,
  },
  {
    id: 'dec-fem-02',
    name: 'Feminine decante — purple/violet liquid, elegant bottle',
    prompt: `Realistic product photograph of ${DECANT_BODY}, filled with deep purple violet liquid, amethyst tinted glass body, elegant gold filigree band at the neck, refined feminine luxurious design, mysterious violet floral mood, ${BG}, single bottle centered vertical composition, ${LUX_STYLE}`,
  },
  {
    id: 'dec-fem-03',
    name: 'Feminine decante — red/crimson liquid, sensual bottle',
    prompt: `Realistic product photograph of ${DECANT_BODY}, filled with crimson red liquid, ruby red tinted glass body, gold trim around the cap base, sensual seductive feminine design, deep red rose romantic mood, ${BG}, single bottle centered vertical composition, ${LUX_STYLE}`,
  },
  {
    id: 'dec-fem-04',
    name: 'Feminine decante — rose-gold liquid, floral bottle',
    prompt: `Realistic product photograph of ${DECANT_BODY}, filled with shimmering rose gold liquid, rose gold tinted glass body, engraved gold floral pattern around the body, feminine floral luxurious design, soft rose-gold romantic mood, ${BG}, single bottle centered vertical composition, ${LUX_STYLE}`,
  },
  {
    id: 'dec-fem-05',
    name: 'Feminine decante — magenta liquid, ornate bottle',
    prompt: `Realistic product photograph of ${DECANT_BODY}, filled with vibrant magenta liquid, deep magenta pink tinted glass body, ornate gold ornament ring at the neck, bold feminine ornate luxurious design, vibrant magenta exotic mood, ${BG}, single bottle centered vertical composition, ${LUX_STYLE}`,
  },
  {
    id: 'dec-fem-06',
    name: 'Feminine decante — pink champagne liquid, sparkling bottle',
    prompt: `Realistic product photograph of ${DECANT_BODY}, filled with sparkling pink champagne liquid with tiny bubbles, luminous champagne pink tinted glass body, subtle gold glitter accents around the cap, festive feminine sparkling luxurious design, champagne celebratory mood, ${BG}, single bottle centered vertical composition, ${LUX_STYLE}`,
  },

  // ── MASCULINE DECANTES (black / blue / charcoal) ───────────────────────
  {
    id: 'dec-masc-01',
    name: 'Masculine decante — black liquid, bold dark bottle',
    prompt: `Realistic product photograph of ${DECANT_BODY}, filled with opaque black liquid, bold matte black glass body, dark gold emblem on the bottle, strong masculine powerful design, dark mysterious bold mood, ${BG}, single bottle centered vertical composition, ${LUX_STYLE}`,
  },
  {
    id: 'dec-masc-02',
    name: 'Masculine decante — deep blue liquid, navy bottle',
    prompt: `Realistic product photograph of ${DECANT_BODY}, filled with deep blue navy liquid, navy blue tinted glass body, gold cap with subtle gold accent ring, masculine sophisticated design, deep navy aquatic mood, ${BG}, single bottle centered vertical composition, ${LUX_STYLE}`,
  },
  {
    id: 'dec-masc-03',
    name: 'Masculine decante — dark grey/charcoal liquid, steel bottle',
    prompt: `Realistic product photograph of ${DECANT_BODY}, filled with charcoal grey liquid, steel grey metallic glass body, gunmetal dark cap with gold accent trim, masculine industrial modern design, charcoal sleek metallic mood, ${BG}, single bottle centered vertical composition, ${LUX_STYLE}`,
  },
  {
    id: 'dec-masc-04',
    name: 'Masculine decante — midnight blue liquid, sleek bottle',
    prompt: `Realistic product photograph of ${DECANT_BODY}, filled with midnight blue liquid, sleek dark blue tinted glass body, gold trim around the spray cap, masculine elegant nocturnal design, midnight blue mysterious mood, ${BG}, single bottle centered vertical composition, ${LUX_STYLE}`,
  },

  // ── UNISEX / ARABIC DECANTES (amber / gold / brown / beige neutral) ─────
  {
    id: 'dec-uni-01',
    name: 'Unisex decante — amber liquid, ornate Arabian bottle',
    prompt: `Realistic product photograph of ${DECANT_BODY}, filled with luminous amber liquid, ornate Arabian glass body with intricate gold filigree arabesque pattern at the neck, warm oriental unisex luxurious design, amber oriental mood, ${BG}, single bottle centered vertical composition, ${LUX_STYLE}`,
  },
  {
    id: 'dec-uni-02',
    name: 'Unisex decante — golden liquid, luxury bottle',
    prompt: `Realistic product photograph of ${DECANT_BODY}, filled with radiant golden liquid, crystal clear glass body with gold trim around the cap, neutral unisex luxurious design, golden radiant opulent mood, ${BG}, single bottle centered vertical composition, ${LUX_STYLE}`,
  },
  {
    id: 'dec-uni-03',
    name: 'Unisex decante — warm brown liquid, oriental bottle',
    prompt: `Realistic product photograph of ${DECANT_BODY}, filled with warm brown liquid, warm amber-brown tinted glass body, subtle gold accent ring at the neck, oriental woody unisex design, warm brown oriental mood, ${BG}, single bottle centered vertical composition, ${LUX_STYLE}`,
  },
  {
    id: 'dec-uni-04',
    name: 'Unisex decante — beige/cream liquid, minimalist bottle',
    prompt: `Realistic product photograph of ${DECANT_BODY}, filled with soft beige cream liquid, frosted beige tinted glass body, subtle minimalist gold accent line at the base of the cap, neutral minimalist unisex luxurious design, calm beige cream serene mood, ${BG}, single bottle centered vertical composition, ${LUX_STYLE}`,
  },
];

const MAX_RETRIES = 4;

function exists(id) {
  const p = path.join(OUT_DIR, `${id}.jpg`);
  if (!fs.existsSync(p)) return false;
  const s = fs.statSync(p);
  return s.size > 5000;
}

async function generateOne(zai, job, attempt = 1) {
  const tmpPng = path.join(TMP_DIR, `${job.id}.raw.png`);
  try {
    console.log(`▶ [${attempt}/${MAX_RETRIES}] ${job.id} — ${job.name}`);
    const response = await zai.images.generations.create({
      prompt: job.prompt,
      size: '1024x1024',
    });
    if (!response?.data?.[0]?.base64) {
      throw new Error('Invalid response from API (no base64)');
    }
    const buffer = Buffer.from(response.data[0].base64, 'base64');
    fs.writeFileSync(tmpPng, buffer);

    const outPath = path.join(OUT_DIR, `${job.id}.jpg`);
    await sharp(tmpPng, { failOn: 'none' })
      .resize({ width: 1024, height: 1024, fit: 'cover', position: 'center' })
      .jpeg({ quality: 92, mozjpeg: true, chromaSubsampling: '4:4:4' })
      .toFile(outPath);
    const stat = fs.statSync(outPath);
    console.log(`  ✓ ${job.id}.jpg (${stat.size} bytes)`);
    fs.unlinkSync(tmpPng);
    return { success: true, id: job.id, name: job.name, path: outPath, bytes: stat.size };
  } catch (err) {
    console.error(`  ✗ ${job.id}: ${err.message}`);
    if (fs.existsSync(tmpPng)) {
      try { fs.unlinkSync(tmpPng); } catch {}
    }
    if (attempt < MAX_RETRIES) {
      const wait = 2500 * attempt;
      console.log(`  ↻ retry in ${wait / 1000}s...`);
      await new Promise(r => setTimeout(r, wait));
      return generateOne(zai, job, attempt + 1);
    }
    return { success: false, id: job.id, name: job.name, error: err.message };
  }
}

async function main() {
  const pending = JOBS.filter(j => !exists(j.id));
  const done = JOBS.filter(j => exists(j.id));
  console.log(`Total jobs: ${JOBS.length} | already done: ${done.length} | pending: ${pending.length}`);
  done.forEach(d => console.log(`  ✓ ${d.id}.jpg already exists`));

  if (pending.length === 0) {
    console.log('Nothing to do.');
    return;
  }

  console.log('\nInitializing Z-AI SDK...');
  const zai = await ZAI.create();

  const results = [];
  for (const job of pending) {
    const r = await generateOne(zai, job);
    results.push(r);
    await new Promise(res => setTimeout(res, 400));
  }

  console.log('\n========== BATCH SUMMARY ==========');
  const ok = [], fail = [];
  for (const r of results) {
    if (r.success) {
      console.log(`  ✓ ${r.id}.jpg → ${r.path} (${r.bytes} bytes)`);
      ok.push(r);
    } else {
      console.log(`  ✗ ${r.id} FAILED: ${r.error}`);
      fail.push(r);
    }
  }
  console.log(`Generated: ${ok.length} | Failed: ${fail.length}`);

  const summaryPath = path.join(TMP_DIR, 'task23-summary.json');
  fs.writeFileSync(summaryPath, JSON.stringify({ ok, fail }, null, 2));
  console.log(`Summary JSON: ${summaryPath}`);

  process.exit(fail.length > 0 ? 1 : 0);
}

main().catch(err => {
  console.error('Fatal:', err);
  process.exit(1);
});
