#!/usr/bin/env python3
"""Search GiftExpress for each perfume and find its image URL."""
import json, re, subprocess, os, sys, time

CACHE_DIR = "/home/z/my-project/scripts/tmp/pages"
os.makedirs(CACHE_DIR, exist_ok=True)

def fetch_page(url, cache_key):
    out_path = os.path.join(CACHE_DIR, f"{cache_key}.json")
    if os.path.exists(out_path) and os.path.getsize(out_path) > 1000:
        return out_path
    args = json.dumps({"url": url})
    cmd = ["z-ai", "function", "-n", "page_reader", "-a", args, "-o", out_path]
    try:
        res = subprocess.run(cmd, capture_output=True, text=True, timeout=120)
        if res.returncode != 0:
            return None
        return out_path
    except subprocess.TimeoutExpired:
        return None

def parse_giftexpress_results(json_path):
    """Return list of (alt_text, image_url) tuples from GiftExpress search results."""
    try:
        with open(json_path) as f:
            d = json.load(f)
    except: return []
    html = d.get("data", {}).get("html", "")
    if not html: return []
    pairs = []
    for m in re.finditer(r'<img[^>]+alt=["\']([^"\']+)["\'][^>]+(?:data-src|src)=["\']([^"\']*media/catalog/product[^"\']+)["\']', html):
        pairs.append((m.group(1), m.group(2)))
    for m in re.finditer(r'<img[^>]+(?:data-src|src)=["\']([^"\']*media/catalog/product[^"\']+)["\'][^>]+alt=["\']([^"\']+)["\']', html):
        pairs.append((m.group(2), m.group(1)))
    return pairs

def check_url(url):
    try:
        res = subprocess.run(
            ["curl", "-sI", "-o", "/dev/null", "-w", "%{http_code}", "--max-time", "20",
             "-A", "Mozilla/5.0", url],
            capture_output=True, text=True, timeout=25
        )
        code = res.stdout.strip().split('\n')[-1]
        return code == "200", code
    except Exception as e:
        return False, str(e)

def best_match(pairs, perfume_name, brand):
    """Score each pair by how well alt text matches perfume_name + brand."""
    perfume_lower = perfume_name.lower()
    brand_lower = brand.lower()
    # Build keyword list (skip common words)
    stopwords = {"the","for","by","and","of","edt","edp","parfum","spray","men","women","unisex","eau","de","toilette","perfume","cologne","intense"}
    keywords = set()
    for word in perfume_name.lower().replace("'", " ").split():
        if word not in stopwords and len(word) > 1:
            keywords.add(word)
    for word in brand.lower().split():
        if word not in stopwords and len(word) > 1:
            keywords.add(word)
    scored = []
    for alt, src in pairs:
        alt_lower = alt.lower().replace("&amp;", " ").replace("&gt;", " ")
        # Tokenize
        alt_words = set(re.findall(r'[a-z0-9]+', alt_lower))
        matches = len(keywords & alt_words)
        # Penalty: if it's a "tester" or "vial" or "mini"
        penalty = 0
        if "tester" in alt_lower: penalty -= 2
        if "vial" in alt_lower: penalty -= 1
        if "mini" in alt_lower: penalty -= 1
        if "set" in alt_lower or "gift" in alt_lower: penalty -= 1
        # Bonus: brand match is most important
        brand_words = set(re.findall(r'[a-z0-9]+', brand_lower))
        brand_matches = len(brand_words & alt_words)
        score = matches + 3 * brand_matches + penalty
        scored.append((score, alt, src))
    scored.sort(reverse=True)
    return scored

# Perfumes to find via GiftExpress
TARGETS = {
    # Brand Collection
    "bc-001": ("Allure Homme Sport", "Chanel"),
    "bc-002": ("London", "Burberry"),
    "bc-003": ("CH", "Carolina Herrera"),
    "bc-004": ("CH Men", "Carolina Herrera"),
    "bc-005": ("1 Million", "Paco Rabanne"),
    "bc-007": ("J'adore", "Christian Dior"),
    "bc-008": ("212 VIP Men", "Carolina Herrera"),
    "bc-010": ("Black Orchid", "Tom Ford"),
    "bc-012": ("La Vie Est Belle", "Lancome"),
    "bc-021": ("Coco Mademoiselle", "Chanel"),
    "bc-027": ("Hypnotic Poison", "Christian Dior"),
    "bc-034": ("212 VIP Rose", "Carolina Herrera"),
    "bc-070": ("Bleu de Chanel", "Chanel"),
    "bc-100": ("Sauvage", "Christian Dior"),
    "bc-105": ("Lady Million", "Paco Rabanne"),
    "bc-116": ("Invictus", "Paco Rabanne"),
    "bc-126": ("Good Girl", "Carolina Herrera"),
    "bc-136": ("Scandal", "Jean Paul Gaultier"),
    "bc-159": ("Libre", "Yves Saint Laurent"),
    "bc-181": ("Bad Boy", "Carolina Herrera"),
    "bc-247": ("Baccarat Rouge 540", "Maison Francis Kurkdjian"),
    "bc-283": ("Sauvage Elixir", "Christian Dior"),
    # Non-Lattafa Arabic perfumes
    "af-04": ("Royal Amber", "Orientica"),
    "dec-01": ("Bareeq Al Dahab", "Al Wataniah"),
    "dec-04": ("Royal Blend Nero", "Maison Alhambra"),
    "dec-07": ("Odyssey Dubai Chocolat", "Armaf"),
    "dec-09": ("Watani Noir", "Al Wataniah"),
    "dec-11": ("Oud Mystery Intense", "Al Wataniah"),
    "dec-13": ("Chants Tenderina", "Maison Alhambra"),
    "dec-15": ("Rose Mystery Intense", "Al Wataniah"),
    "af-03": ("Yara Pink", "Lattafa"),
}

results = {}
for pid, (perfume, brand) in TARGETS.items():
    print(f"\n=== {pid} ({brand} {perfume}) ===", flush=True)
    # Build search query: brand + perfume
    query = f"{brand} {perfume}".replace(" ", "+").replace("'", "%27")
    url = f"https://www.giftexpress.com/catalogsearch/result/?q={query}"
    cache_key = f"ge-{pid}"
    out = fetch_page(url, cache_key)
    if not out:
        print(f"  fetch failed", flush=True)
        continue
    pairs = parse_giftexpress_results(out)
    if not pairs:
        print(f"  no results", flush=True)
        continue
    # Deduplicate
    seen = set()
    unique_pairs = []
    for alt, src in pairs:
        key = (alt, src)
        if key not in seen:
            seen.add(key)
            unique_pairs.append((alt, src))
    print(f"  Unique results: {len(unique_pairs)}", flush=True)
    # Top candidates
    scored = best_match(unique_pairs, perfume, brand)
    for score, alt, src in scored[:5]:
        print(f"    [{score}] {alt[:80]} -> {src}", flush=True)
    if not scored:
        continue
    best_score, best_alt, best_src = scored[0]
    if best_score < 4:
        print(f"  LOW confidence (score={best_score})", flush=True)
    ok, code = check_url(best_src)
    if ok:
        print(f"  -> {best_src} [200]", flush=True)
        results[pid] = best_src
    else:
        print(f"  -> {best_src} [{code}]", flush=True)
    time.sleep(0.2)

print("\n=== FINAL ===")
for k, v in results.items():
    print(f"  {k}: {v}")
print(f"\nTotal: {len(results)}/{len(TARGETS)}")

with open("/home/z/my-project/scripts/tmp/giftexpress-results.json", "w") as f:
    json.dump(results, f, indent=2)
