#!/usr/bin/env python3
"""Fetch missing Lattafa perfume pages via page_reader."""
import json, re, subprocess, os, sys

CACHE_DIR = "/home/z/my-project/scripts/tmp/pages"
os.makedirs(CACHE_DIR, exist_ok=True)

def fetch_page(url, cache_key):
    out_path = os.path.join(CACHE_DIR, f"{cache_key}.json")
    if os.path.exists(out_path) and os.path.getsize(out_path) > 1000:
        return out_path
    args = json.dumps({"url": url})
    cmd = ["z-ai", "function", "-n", "page_reader", "-a", args, "-o", out_path]
    try:
        res = subprocess.run(cmd, capture_output=True, text=True, timeout=120)
        if res.returncode != 0:
            print(f"  ERROR: {res.stderr[:200]}", file=sys.stderr)
            return None
        return out_path
    except subprocess.TimeoutExpired:
        return None

def extract_og_image(json_path):
    try:
        with open(json_path) as f:
            d = json.load(f)
    except: return None, "json err"
    html = d.get("data", {}).get("html", "")
    if not html: return None, "no html"
    m = re.search(r'<meta[^>]+property=["\']og:image["\'][^>]+content=["\']([^"\']+)["\']', html, re.IGNORECASE)
    if not m:
        m = re.search(r'<meta[^>]+content=["\']([^"\']+)["\'][^>]+property=["\']og:image["\']', html, re.IGNORECASE)
    if m:
        return m.group(1), "og:image"
    # JSON-LD
    ld_blocks = re.findall(r'<script[^>]+type=["\']application/ld\+json["\'][^>]*>(.*?)</script>', html, re.DOTALL)
    for b in ld_blocks:
        try:
            j = json.loads(b.strip())
            if isinstance(j, dict) and j.get("@type") == "Product":
                img = j.get("image")
                if isinstance(img, list) and img: return img[0], "JSON-LD"
                if isinstance(img, str): return img, "JSON-LD"
            if isinstance(j, dict) and "@graph" in j:
                for n in j["@graph"]:
                    if isinstance(n, dict) and n.get("@type") == "Product":
                        img = n.get("image")
                        if isinstance(img, list) and img: return img[0], "JSON-LD @graph"
                        if isinstance(img, str): return img, "JSON-LD @graph"
        except: pass
    return None, "no og"

def check_url(url):
    if not url or not url.startswith("http"): return False, "invalid"
    try:
        res = subprocess.run(
            ["curl", "-sIL", "-o", "/dev/null", "-w", "%{http_code}", "--max-time", "20", url],
            capture_output=True, text=True, timeout=25
        )
        code = res.stdout.strip().split('\n')[-1]
        return code == "200", code
    except Exception as e:
        return False, str(e)

# Try these specific slugs on lattafa.com
SLUGS = {
    "af-07": ["fakhar-lattafa-women"],
    "dec-06": ["asad-bourbon"],
    "dec-14": ["ameerat-al-arab-prive-rose", "ameerat-al-arab"],
    "dec-16": ["fakhar-lattafa-platin", "fakhar-lattafa-extrait"],
}

# Also try Yara Pink via search on Lattafa USA catalog (we already have it but it's not there)
# Try different naming on other sites

results = {}
for pid, slugs in SLUGS.items():
    print(f"\n=== {pid} ===", flush=True)
    found = False
    for slug in slugs:
        url = f"https://lattafa.com/product/{slug}/"
        cache_key = f"lat2-{pid}-{slug}"
        print(f"  Trying: {url}", flush=True)
        out = fetch_page(url, cache_key)
        if not out:
            continue
        img, source = extract_og_image(out)
        if img:
            print(f"  Found ({source}): {img}", flush=True)
            ok, code = check_url(img)
            if ok:
                print(f"  OK 200", flush=True)
                results[pid] = img
                found = True
                break
            else:
                print(f"  HTTP {code}", flush=True)
        else:
            print(f"  No og:image: {source}", flush=True)
    if not found:
        print(f"  NOT FOUND for {pid}", flush=True)

print("\n=== RESULTS ===")
for k, v in results.items():
    print(f"  {k}: {v}")

with open("/home/z/my-project/scripts/tmp/lattafa-extra.json", "w") as f:
    json.dump(results, f, indent=2)
