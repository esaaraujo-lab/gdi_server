#!/usr/bin/env python3
"""Fetch Lattafa product pages via page_reader and extract og:image URL."""
import json, re, subprocess, sys, os

CACHE_DIR = "/home/z/my-project/scripts/tmp/pages"
os.makedirs(CACHE_DIR, exist_ok=True)

def fetch_page(url, cache_key):
    """Use z-ai function page_reader to fetch a page; cache result."""
    out_path = os.path.join(CACHE_DIR, f"{cache_key}.json")
    if os.path.exists(out_path) and os.path.getsize(out_path) > 1000:
        return out_path
    args = json.dumps({"url": url})
    cmd = ["z-ai", "function", "-n", "page_reader", "-a", args, "-o", out_path]
    try:
        res = subprocess.run(cmd, capture_output=True, text=True, timeout=120)
        if res.returncode != 0:
            print(f"  ERROR fetching {url}: {res.stderr[:200]}", file=sys.stderr)
            return None
        return out_path
    except subprocess.TimeoutExpired:
        print(f"  TIMEOUT fetching {url}", file=sys.stderr)
        return None

def extract_og_image(json_path):
    """Extract og:image or JSON-LD Product image from page_reader JSON."""
    try:
        with open(json_path) as f:
            d = json.load(f)
    except Exception as e:
        return None, f"json load failed: {e}"
    html = d.get("data", {}).get("html", "")
    if not html:
        return None, "no html"
    # og:image
    m = re.search(r'<meta[^>]+property=["\']og:image["\'][^>]+content=["\']([^"\']+)["\']', html, re.IGNORECASE)
    if not m:
        m = re.search(r'<meta[^>]+content=["\']([^"\']+)["\'][^>]+property=["\']og:image["\']', html, re.IGNORECASE)
    if m:
        return m.group(1), "og:image"
    # JSON-LD Product
    ld_blocks = re.findall(r'<script[^>]+type=["\']application/ld\+json["\'][^>]*>(.*?)</script>', html, re.DOTALL)
    for b in ld_blocks:
        try:
            j = json.loads(b.strip())
            if isinstance(j, dict) and j.get("@type") == "Product":
                img = j.get("image")
                if isinstance(img, list) and img:
                    return img[0], "JSON-LD Product"
                if isinstance(img, str):
                    return img, "JSON-LD Product"
            # Graph list
            if isinstance(j, dict) and "@graph" in j:
                for node in j["@graph"]:
                    if isinstance(node, dict) and node.get("@type") == "Product":
                        img = node.get("image")
                        if isinstance(img, list) and img:
                            return img[0], "JSON-LD @graph Product"
                        if isinstance(img, str):
                            return img, "JSON-LD @graph Product"
        except: pass
    # og:image:secure_url fallback
    m = re.search(r'<meta[^>]+property=["\']og:image:secure_url["\'][^>]+content=["\']([^"\']+)["\']', html, re.IGNORECASE)
    if m:
        return m.group(1), "og:image:secure_url"
    title = re.search(r'<title[^>]*>([^<]+)</title>', html)
    return None, f"no og:image found (title: {title.group(1)[:80] if title else 'none'})"

def check_url(url):
    """Check if URL returns HTTP 200."""
    if not url or not url.startswith("http"):
        return False, "invalid"
    try:
        res = subprocess.run(
            ["curl", "-sIL", "-o", "/dev/null", "-w", "%{http_code}", "--max-time", "20", url],
            capture_output=True, text=True, timeout=25
        )
        code = res.stdout.strip().split('\n')[-1]
        return code == "200", code
    except Exception as e:
        return False, str(e)

# Define Lattafa perfume slugs to try
LATTAFA_SLUGS = {
    # AFEER Arabic Miniatures
    "af-01": ["aatheer", "aatheer-lattafa", "atheeri"],
    "af-02": ["asad", "asad-eau-de-parfum"],
    "af-03": ["yara-pink", "yara-pink-lattafa"],
    "af-07": ["fakhar-rose", "fakhar-rose-edp"],

    # Decantes Arabic
    "dec-02": ["asad-zanzibar", "zanzibar"],
    "dec-03": ["qaed-al-fursan", "qaed-al-fursan-unisex"],
    "dec-05": ["khamrah", "khamrah-edp"],
    "dec-06": ["asad-marrom-bourbon", "marrom-bourbon", "asad-marrom"],
    "dec-08": ["dukhan", "dukhan-lattafa"],
    "dec-10": ["badee-al-oud-for-glory", "badee-al-oud-amothman"],
    "dec-12": ["al-noble-ameer", "noble-ameer"],
    "dec-14": ["amirat-al-arab-prive", "amirat-al-arab-prive-red"],
    "dec-16": ["fakhar-rose-gold", "fakhar-rose-gold-lattafa"],
    "dec-17": ["tharwah-gold", "tharwa-gold"],
    "dec-18": ["yara-tous", "yara-tous-lattafa"],
}

results = {}
for perfume_id, slugs in LATTAFA_SLUGS.items():
    print(f"\n=== {perfume_id} ===", flush=True)
    found = False
    for slug in slugs:
        url = f"https://lattafa.com/product/{slug}/"
        cache_key = f"{perfume_id}-{slug}"
        print(f"  Trying: {url}", flush=True)
        out = fetch_page(url, cache_key)
        if not out:
            continue
        img, source = extract_og_image(out)
        if img:
            print(f"  Found via {source}: {img}", flush=True)
            ok, code = check_url(img)
            if ok:
                print(f"  OK VALID (200)", flush=True)
                results[perfume_id] = img
                found = True
                break
            else:
                print(f"  Image URL returned {code}", flush=True)
        else:
            print(f"  No og:image: {source}", flush=True)
    if not found:
        print(f"  NO VALID IMAGE FOUND for {perfume_id}", flush=True)

print("\n=== RESULTS ===")
for k, v in results.items():
    print(f"  {k}: {v}")
print(f"\nTotal: {len(results)}/{len(LATTAFA_SLUGS)}")

with open("/home/z/my-project/scripts/tmp/lattafa-results.json", "w") as f:
    json.dump(results, f, indent=2)
print("\nSaved to lattafa-results.json")
