/**
 * Busca imagens reais de perfumes árabes via Wayback Machine (archive.org).
 * A Lattafa usa CloudFront (d2jo70kbut6ej8.cloudfront.net) que é bloqueado,
 * mas o Wayback Machine preserva as imagens com prefixo "im_/".
 */
import ZAI from 'z-ai-web-dev-sdk';
import fs from 'fs';
import path from 'path';
import https from 'https';

const PERFUMES = [
  // Lattafa perfumes
  { id: 'dec-05', name: 'Khamrah', url: 'https://lattafa.com/product/khamrah/' },
  { id: 'dec-03', name: 'Qaed Al Fursan', url: 'https://lattafa.com/product/qaed-al-fursan/' },
  { id: 'dec-02', name: 'Asad Zanzibar', url: 'https://lattafa.com/product/asad-zanzibar/' },
  { id: 'dec-06', name: 'Asad Marrom Bourbon', url: 'https://lattafa.com/product/asad-bourbon/' },
  { id: 'af-02', name: 'Asad', url: 'https://lattafa.com/product/asad/' },
  { id: 'af-03', name: 'Yara Pink', url: 'https://lattafa.com/product/yara-pink/' },
  { id: 'af-07', name: 'Fakhar Rose', url: 'https://lattafa.com/product/fakhar-rose/' },
  { id: 'dec-16', name: 'Fakhar Rose Gold', url: 'https://lattafa.com/product/fakhar-rose-gold/' },
  { id: 'dec-17', name: 'Tharwah Gold', url: 'https://lattafa.com/product/tharwah-gold/' },
  { id: 'dec-18', name: 'Yara Tous', url: 'https://lattafa.com/product/yara-tous/' },
  { id: 'dec-14', name: 'Amirat Al Arab Prive Red', url: 'https://lattafa.com/product/amirat-al-arab-prive-red/' },
  { id: 'dec-08', name: 'Dukhan', url: 'https://lattafa.com/product/dukhan/' },
  { id: 'dec-10', name: 'Badee Al Oud For Glory', url: 'https://lattafa.com/product/badee-al-oud-for-glory/' },
  { id: 'dec-12', name: 'Al Noble Ameer', url: 'https://lattafa.com/product/al-noble-ameer/' },
  // Maison Alhambra
  { id: 'dec-04', name: 'Royal Blend Nero', url: 'https://maison-alhambra.com/product/royal-blend-nero/' },
  { id: 'dec-13', name: 'Chants Tenderina', url: 'https://maison-alhambra.com/product/chants-tenderina/' },
];

function extractProductImage(html, domain) {
  const re = /(?:src|data-src)="(https?:\/\/web\.archive\.org\/web\/\d+im_\/https?:\/\/[^"]+\.(?:jpg|jpeg|png|webp)[^"]*)"/gi;
  const urls = new Set();
  let m;
  while ((m = re.exec(html)) !== null) urls.add(m[1]);
  // Filtra imagens de produto (não ícones de UI)
  const prod = [...urls].filter(u =>
    !u.includes('icon/') && !u.includes('logo') && !u.includes('banner') &&
    !u.includes('assets/images') && !u.includes('add.png') &&
    (u.includes('uploads') || u.includes('product') || u.includes('cloudfront'))
  );
  return prod[0] || null;
}

function download(url, dest) {
  return new Promise((resolve) => {
    const file = fs.createWriteStream(dest);
    https.get(url, { headers: { 'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36' } }, (res) => {
      if (res.statusCode !== 200) { file.close(); fs.unlinkSync(dest); resolve(false); return; }
      res.pipe(file);
      file.on('finish', () => { file.close(); resolve(true); });
    }).on('error', () => { fs.existsSync(dest) && fs.unlinkSync(dest); resolve(false); });
  });
}

async function main() {
  const zai = await ZAI.create();
  const outDir = '/home/z/my-project/public/perfumes';
  if (!fs.existsSync(outDir)) fs.mkdirSync(outDir, { recursive: true });

  const results = {};
  let found = 0;

  for (const p of PERFUMES) {
    console.log(`\n[${p.id}] ${p.name}`);
    const wbUrl = `https://web.archive.org/web/2024/${p.url}`;
    try {
      const result = await zai.functions.invoke('page_reader', { url: wbUrl });
      const html = result.data?.html || '';
      const title = result.data?.title || '';
      console.log(`  Title: ${title.slice(0, 60)}`);
      const imgUrl = extractProductImage(html, p.url);
      if (imgUrl) {
        console.log(`  Found: ${imgUrl.slice(0, 120)}`);
        // Baixa a imagem
        const ext = imgUrl.match(/\.(jpg|jpeg|png|webp)/i)?.[0]?.toLowerCase() || '.jpg';
        const dest = path.join(outDir, `${p.id}-real${ext}`);
        const ok = await download(imgUrl, dest);
        if (ok && fs.statSync(dest).size > 3000) {
          results[p.id] = `/perfumes/${p.id}-real${ext}`;
          found++;
          console.log(`  ✓ Saved (${fs.statSync(dest).size} bytes)`);
        } else {
          console.log(`  ✗ Download failed or too small`);
        }
      } else {
        console.log(`  ✗ No product image found`);
      }
    } catch (e) {
      console.log(`  ✗ Error: ${e.message?.slice(0, 80)}`);
    }
    await new Promise(r => setTimeout(r, 800)); // throttle
  }

  fs.writeFileSync('/home/z/my-project/real-image-urls.json', JSON.stringify(results, null, 2));
  console.log(`\n=== SUMMARY ===`);
  console.log(`Found ${found}/${PERFUMES.length} real images`);
  console.log('Saved to /home/z/my-project/real-image-urls.json');
}

main().catch(console.error);
