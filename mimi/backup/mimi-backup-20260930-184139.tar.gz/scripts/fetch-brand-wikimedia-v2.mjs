/**
 * Busca imagens reais dos Brand Collection via Wikimedia Commons API.
 * Baixa diretamente (sem VLM para evitar rate limit).
 */
import fs from 'fs';
import path from 'path';
import { execSync } from 'child_process';

const OUT_DIR = '/home/z/my-project/public/perfumes';
const UA = 'MimiMimos/1.0 (perfume catalog; contact@mimimimos.com)';

const PERFUMES = [
  { id: 'bc-001', q: 'Allure Homme Sport Chanel' },
  { id: 'bc-002', q: 'Burberry London for Men perfume' },
  { id: 'bc-003', q: 'Carolina Herrera CH Women perfume' },
  { id: 'bc-004', q: 'Carolina Herrera CH Men perfume' },
  { id: 'bc-005', q: 'Paco Rabanne 1 Million perfume' },
  { id: 'bc-007', q: 'Dior Jadore perfume' },
  { id: 'bc-008', q: '212 VIP Men Carolina Herrera' },
  { id: 'bc-010', q: 'Tom Ford Black Orchid perfume' },
  { id: 'bc-012', q: 'La Vie Est Belle Lancome' },
  { id: 'bc-021', q: 'Coco Mademoiselle Chanel' },
  { id: 'bc-027', q: 'Hypnotic Poison Dior' },
  { id: 'bc-034', q: '212 VIP Rose Carolina Herrera' },
  { id: 'bc-070', q: 'Bleu de Chanel perfume' },
  { id: 'bc-100', q: 'Sauvage Dior perfume' },
  { id: 'bc-105', q: 'Lady Million Paco Rabanne' },
  { id: 'bc-116', q: 'Invictus Paco Rabanne' },
  { id: 'bc-126', q: 'Good Girl Carolina Herrera' },
  { id: 'bc-136', q: 'Scandal Jean Paul Gaultier perfume' },
  { id: 'bc-159', q: 'Libre Yves Saint Laurent perfume' },
  { id: 'bc-181', q: 'Bad Boy Carolina Herrera' },
  { id: 'bc-247', q: 'Baccarat Rouge 540' },
  { id: 'bc-283', q: 'Sauvage Elixir Dior' },
];

function searchWikimedia(query) {
  try {
    const url = `https://commons.wikimedia.org/w/api.php?action=query&generator=search&gsrsearch=${encodeURIComponent(query)}&gsrnamespace=6&prop=imageinfo&iiprop=url|mime|size&format=json&gsrlimit=5`;
    const out = execSync(`curl -s -A "${UA}" --max-time 15 "${url}"`, { timeout: 20000, encoding: 'utf-8' });
    const data = JSON.parse(out);
    const pages = data.query?.pages || {};
    return Object.values(pages)
      .filter(p => {
        const ii = p.imageinfo?.[0];
        return ii && (ii.mime === 'image/jpeg' || ii.mime === 'image/png') && (ii.size || 0) > 10000;
      })
      .map(p => ({
        url: p.imageinfo[0].url.split('?')[0],
        title: p.title.replace('File:', '').replace(/\.(jpg|jpeg|png)$/i, '').replace(/_/g, ' '),
      }));
  } catch { return []; }
}

function download(url, dest) {
  try {
    execSync(`curl -s -o "${dest}" --max-time 20 -A "${UA}" -L -e "https://commons.wikimedia.org/" "${url}"`, { timeout: 25000 });
    if (fs.existsSync(dest) && fs.statSync(dest).size > 8000) {
      const fileType = execSync(`file -b "${dest}"`, { encoding: 'utf-8' }).trim();
      if (fileType.includes('JPEG') || fileType.includes('PNG')) return true;
    }
    if (fs.existsSync(dest)) fs.unlinkSync(dest);
    return false;
  } catch { return false; }
}

async function main() {
  const results = {};
  let found = 0;

  for (const p of PERFUMES) {
    process.stdout.write(`[${p.id}] ${p.q.slice(0, 30)}... `);
    const candidates = searchWikimedia(p.q);
    if (candidates.length === 0) {
      console.log('✗ no results');
      continue;
    }
    let saved = false;
    for (const c of candidates.slice(0, 4)) {
      const dest = path.join(OUT_DIR, `${p.id}-real.jpg`);
      if (download(c.url, dest)) {
        results[p.id] = `/perfumes/${p.id}-real.jpg`;
        found++;
        saved = true;
        console.log(`✓ "${c.title.slice(0, 40)}" (${fs.statSync(dest).size} bytes)`);
        break;
      }
      await new Promise(r => setTimeout(r, 300));
    }
    if (!saved) console.log('✗ download failed');
    await new Promise(r => setTimeout(r, 1200)); // Wikimedia rate limit
  }

  fs.writeFileSync('/home/z/my-project/real-brand-images.json', JSON.stringify(results, null, 2));
  console.log(`\n=== SUMMARY: ${found}/${PERFUMES.length} real brand images found ===`);
}

main().catch(console.error);
