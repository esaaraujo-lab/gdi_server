/**
 * Busca imagens reais via Wikipedia PageImages API + Wikimedia Commons.
 * Wikipedia articles têm a foto do frasco no infobox.
 */
import fs from 'fs';
import path from 'path';
import { execSync } from 'child_process';

const OUT_DIR = '/home/z/my-project/public/perfumes';
const UA = 'MimiMimos/1.0 (perfume catalog; contact@mimimimos.com)';

// Mapeia perfume ID -> título do artigo na Wikipedia (inglês)
const PERFUMES = [
  { id: 'bc-001', wiki: 'Allure (Chanel)', commons: 'Allure Homme Sport Chanel bottle' },
  { id: 'bc-002', wiki: 'Burberry London (perfume)', commons: 'Burberry London perfume bottle' },
  { id: 'bc-003', wiki: 'CH (Carolina Herrera)', commons: 'Carolina Herrera CH perfume' },
  { id: 'bc-004', wiki: 'CH Men (Carolina Herrera)', commons: 'CH Men Carolina Herrera' },
  { id: 'bc-005', wiki: '1 Million (Paco Rabanne)', commons: 'Paco Rabanne 1 Million bottle' }, // already have
  { id: 'bc-007', wiki: "J'adore", commons: 'Dior Jadore perfume bottle' },
  { id: 'bc-008', wiki: '212 VIP Men', commons: '212 VIP Men Carolina Herrera' },
  { id: 'bc-010', wiki: 'Black Orchid (Tom Ford)', commons: 'Tom Ford Black Orchid bottle' },
  { id: 'bc-012', wiki: 'La Vie Est Belle', commons: 'La Vie Est Belle Lancome bottle' },
  { id: 'bc-021', wiki: 'Coco Mademoiselle', commons: 'Coco Mademoiselle Chanel bottle' },
  { id: 'bc-027', wiki: 'Hypnotic Poison', commons: 'Hypnotic Poison Dior bottle' },
  { id: 'bc-034', wiki: '212 VIP', commons: '212 VIP Rose Carolina Herrera' },
  { id: 'bc-070', wiki: 'Bleu de Chanel', commons: 'Bleu de Chanel bottle' },
  { id: 'bc-100', wiki: 'Sauvage (fragrance)', commons: 'Sauvage Dior bottle' },
  { id: 'bc-105', wiki: 'Lady Million', commons: 'Lady Million Paco Rabanne bottle' },
  { id: 'bc-116', wiki: 'Invictus (fragrance)', commons: 'Invictus Paco Rabanne bottle' },
  { id: 'bc-126', wiki: 'Good Girl (fragrance)', commons: 'Good Girl Carolina Herrera bottle' },
  { id: 'bc-136', wiki: 'Scandal (fragrance)', commons: 'Scandal Jean Paul Gaultier bottle' },
  { id: 'bc-159', wiki: 'Libre (perfume)', commons: 'Libre YSL perfume bottle' },
  { id: 'bc-181', wiki: 'Bad Boy (fragrance)', commons: 'Bad Boy Carolina Herrera bottle' },
  { id: 'bc-247', wiki: 'Baccarat Rouge 540', commons: 'Baccarat Rouge 540 MFK' },
  { id: 'bc-283', wiki: 'Sauvage Elixir', commons: 'Sauvage Elixir Dior' },
];

function getWikipediaImage(title) {
  try {
    const url = `https://en.wikipedia.org/w/api.php?action=query&titles=${encodeURIComponent(title)}&prop=pageimages&format=json&pithumbsize=600`;
    const out = execSync(`curl -s -A "${UA}" --max-time 10 "${url}"`, { timeout: 15000, encoding: 'utf-8' });
    const data = JSON.parse(out);
    const pages = data.query?.pages || {};
    for (const p of Object.values(pages)) {
      const thumb = p.thumbnail?.source;
      if (thumb) return thumb;
    }
  } catch {}
  return null;
}

function searchWikimedia(query) {
  try {
    const url = `https://commons.wikimedia.org/w/api.php?action=query&generator=search&gsrsearch=${encodeURIComponent(query)}&gsrnamespace=6&prop=imageinfo&iiprop=url|mime|size&format=json&gsrlimit=5`;
    const out = execSync(`curl -s -A "${UA}" --max-time 10 "${url}"`, { timeout: 15000, encoding: 'utf-8' });
    const data = JSON.parse(out);
    const pages = data.query?.pages || {};
    return Object.values(pages)
      .filter(p => {
        const ii = p.imageinfo?.[0];
        return ii && (ii.mime === 'image/jpeg' || ii.mime === 'image/png') && (ii.size || 0) > 15000;
      })
      .map(p => ({
        url: p.imageinfo[0].url.split('?')[0],
        title: p.title.replace('File:', '').replace(/\.(jpg|jpeg|png)$/i, '').replace(/_/g, ' '),
      }));
  } catch { return []; }
}

function download(url, dest) {
  try {
    execSync(`curl -s -o "${dest}" --max-time 20 -A "${UA}" -L -e "https://en.wikipedia.org/" "${url}"`, { timeout: 25000 });
    if (fs.existsSync(dest) && fs.statSync(dest).size > 8000) {
      const fileType = execSync(`file -b "${dest}"`, { encoding: 'utf-8' }).trim();
      if (fileType.includes('JPEG') || fileType.includes('PNG')) return true;
    }
    if (fs.existsSync(dest)) fs.unlinkSync(dest);
    return false;
  } catch { return false; }
}

async function main() {
  // Skip bc-005 which we already have
  const toFetch = PERFUMES.filter(p => !fs.existsSync(path.join(OUT_DIR, `${p.id}-real.jpg`)));
  const results = JSON.parse(fs.readFileSync('/home/z/my-project/real-brand-images.json', 'utf-8').trim() || '{}');
  let found = Object.keys(results).length;

  for (const p of toFetch) {
    process.stdout.write(`[${p.id}] ${p.wiki.slice(0, 25)}... `);
    
    // Method 1: Wikipedia page image
    let saved = false;
    const wikiImg = getWikipediaImage(p.wiki);
    if (wikiImg) {
      const dest = path.join(OUT_DIR, `${p.id}-real.jpg`);
      if (download(wikiImg, dest)) {
        results[p.id] = `/perfumes/${p.id}-real.jpg`;
        found++;
        saved = true;
        console.log(`✓ Wikipedia (${fs.statSync(dest).size} bytes)`);
        await new Promise(r => setTimeout(r, 1000));
        continue;
      }
    }
    
    // Method 2: Wikimedia Commons search
    if (!saved) {
      const candidates = searchWikimedia(p.commons);
      for (const c of candidates.slice(0, 3)) {
        const dest = path.join(OUT_DIR, `${p.id}-real.jpg`);
        if (download(c.url, dest)) {
          results[p.id] = `/perfumes/${p.id}-real.jpg`;
          found++;
          saved = true;
          console.log(`✓ Commons "${c.title.slice(0, 30)}" (${fs.statSync(dest).size} bytes)`);
          break;
        }
        await new Promise(r => setTimeout(r, 300));
      }
    }
    
    if (!saved) console.log('✗ no image found');
    await new Promise(r => setTimeout(r, 1000));
  }

  fs.writeFileSync('/home/z/my-project/real-brand-images.json', JSON.stringify(results, null, 2));
  console.log(`\n=== SUMMARY: ${found}/${PERFUMES.length} real brand images ===`);
}

main().catch(console.error);
