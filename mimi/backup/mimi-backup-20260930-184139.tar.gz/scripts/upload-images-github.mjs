/**
 * Faz upload de arquivos para a pasta mimi/ no repositório gdi_server no GitHub.
 * Usa a GitHub Contents API (cria um commit por arquivo).
 */
import fs from 'fs';
import path from 'path';

const TOKEN = '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';
const REPO = 'esaaraujo-lab/gdi_server';
const BRANCH = 'main';

async function uploadFile(githubPath, localPath, message) {
  const content = fs.readFileSync(localPath);
  const b64 = content.toString('base64');
  // Check if file exists (get SHA for update)
  let sha = null;
  const checkRes = await fetch(`https://api.github.com/repos/${REPO}/contents/${githubPath}?ref=${BRANCH}`, {
    headers: { Authorization: `token ${TOKEN}`, Accept: 'application/vnd.github+json' },
  });
  if (checkRes.ok) {
    const data = await checkRes.json();
    sha = data.sha;
  }
  // Upload
  const res = await fetch(`https://api.github.com/repos/${REPO}/contents/${githubPath}`, {
    method: 'PUT',
    headers: { Authorization: `token ${TOKEN}`, Accept: 'application/vnd.github+json', 'Content-Type': 'application/json' },
    body: JSON.stringify({
      message: message || `mimi: add ${githubPath}`,
      content: b64,
      branch: BRANCH,
      ...(sha ? { sha } : {}),
    }),
  });
  const data = await res.json();
  return { ok: res.ok, sha: data.content?.sha || data.commit?.sha, status: res.status };
}

async function main() {
  const perfumesDir = '/home/z/my-project/public/perfumes';
  const files = fs.readdirSync(perfumesDir).filter(f => f.endsWith('.jpg') || f.endsWith('.png'));
  console.log(`Found ${files.length} perfume images to upload`);

  let uploaded = 0, failed = 0;
  for (const f of files) {
    const localPath = path.join(perfumesDir, f);
    const githubPath = `mimi/perfumes/${f}`;
    process.stdout.write(`[${uploaded + failed + 1}/${files.length}] ${f}... `);
    const result = await uploadFile(githubPath, localPath, `mimi: add perfume image ${f}`);
    if (result.ok) { uploaded++; console.log('✓'); }
    else { failed++; console.log(`✗ (status ${result.status})`); }
    await new Promise(r => setTimeout(r, 300)); // throttle to avoid rate limit
  }
  console.log(`\n=== Images: ${uploaded} uploaded, ${failed} failed ===`);
}

main().catch(console.error);
