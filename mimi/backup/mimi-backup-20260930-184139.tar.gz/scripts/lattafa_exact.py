#!/usr/bin/env python3
"""Map perfumes to Lattafa USA Shopify product by EXACT handle."""
import json, os, subprocess

all_products = []
for page in [1, 2]:
    with open(f"/tmp/lattafa-products-p{page}.json") as f:
        d = json.load(f)
    all_products.extend(d.get("products", []))

by_handle = {p.get("handle", "").lower(): p for p in all_products}

# EXACT handle mapping
EXACT_HANDLE_MAP = {
    # AFEER
    "af-01": "atheeri",
    "af-02": "asad",
    # Decantes
    "dec-02": "asad-zanzibar",
    "dec-03": "qaed-al-fursan",
    "dec-05": "khamrah",
    "dec-10": "badee-al-oud-glory",   # Badee Al Oud (For) Glory
    "dec-12": "al-noble-ameer",
    "dec-17": "tharwah-gold",
    "dec-18": "yara-tous",
    # Try these for missing
    "af-03-try-yara-pink": "yara-pink",         # likely not present
    "af-07-try-fakhar-rose": "fakhar",            # the female "Fakhar" - rose variant?
    "dec-06-try-asad-marrom-bourbon": "asad-bourbon",  # gift set fallback?
    "dec-08-try-dukhan": "dukhan",                 # likely not present
    "dec-14-try-amirat-al-arab": "amirat-al-arab-prive",  # likely not present
    "dec-16-try-fakhar-rose-gold": "fakhar-rose-gold",   # likely not present
}

def check_url(url):
    if not url or not url.startswith("http"):
        return False, "invalid"
    try:
        res = subprocess.run(
            ["curl", "-sIL", "-o", "/dev/null", "-w", "%{http_code}", "--max-time", "20", url],
            capture_output=True, text=True, timeout=25
        )
        code = res.stdout.strip().split('\n')[-1]
        return code == "200", code
    except Exception as e:
        return False, str(e)

results = {}
for pid, handle in EXACT_HANDLE_MAP.items():
    p = by_handle.get(handle)
    if not p:
        print(f"  {pid}: handle '{handle}' NOT in catalog")
        continue
    images = p.get("images", [])
    if not images:
        print(f"  {pid}: '{p.get('title')}' has NO images")
        continue
    img = images[0].get("src", "")
    ok, code = check_url(img)
    if ok:
        print(f"  {pid}: '{p.get('title')}' -> {img}  [200 OK]")
        if not pid.endswith("-try"):
            results[pid] = img
    else:
        print(f"  {pid}: '{p.get('title')}' -> {img}  [{code}]")

print("\n=== FINAL ===")
for k, v in results.items():
    print(f"  {k}: {v}")
print(f"Total confirmed: {len(results)}")
os.makedirs("/home/z/my-project/scripts/tmp", exist_ok=True)
with open("/home/z/my-project/scripts/tmp/lattafa-exact.json", "w") as f:
    json.dump(results, f, indent=2)
