// Generate remaining luxury images (hero, og-cover, icons) for Mimi Mimos
import ZAI from 'z-ai-web-dev-sdk';
import fs from 'fs';
import path from 'path';
import sharp from 'sharp';

const PUBLIC_DIR = '/home/z/my-project/public';
const TMP_DIR = '/home/z/my-project/scripts/tmp';

fs.mkdirSync(TMP_DIR, { recursive: true });

const LUX_STYLE = 'ultra-luxurious editorial product photography, high-end parfumerie catalog, dramatic cinematic lighting, soft golden rim light, fine art still life, ultra-detailed, photorealistic, 8k, depth of field, reflective polished black surface';

// Use 1344x768 (supported, multiple of 32) for hero & og-cover.
// Use 1024x1024 for icons.
const IMAGE_JOBS = [
  {
    name: 'hero-ambient.jpg',
    size: '1344x768',
    final: { format: 'jpg', quality: 92 },
    prompt: `Atmospheric luxury perfume scene, single elegant 25ml glass perfume bottle floating in center, dark obsidian black background with dramatic golden light beams piercing through, swirling golden mist and floating glittering particles, soft volumetric god rays, ultra-luxurious editorial photography, cinematic mood, depth of field, reflective polished black marble surface, elegant and mysterious, high-end parfumerie brand campaign aesthetic, gold and obsidian color palette, ${LUX_STYLE}`,
  },
  {
    name: 'og-cover.jpg',
    size: '1344x768',
    final: { format: 'jpg', quality: 92 },
    prompt: `Luxury social share cover image, single elegant 25ml glass perfume bottle with gold accents centered on obsidian black background, refined golden light glow around the bottle, sophisticated minimal composition with elegant empty space around the bottle, gold dust particles floating, ultra-luxurious parfumerie branding aesthetic, high-end editorial photography, gold and obsidian black color palette, symmetrical centered composition, ${LUX_STYLE}`,
  },
  {
    name: 'icon-512.png',
    size: '1024x1024',
    final: { format: 'png', resize: { width: 512, height: 512 } },
    prompt: `Luxury app icon design, single elegant gold letter "M" monogram centered, polished obsidian solid black background, brushed gold metallic letterform with subtle gradient shine, minimalist premium luxury branding, elegant serif-style capital letter M, subtle golden outer glow, geometric circular gold ring border framing the letter, ultra-clean centered composition, no text other than the letter M`,
  },
  {
    name: 'icon-192.png',
    size: '1024x1024',
    final: { format: 'png', resize: { width: 192, height: 192 } },
    prompt: `Luxury app icon design, single elegant gold letter "M" monogram centered, polished obsidian solid black background, brushed gold metallic letterform with subtle gradient shine, minimalist premium luxury branding, elegant serif-style capital letter M, subtle golden outer glow, geometric circular gold ring border framing the letter, ultra-clean centered composition, no text other than the letter M`,
  },
  {
    name: 'apple-touch-icon.png',
    size: '1024x1024',
    final: { format: 'png', resize: { width: 180, height: 180 }, flatten: true },
    prompt: `Luxury iOS app icon design, single elegant gold letter "M" monogram centered, solid opaque obsidian black square background with no transparency, brushed gold metallic letterform with subtle gradient shine, minimalist premium luxury branding, elegant serif-style capital letter M, subtle golden outer glow, geometric circular gold ring border framing the letter, ultra-clean centered composition, no text other than the letter M, fully opaque solid background`,
  },
];

const MAX_RETRIES = 4;

async function generateOne(zai, job, attempt = 1) {
  const tmpPng = path.join(TMP_DIR, job.name + '.raw.png');
  try {
    console.log(`▶ [${attempt}/${MAX_RETRIES}] Generating: ${job.name} (${job.size})`);
    const response = await zai.images.generations.create({
      prompt: job.prompt,
      size: job.size,
    });
    if (!response?.data?.[0]?.base64) {
      throw new Error('Invalid response from API (no base64)');
    }
    const buffer = Buffer.from(response.data[0].base64, 'base64');
    fs.writeFileSync(tmpPng, buffer);
    console.log(`  ✓ Raw PNG saved (${buffer.length} bytes)`);

    const outPath = path.join(PUBLIC_DIR, job.name);
    let img = sharp(tmpPng, { failOn: 'none' });
    if (job.final.resize) {
      img = img.resize({
        width: job.final.resize.width,
        height: job.final.resize.height,
        fit: 'cover',
        position: 'center',
      });
    }
    if (job.final.flatten) {
      img = img.flatten({ background: '#000000' });
    }
    if (job.final.format === 'jpg') {
      img = img.jpeg({ quality: job.final.quality || 90, mozjpeg: true, chromaSubsampling: '4:4:4' });
    } else {
      img = img.png({ compressionLevel: 9, quality: 90 });
    }
    await img.toFile(outPath);
    const stat = fs.statSync(outPath);
    console.log(`  ✓ Saved: ${outPath} (${stat.size} bytes)`);
    fs.unlinkSync(tmpPng);
    return { success: true, name: job.name, path: outPath, bytes: stat.size };
  } catch (err) {
    console.error(`  ✗ Error on ${job.name}: ${err.message}`);
    if (fs.existsSync(tmpPng)) { try { fs.unlinkSync(tmpPng); } catch {} }
    if (attempt < MAX_RETRIES) {
      const wait = 3000 * attempt;
      console.log(`  ↻ Retrying in ${wait / 1000}s...`);
      await new Promise(r => setTimeout(r, wait));
      return generateOne(zai, job, attempt + 1);
    }
    return { success: false, name: job.name, error: err.message };
  }
}

async function main() {
  console.log('Initializing Z-AI SDK...');
  const zai = await ZAI.create();
  console.log(`Will process ${IMAGE_JOBS.length} remaining image jobs.\n`);

  const results = [];
  for (const job of IMAGE_JOBS) {
    const r = await generateOne(zai, job);
    results.push(r);
    await new Promise(res => setTimeout(res, 800));
  }

  console.log('\n========== SUMMARY ==========');
  for (const r of results) {
    if (r.success) {
      console.log(`  ✓ ${r.name} → ${r.path} (${r.bytes} bytes)`);
    } else {
      console.log(`  ✗ ${r.name} → FAILED: ${r.error}`);
    }
  }
  fs.writeFileSync(
    path.join(TMP_DIR, 'results-remaining.json'),
    JSON.stringify(results, null, 2)
  );
  const failed = results.filter(r => !r.success).length;
  process.exit(failed > 0 ? 1 : 0);
}

main().catch(err => {
  console.error('Fatal:', err);
  process.exit(1);
});
