// Generate a subset of perfume images — pass start/end indices as args.
// Usage: node scripts/generate-task16-batch.mjs <startIdx> <endIdx>
// Indices are inclusive. Skips images that already exist.
import ZAI from 'z-ai-web-dev-sdk';
import fs from 'fs';
import path from 'path';
import sharp from 'sharp';

const OUT_DIR = '/home/z/my-project/public/perfumes';
const TMP_DIR = '/home/z/my-project/scripts/tmp';
fs.mkdirSync(OUT_DIR, { recursive: true });
fs.mkdirSync(TMP_DIR, { recursive: true });

const LUX_STYLE =
  'ultra-luxurious editorial product photography, high-end parfumerie catalog, dramatic cinematic lighting, soft golden rim light, fine art still life, ultra-detailed, photorealistic, 8k, depth of field, reflective polished black obsidian surface, luxury gold accents';
const BG = 'pure obsidian solid black background, deep matte black, no other objects';

const JOBS = [
  { id: 'af-01', name: 'Afeer Atheeri', prompt: `Realistic product photograph of a small 20ml miniature Arabic luxury perfume bottle, ornate Arabian design with golden honey amber tones, warm honey-colored liquid inside, intricate gold filigree cap with oriental arabesque patterns, faceted crystal glass body, inspired by Lattafa Atheeri, ${BG}, single bottle centered, ${LUX_STYLE}` },
  { id: 'af-02', name: 'Afeer Asad', prompt: `Realistic product photograph of a small 20ml miniature Arabic luxury perfume bottle, dark black bold masculine design with silver and black tones, square heavy glass body, ornate dark metallic cap with lion motif engraving, deep amber liquid, inspired by Lattafa Asad, ${BG}, single bottle centered, ${LUX_STYLE}` },
  { id: 'af-03', name: 'Afeer Yara Pink', prompt: `Realistic product photograph of a small 20ml miniature Arabic luxury perfume bottle, pink and magenta gradient glass, feminine ornate design, gold accents on cap, faceted crystal body with floral arabesque engravings, pink-tinted liquid, inspired by Lattafa Yara Pink, ${BG}, single bottle centered, ${LUX_STYLE}` },
  { id: 'af-04', name: 'Afeer Royal Amber', prompt: `Realistic product photograph of a small 20ml miniature Arabic luxury perfume bottle, golden amber tones, royal oriental ornate design, tall faceted crystal glass body with amber liquid, ornate gold crown-shaped cap with arabesque details, inspired by Orientica Royal Amber, ${BG}, single bottle centered, ${LUX_STYLE}` },
  { id: 'af-07', name: 'Afeer Fakhar Rose', prompt: `Realistic product photograph of a small 20ml miniature Arabic luxury perfume bottle, deep rose and pink tones, floral ornate design, elegant faceted crystal body with rose-pink liquid, gold detailing on cap with rose motif engraving, inspired by Lattafa Fakhar Rose, ${BG}, single bottle centered, ${LUX_STYLE}` },
  { id: 'bc-003', name: 'CH Red Woman', prompt: `Realistic product photograph of an elegant round feminine luxury perfume bottle, warm red color tones, smooth spherical glass body with red-tinted liquid, gold metallic cap, inspired by Carolina Herrera CH Women, ${BG}, single bottle centered, ${LUX_STYLE}` },
  { id: 'bc-004', name: 'CH Men Leather', prompt: `Realistic product photograph of a masculine rectangular luxury perfume bottle with brown leather texture, dark brown leather-look panels on glass body, silver metallic cap, amber liquid inside, inspired by Carolina Herrera CH Men, ${BG}, single bottle centered, ${LUX_STYLE}` },
  { id: 'bc-005', name: 'Gold 1 Million', prompt: `Realistic product photograph of a masculine luxury perfume bottle shaped like a shiny gold ingot or gold bar, polished metallic gold rectangular body with embossed engravings, dark grey cap, gold liquid inside, inspired by Paco Rabanne 1 Million, ${BG}, single bottle centered, ${LUX_STYLE}` },
  { id: 'bc-007', name: 'I Love J\'adore', prompt: `Realistic product photograph of an elegant tall feminine luxury perfume bottle with a long slender neck, golden amber tones, clear glass body with golden amber liquid, gold metallic cap, sophisticated feminine silhouette, inspired by Dior J\'adore, ${BG}, single bottle centered, ${LUX_STYLE}` },
  { id: 'bc-008', name: 'VIP Men 212', prompt: `Realistic product photograph of a masculine cylindrical luxury perfume bottle with silver and dark tones, brushed silver metal body, dark grey cap, clear liquid with silver tint, inspired by Carolina Herrera 212 VIP Men, ${BG}, single bottle centered, ${LUX_STYLE}` },
  { id: 'bc-010', name: 'Black Orchid Velvet', prompt: `Realistic product photograph of a feminine luxury perfume bottle with black elegant design, rectangular black faceted glass body, black glossy cap with gold accents, dark tinted liquid, inspired by Tom Ford Black Orchid, ${BG}, single bottle centered, ${LUX_STYLE}` },
  { id: 'bc-021', name: 'Coco Mademoiselle', prompt: `Realistic product photograph of a feminine luxury perfume bottle with classic elegant rectangular design, clear crystal glass body with pale amber liquid, flat transparent cap with black accent, minimalist Chanel-style aesthetic, inspired by Chanel Coco Mademoiselle, ${BG}, single bottle centered, ${LUX_STYLE}` },
  { id: 'bc-027', name: 'Hypnotic Poison Apple', prompt: `Realistic product photograph of a feminine luxury perfume bottle shaped like a round red apple, deep ruby red glass body, small black cap on top, dark red liquid, mysterious sensual feminine aesthetic, inspired by Dior Hypnotic Poison, ${BG}, single bottle centered, ${LUX_STYLE}` },
  { id: 'bc-070', name: 'Bleu Ocean Deep', prompt: `Realistic product photograph of a masculine luxury perfume bottle with deep blue tones, dark navy blue rectangular glass body with magnetic silver cap, dark blue liquid, sophisticated woody aromatic aesthetic, inspired by Chanel Bleu de Chanel, ${BG}, single bottle centered, ${LUX_STYLE}` },
  { id: 'bc-100', name: 'Sauvage Dior', prompt: `Realistic product photograph of a masculine luxury perfume bottle with dark blue and grey tones, dark cylindrical glass body with magnetic silver cap, dark blue tinted liquid, minimalist sophisticated masculine aesthetic, inspired by Dior Sauvage, ${BG}, single bottle centered, ${LUX_STYLE}` },
  { id: 'bc-105', name: 'Lady Diamond Million', prompt: `Realistic product photograph of a feminine luxury perfume bottle shaped like a diamond, faceted gold metallic body with diamond-cut crystal pattern, gold hexagonal cap, golden liquid inside, glamorous feminine aesthetic, inspired by Paco Rabanne Lady Million, ${BG}, single bottle centered, ${LUX_STYLE}` },
  { id: 'bc-116', name: 'Invictus Trophy', prompt: `Realistic product photograph of a masculine luxury perfume bottle shaped like a silver trophy or championship cup, silver metallic trophy-shaped body with glass bowl, silver cap, blue-tinted liquid inside, sporty masculine aesthetic, inspired by Paco Rabanne Invictus, ${BG}, single bottle centered, ${LUX_STYLE}` },
  { id: 'bc-126', name: 'Good Girl Stiletto', prompt: `Realistic product photograph of a feminine luxury perfume bottle shaped like a tall stiletto high heel shoe, sleek black and gold design, glass stiletto heel body with black liquid, gold accents, dramatic feminine silhouette, inspired by Carolina Herrera Good Girl, ${BG}, single bottle centered, ${LUX_STYLE}` },
  { id: 'bc-136', name: 'Scandal Honey', prompt: `Realistic product photograph of a feminine luxury perfume bottle with honey amber tones, curved glass body shaped like a female torso silhouette, gold cap crown, golden honey liquid inside, elegant feminine aesthetic, inspired by Jean Paul Gaultier Scandal, ${BG}, single bottle centered, ${LUX_STYLE}` },
  { id: 'bc-159', name: 'Libre Couture', prompt: `Realistic product photograph of a feminine luxury perfume bottle with amber and gold tones, square transparent glass body with sharp corners, gold cap, gold liquid inside, elegant minimalist feminine aesthetic, inspired by YSL Libre, ${BG}, single bottle centered, ${LUX_STYLE}` },
  { id: 'bc-181', name: 'Bad Boy Lightning', prompt: `Realistic product photograph of a masculine luxury perfume bottle with dark bold design, dark glass lightning bolt shaped body, black and silver cap, lightning bolt motif embossed, dark blue liquid, edgy masculine aesthetic, inspired by Carolina Herrera Bad Boy, ${BG}, single bottle centered, ${LUX_STYLE}` },
  { id: 'bc-247', name: 'Baccarat Rouge 540', prompt: `Realistic product photograph of an unisex luxury perfume bottle with crimson red and gold tones, elegant faceted crystal glass body with red-tinted liquid, gold cap, sophisticated minimal luxury aesthetic, inspired by Maison Francis Kurkdjian Baccarat Rouge 540, ${BG}, single bottle centered, ${LUX_STYLE}` },
  { id: 'bc-283', name: 'Sauvage Elixir', prompt: `Realistic product photograph of a masculine luxury perfume bottle with dark purple and amber tones, dark cylindrical glass body with deep purple tinted liquid, black cap, sophisticated apothecary-style label, inspired by Dior Sauvage Elixir, ${BG}, single bottle centered, ${LUX_STYLE}` },
  { id: 'dec-01', name: 'Decante Khamrah', prompt: `Realistic product photograph of a small 5ml perfume decant sample atomizer spray bottle, miniature cylindrical glass vial with cinnamon amber colored liquid, gold spray cap, Arabic luxury design inspired by Lattafa Khamrah, tiny sample travel atomizer, ${BG}, single bottle centered, ${LUX_STYLE}` },
  { id: 'dec-02', name: 'Decante Delina', prompt: `Realistic product photograph of a small 5ml perfume decant sample atomizer spray bottle, miniature cylindrical glass vial with pink rose colored liquid, silver spray cap, feminine floral luxury design inspired by Parfums de Marly Delina, tiny sample travel atomizer, ${BG}, single bottle centered, ${LUX_STYLE}` },
  { id: 'dec-03', name: 'Decante Angels Share', prompt: `Realistic product photograph of a small 5ml perfume decant sample atomizer spray bottle, miniature cylindrical glass vial with cognac amber colored liquid, gold spray cap, gourmand luxury design inspired by Kilian Angels Share, tiny sample travel atomizer, ${BG}, single bottle centered, ${LUX_STYLE}` },
  { id: 'dec-04', name: 'Decante Baccarat', prompt: `Realistic product photograph of a small 5ml perfume decant sample atomizer spray bottle, miniature cylindrical glass vial with crimson red colored liquid, gold spray cap, luxury unisex design inspired by Maison Francis Kurkdjian Baccarat Rouge 540, tiny sample travel atomizer, ${BG}, single bottle centered, ${LUX_STYLE}` },
];

const MAX_RETRIES = 4;
const startIdx = parseInt(process.argv[2] ?? '0', 10);
const endIdx = parseInt(process.argv[3] ?? String(JOBS.length - 1), 10);

function exists(id) {
  const p = path.join(OUT_DIR, `${id}.jpg`);
  if (!fs.existsSync(p)) return false;
  const s = fs.statSync(p);
  return s.size > 5000;
}

async function generateOne(zai, job, attempt = 1) {
  const tmpPng = path.join(TMP_DIR, `${job.id}.raw.png`);
  try {
    console.log(`▶ [${attempt}/${MAX_RETRIES}] ${job.id} — ${job.name}`);
    const response = await zai.images.generations.create({
      prompt: job.prompt,
      size: '1024x1024',
    });
    if (!response?.data?.[0]?.base64) {
      throw new Error('Invalid response from API (no base64)');
    }
    const buffer = Buffer.from(response.data[0].base64, 'base64');
    fs.writeFileSync(tmpPng, buffer);

    const outPath = path.join(OUT_DIR, `${job.id}.jpg`);
    await sharp(tmpPng, { failOn: 'none' })
      .resize({ width: 1024, height: 1024, fit: 'cover', position: 'center' })
      .jpeg({ quality: 92, mozjpeg: true, chromaSubsampling: '4:4:4' })
      .toFile(outPath);
    const stat = fs.statSync(outPath);
    console.log(`  ✓ ${job.id}.jpg (${stat.size} bytes)`);
    fs.unlinkSync(tmpPng);
    return { success: true, id: job.id, name: job.name, path: outPath, bytes: stat.size };
  } catch (err) {
    console.error(`  ✗ ${job.id}: ${err.message}`);
    if (fs.existsSync(tmpPng)) { try { fs.unlinkSync(tmpPng); } catch {} }
    if (attempt < MAX_RETRIES) {
      const wait = 2500 * attempt;
      console.log(`  ↻ retry in ${wait / 1000}s...`);
      await new Promise(r => setTimeout(r, wait));
      return generateOne(zai, job, attempt + 1);
    }
    return { success: false, id: job.id, name: job.name, error: err.message };
  }
}

async function main() {
  const range = JOBS.slice(startIdx, endIdx + 1);
  const pending = range.filter(j => !exists(j.id));
  const done = range.filter(j => exists(j.id));
  console.log(`Range [${startIdx}..${endIdx}] → ${range.length} jobs | already done: ${done.length} | pending: ${pending.length}`);
  done.forEach(d => console.log(`  ✓ ${d.id}.jpg already exists`));

  console.log('Initializing Z-AI SDK...');
  const zai = await ZAI.create();

  const results = [];
  for (const job of pending) {
    const r = await generateOne(zai, job);
    results.push(r);
    await new Promise(res => setTimeout(res, 400));
  }

  console.log('\n========== BATCH SUMMARY ==========');
  const ok = [], fail = [];
  for (const r of results) {
    if (r.success) {
      console.log(`  ✓ ${r.id}.jpg → ${r.path} (${r.bytes} bytes)`);
      ok.push(r);
    } else {
      console.log(`  ✗ ${r.id} FAILED: ${r.error}`);
      fail.push(r);
    }
  }
  console.log(`Generated this batch: ${ok.length} | Failed: ${fail.length}`);
  process.exit(fail.length > 0 ? 1 : 0);
}

main().catch(err => {
  console.error('Fatal:', err);
  process.exit(1);
});
