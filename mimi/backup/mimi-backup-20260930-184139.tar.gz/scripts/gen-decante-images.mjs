/**
 * Gera imagens de decantes (5ml atomizers) com cores por gênero:
 * - Feminino: rosa/roxo/vermelho
 * - Masculino: preto/azul
 * - Unissex/Árabe: neutros (âmbar/dourado/bege)
 */
import ZAI from 'z-ai-web-dev-sdk';
import fs from 'fs';
import sharp from 'sharp';

const OUT_DIR = '/home/z/my-project/public/perfumes';
const BG = 'obsidian black background #090a0f, dramatic editorial lighting, gold accents';

const DECANTES = [
  // Feminino (rosa/roxo/vermelho)
  { file: 'dec-fem-01.jpg', prompt: `Small 5ml perfume decante atomizer spray bottle with PINK rose-colored liquid, elegant feminine rose-themed glass bottle with gold spray cap, ${BG}, luxury parfumerie product photo, 1024x1024` },
  { file: 'dec-fem-02.jpg', prompt: `Small 5ml perfume decante atomizer spray bottle with PURPLE violet liquid, elegant feminine glass bottle with gold accents, ${BG}, luxury parfumerie product photo, 1024x1024` },
  { file: 'dec-fem-03.jpg', prompt: `Small 5ml perfume decante atomizer spray bottle with RED crimson liquid, sensual feminine glass bottle with gold cap, ${BG}, luxury parfumerie product photo, 1024x1024` },
  { file: 'dec-fem-04.jpg', prompt: `Small 5ml perfume decante atomizer spray bottle with ROSE-GOLD liquid, floral feminine ornate bottle with gold details, ${BG}, luxury parfumerie product photo, 1024x1024` },
  { file: 'dec-fem-05.jpg', prompt: `Small 5ml perfume decante atomizer spray bottle with MAGENTA liquid, ornate feminine bottle with gold cap, ${BG}, luxury parfumerie product photo, 1024x1024` },
  { file: 'dec-fem-06.jpg', prompt: `Small 5ml perfume decante atomizer spray bottle with PINK CHAMPAGNE sparkling liquid, elegant feminine bottle with gold, ${BG}, luxury product photo, 1024x1024` },
  // Masculino (preto/azul)
  { file: 'dec-masc-01.jpg', prompt: `Small 5ml perfume decante atomizer spray bottle with BLACK liquid, bold dark masculine glass bottle with gold cap, ${BG}, luxury parfumerie product photo, 1024x1024` },
  { file: 'dec-masc-02.jpg', prompt: `Small 5ml perfume decante atomizer spray bottle with DEEP BLUE navy liquid, masculine sleek glass bottle with gold cap, ${BG}, luxury product photo, 1024x1024` },
  { file: 'dec-masc-03.jpg', prompt: `Small 5ml perfume decante atomizer spray bottle with DARK GREY charcoal liquid, steel masculine bottle with gold cap, ${BG}, luxury product photo, 1024x1024` },
  { file: 'dec-masc-04.jpg', prompt: `Small 5ml perfume decante atomizer spray bottle with MIDNIGHT BLUE liquid, sleek masculine bottle with gold details, ${BG}, luxury product photo, 1024x1024` },
  // Unissex/Árabe (neutros)
  { file: 'dec-uni-01.jpg', prompt: `Small 5ml perfume decante atomizer spray bottle with AMBER liquid, ornate Arabian unisex glass bottle with gold cap, ${BG}, luxury parfumerie product photo, 1024x1024` },
  { file: 'dec-uni-02.jpg', prompt: `Small 5ml perfume decante atomizer spray bottle with GOLDEN liquid, luxury unisex glass bottle with gold cap, ${BG}, luxury product photo, 1024x1024` },
  { file: 'dec-uni-03.jpg', prompt: `Small 5ml perfume decante atomizer spray bottle with WARM BROWN liquid, oriental unisex bottle with gold cap, ${BG}, luxury product photo, 1024x1024` },
  { file: 'dec-uni-04.jpg', prompt: `Small 5ml perfume decante atomizer spray bottle with BEIGE cream liquid, minimalist unisex bottle with gold cap, ${BG}, luxury product photo, 1024x1024` },
];

async function main() {
  const zai = await ZAI.create();
  if (!fs.existsSync(OUT_DIR)) fs.mkdirSync(OUT_DIR, { recursive: true });
  let ok = 0, fail = 0;
  for (const d of DECANTES) {
    const outPath = `${OUT_DIR}/${d.file}`;
    if (fs.existsSync(outPath)) { console.log(`[skip] ${d.file} already exists`); ok++; continue; }
    process.stdout.write(`[gen] ${d.file}... `);
    try {
      const response = await zai.images.generations.create({
        prompt: d.prompt,
        size: '1024x1024',
      });
      const b64 = response.data[0].base64;
      const pngBuf = Buffer.from(b64, 'base64');
      // Convert to JPG via sharp
      const jpgBuf = await sharp(pngBuf).jpeg({ quality: 92, mozjpeg: true }).toBuffer();
      fs.writeFileSync(outPath, jpgBuf);
      console.log(`✓ (${(jpgBuf.length/1024).toFixed(0)}KB)`);
      ok++;
    } catch (e) {
      console.log(`✗ ${e.message?.slice(0, 80)}`);
      fail++;
    }
    await new Promise(r => setTimeout(r, 1500));
  }
  console.log(`\n=== SUMMARY: ${ok} generated, ${fail} failed ===`);
}

main().catch(console.error);
