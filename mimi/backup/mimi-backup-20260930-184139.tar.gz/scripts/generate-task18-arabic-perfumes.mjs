// Task ID 18 — Generate 10 Arabic perfume images for Mimi Mimos catalog
// 5 decanters (5ml atomizer spray samples) + 5 full-size ornate bottles
// All 1024x1024 jpg q=92, consistent dark obsidian + gold luxury aesthetic.
//
// Usage: node scripts/generate-task18-arabic-perfumes.mjs
import ZAI from 'z-ai-web-dev-sdk';
import fs from 'fs';
import path from 'path';
import sharp from 'sharp';

const OUT_DIR = '/home/z/my-project/public/perfumes';
const TMP_DIR = '/home/z/my-project/scripts/tmp';
fs.mkdirSync(OUT_DIR, { recursive: true });
fs.mkdirSync(TMP_DIR, { recursive: true });

const LUX_STYLE =
  'ultra-luxurious editorial product photography, high-end parfumerie catalog, dramatic cinematic lighting, soft golden rim light, fine art still life, ultra-detailed, photorealistic, 8k, depth of field, reflective polished black obsidian surface, luxury gold accents';
const BG = 'pure obsidian solid black background, deep matte black, no other objects, no text, no labels with text';

// 5ml atomizer decant description (consistent across dec-01..05)
const DECANT_BODY =
  'a small 5ml miniature perfume decant sample atomizer spray bottle, slim cylindrical glass vial about 7cm tall, slender travel atomizer size, small gold metallic spray nozzle cap on top, fine mist pump, tiny pocket-size sample bottle, NOT a full size bottle, proportions of a small tester sample';

const JOBS = [
  // ── DECANTES (5ml atomizer spray samples) ──────────────────────────────
  {
    id: 'dec-01',
    name: 'Khamrah (Lattafa) decante',
    prompt: `Realistic product photograph of ${DECANT_BODY}, filled with warm cinnamon amber colored liquid, golden amber honey tones inside, subtle Arabian ornate gold filigree band at the neck, inspired by Lattafa Khamrah sweet cinnamon date praline gourmand, ${BG}, single bottle centered vertical composition, ${LUX_STYLE}`,
  },
  {
    id: 'dec-02',
    name: 'Qaed Al Fursan (Lattafa) decante',
    prompt: `Realistic product photograph of ${DECANT_BODY}, filled with golden tropical pineapple colored liquid, warm sunny golden tones inside, subtle dark gold metallic accent ring, inspired by Lattafa Qaed Al Fursan tropical pineapple with smoky depth, ${BG}, single bottle centered vertical composition, ${LUX_STYLE}`,
  },
  {
    id: 'dec-03',
    name: 'Asad Zanzibar (Lattafa) decante',
    prompt: `Realistic product photograph of ${DECANT_BODY}, filled with fresh blue aquatic colored liquid, marine blue and sea-salt tones inside, subtle cool blue tint, inspired by Lattafa Asad Zanzibar coconut sea salt pepper fresh marine aquatic, ${BG}, single bottle centered vertical composition, ${LUX_STYLE}`,
  },
  {
    id: 'dec-04',
    name: 'Bareeq Al Dahab (Al Wataniah) decante',
    prompt: `Realistic product photograph of ${DECANT_BODY}, filled with luminous amber gold colored liquid, radiant glowing golden tones inside, subtle ornate gold accent ring, inspired by Al Wataniah Bareeq Al Dahab ambery luminous versatile oriental, ${BG}, single bottle centered vertical composition, ${LUX_STYLE}`,
  },
  {
    id: 'dec-05',
    name: 'Royal Blend Nero (Maison Alhambra) decante',
    prompt: `Realistic product photograph of ${DECANT_BODY}, filled with dark black deep liquor colored liquid, almost opaque dark brownish black liquid inside, sleek black matte spray cap with subtle gold accent, inspired by Maison Alhambra Royal Blend Nero liquor vanilla woody dark mysterious, ${BG}, single bottle centered vertical composition, ${LUX_STYLE}`,
  },

  // ── FULL-SIZE ORNATE BOTTLES ───────────────────────────────────────────
  {
    id: 'af-khamrah',
    name: 'Khamrah (Lattafa) full bottle',
    prompt: `Realistic product photograph of a large ornate Arabian luxury perfume bottle, full size 100ml bottle, warm amber copper and golden tones, ornate decorative faceted crystal glass body with intricate oriental arabesque engravings, decorative gold metallic cap with carved Arabian motif, sweet cinnamon and dates gourmand amber liquid inside, inspired by Lattafa Khamrah, ${BG}, single bottle centered vertical composition, ${LUX_STYLE}`,
  },
  {
    id: 'af-qaed-fursan',
    name: 'Qaed Al Fursan (Lattafa) full bottle',
    prompt: `Realistic product photograph of a large elegant Arabian luxury perfume bottle, full size 100ml bottle, dark elegant glass body with rich gold accents, royal masculine ornate design, faceted rectangular crystal glass body, ornate gold metallic cap with embossed Arabian knight motif, warm tropical golden amber liquid inside, inspired by Lattafa Qaed Al Fursan tropical pineapple smoky depth, ${BG}, single bottle centered vertical composition, ${LUX_STYLE}`,
  },
  {
    id: 'af-asad-zanzibar',
    name: 'Asad Zanzibar (Lattafa) full bottle',
    prompt: `Realistic product photograph of a large bold Arabian luxury perfume bottle, full size 100ml bottle, bold dark glass body with vivid blue aquatic accents, ornate dark metallic Arabian cap with embossed lion motif, fresh marine blue tinted liquid inside, masculine fresh aquatic design, inspired by Lattafa Asad Zanzibar coconut sea salt pepper marine, ${BG}, single bottle centered vertical composition, ${LUX_STYLE}`,
  },
  {
    id: 'af-bareeq-dahab',
    name: 'Bareeq Al Dahab (Al Wataniah) full bottle',
    prompt: `Realistic product photograph of a large ornate Arabian luxury perfume bottle, full size 100ml bottle, luminous amber and gold radiant tones, radiant oriental design, faceted crystal glass body with luminous golden glow, ornate gold metallic cap with carved arabesque floral motif, glowing luminous amber gold liquid inside, inspired by Al Wataniah Bareeq Al Dahab ambery luminous versatile oriental, ${BG}, single bottle centered vertical composition, ${LUX_STYLE}`,
  },
  {
    id: 'af-royal-nero',
    name: 'Royal Blend Nero (Maison Alhambra) full bottle',
    prompt: `Realistic product photograph of a large dark Arabian luxury perfume bottle, full size 100ml bottle, dark black glass body with rich gold accents, mysterious luxury design, faceted crystal glass body with deep dark tinted liquid, ornate gold metallic cap with subtle engraved details, almost opaque dark liquor vanilla liquid inside, inspired by Maison Alhambra Royal Blend Nero liquor vanilla woody dark mysterious, ${BG}, single bottle centered vertical composition, ${LUX_STYLE}`,
  },
];

const MAX_RETRIES = 4;

function exists(id) {
  const p = path.join(OUT_DIR, `${id}.jpg`);
  if (!fs.existsSync(p)) return false;
  const s = fs.statSync(p);
  return s.size > 5000;
}

async function generateOne(zai, job, attempt = 1) {
  const tmpPng = path.join(TMP_DIR, `${job.id}.raw.png`);
  try {
    console.log(`▶ [${attempt}/${MAX_RETRIES}] ${job.id} — ${job.name}`);
    const response = await zai.images.generations.create({
      prompt: job.prompt,
      size: '1024x1024',
    });
    if (!response?.data?.[0]?.base64) {
      throw new Error('Invalid response from API (no base64)');
    }
    const buffer = Buffer.from(response.data[0].base64, 'base64');
    fs.writeFileSync(tmpPng, buffer);

    const outPath = path.join(OUT_DIR, `${job.id}.jpg`);
    await sharp(tmpPng, { failOn: 'none' })
      .resize({ width: 1024, height: 1024, fit: 'cover', position: 'center' })
      .jpeg({ quality: 92, mozjpeg: true, chromaSubsampling: '4:4:4' })
      .toFile(outPath);
    const stat = fs.statSync(outPath);
    console.log(`  ✓ ${job.id}.jpg (${stat.size} bytes)`);
    fs.unlinkSync(tmpPng);
    return { success: true, id: job.id, name: job.name, path: outPath, bytes: stat.size };
  } catch (err) {
    console.error(`  ✗ ${job.id}: ${err.message}`);
    if (fs.existsSync(tmpPng)) { try { fs.unlinkSync(tmpPng); } catch {} }
    if (attempt < MAX_RETRIES) {
      const wait = 2500 * attempt;
      console.log(`  ↻ retry in ${wait / 1000}s...`);
      await new Promise(r => setTimeout(r, wait));
      return generateOne(zai, job, attempt + 1);
    }
    return { success: false, id: job.id, name: job.name, error: err.message };
  }
}

async function main() {
  const pending = JOBS.filter(j => !exists(j.id));
  const done = JOBS.filter(j => exists(j.id));
  console.log(`Total jobs: ${JOBS.length} | already done: ${done.length} | pending: ${pending.length}`);
  done.forEach(d => console.log(`  ✓ ${d.id}.jpg already exists`));

  if (pending.length === 0) {
    console.log('Nothing to do.');
    return;
  }

  console.log('\nInitializing Z-AI SDK...');
  const zai = await ZAI.create();

  const results = [];
  for (const job of pending) {
    const r = await generateOne(zai, job);
    results.push(r);
    await new Promise(res => setTimeout(res, 400));
  }

  console.log('\n========== BATCH SUMMARY ==========');
  const ok = [], fail = [];
  for (const r of results) {
    if (r.success) {
      console.log(`  ✓ ${r.id}.jpg → ${r.path} (${r.bytes} bytes)`);
      ok.push(r);
    } else {
      console.log(`  ✗ ${r.id} FAILED: ${r.error}`);
      fail.push(r);
    }
  }
  console.log(`Generated: ${ok.length} | Failed: ${fail.length}`);

  // Write machine-readable summary for downstream tooling
  const summaryPath = path.join(TMP_DIR, 'task18-summary.json');
  fs.writeFileSync(summaryPath, JSON.stringify({ ok, fail }, null, 2));
  console.log(`Summary JSON: ${summaryPath}`);

  process.exit(fail.length > 0 ? 1 : 0);
}

main().catch(err => {
  console.error('Fatal:', err);
  process.exit(1);
});
