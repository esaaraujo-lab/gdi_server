/**
 * Busca imagens reais de perfumes via Bing Images (thumbnails em tse3.mm.bing.net).
 * Funciona: o page_reader retorna o HTML do Bing com os thumbnail IDs,
 * e os thumbnails são baixáveis via curl.
 */
import ZAI from 'z-ai-web-dev-sdk';
import fs from 'fs';
import path from 'path';
import { execSync } from 'child_process';

const PERFUMES = [
  // Brand Collection (22) — buscar pelo nome da marca original
  { id: 'bc-001', q: 'Allure Homme Sport Chanel perfume bottle' },
  { id: 'bc-002', q: 'Burberry London for Men perfume bottle' },
  { id: 'bc-003', q: 'Carolina Herrera CH Women perfume bottle' },
  { id: 'bc-004', q: 'Carolina Herrera CH Men perfume bottle' },
  { id: 'bc-005', q: 'Paco Rabanne 1 Million perfume bottle gold' },
  { id: 'bc-007', q: 'Dior Jadore perfume bottle' },
  { id: 'bc-008', q: 'Carolina Herrera 212 VIP Men perfume bottle' },
  { id: 'bc-010', q: 'Tom Ford Black Orchid perfume bottle' },
  { id: 'bc-012', q: 'Lancome La Vie Est Belle perfume bottle' },
  { id: 'bc-021', q: 'Chanel Coco Mademoiselle perfume bottle' },
  { id: 'bc-027', q: 'Dior Hypnotic Poison perfume bottle' },
  { id: 'bc-034', q: 'Carolina Herrera 212 VIP Rose perfume bottle' },
  { id: 'bc-070', q: 'Bleu de Chanel perfume bottle' },
  { id: 'bc-100', q: 'Dior Sauvage perfume bottle' },
  { id: 'bc-105', q: 'Paco Rabanne Lady Million perfume bottle diamond' },
  { id: 'bc-116', q: 'Paco Rabanne Invictus perfume bottle trophy' },
  { id: 'bc-126', q: 'Carolina Herrera Good Girl perfume bottle stiletto' },
  { id: 'bc-136', q: 'Jean Paul Gaultier Scandal perfume bottle' },
  { id: 'bc-159', q: 'YSL Libre perfume bottle' },
  { id: 'bc-181', q: 'Carolina Herrera Bad Boy perfume bottle' },
  { id: 'bc-247', q: 'MFK Baccarat Rouge 540 perfume bottle' },
  { id: 'bc-283', q: 'Dior Sauvage Elixir perfume bottle' },
  // AFEER (5)
  { id: 'af-01', q: 'Lattafa Atheeri perfume bottle' },
  { id: 'af-02', q: 'Lattafa Asad perfume bottle' },
  { id: 'af-03', q: 'Lattafa Yara Pink perfume bottle' },
  { id: 'af-04', q: 'Orientica Royal Amber perfume bottle' },
  { id: 'af-07', q: 'Lattafa Fakhar Rose perfume bottle' },
  // Decantes árabes (18)
  { id: 'dec-01', q: 'Al Wataniah Bareeq Al Dahab perfume bottle' },
  { id: 'dec-02', q: 'Lattafa Asad Zanzibar perfume bottle' },
  { id: 'dec-03', q: 'Lattafa Qaed Al Fursan perfume bottle' },
  { id: 'dec-04', q: 'Maison Alhambra Royal Blend Nero perfume bottle' },
  { id: 'dec-05', q: 'Lattafa Khamrah perfume bottle' },
  { id: 'dec-06', q: 'Lattafa Asad Bourbon perfume bottle' },
  { id: 'dec-07', q: 'Armaf Odyssey Dubai Chocolat perfume bottle' },
  { id: 'dec-08', q: 'Lattafa Dukhan perfume bottle' },
  { id: 'dec-09', q: 'Al Wataniah Watani Noir perfume bottle' },
  { id: 'dec-10', q: 'Lattafa Badee Al Oud For Glory perfume bottle' },
  { id: 'dec-11', q: 'Al Wataniah Oud Mystery Intense perfume bottle' },
  { id: 'dec-12', q: 'Lattafa Al Noble Ameer perfume bottle' },
  { id: 'dec-13', q: 'Maison Alhambra Chants Tenderina perfume bottle' },
  { id: 'dec-14', q: 'Lattafa Amirat Al Arab Prive Red perfume bottle' },
  { id: 'dec-15', q: 'Al Wataniah Rose Mystery Intense perfume bottle' },
  { id: 'dec-16', q: 'Lattafa Fakhar Rose Gold perfume bottle' },
  { id: 'dec-17', q: 'Lattafa Tharwah Gold perfume bottle' },
  { id: 'dec-18', q: 'Lattafa Yara Tous perfume bottle' },
];

function extractBingThumbnails(rawHtml) {
  // Decode HTML entities first
  const decoded = rawHtml.replace(/&quot;/g, '"').replace(/&amp;/g, '&').replace(/&lt;/g, '<').replace(/&gt;/g, '>');
  // Extract thumbnail IDs: OIP.xxxxx
  const ids = [...new Set([...decoded.matchAll(/th\?id=(OIP\.[A-Za-z0-9_-]+)/g)].map(m => m[1]))];
  return ids.map(id => `https://tse3.mm.bing.net/th?id=${id}&w=600`);
}

function download(url, dest) {
  try {
    execSync(`curl -s -o "${dest}" --max-time 15 -A "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36" "${url}"`, { timeout: 20000 });
    if (fs.existsSync(dest) && fs.statSync(dest).size > 3000) return true;
    if (fs.existsSync(dest)) fs.unlinkSync(dest);
    return false;
  } catch { return false; }
}

async function main() {
  const zai = await ZAI.create();
  const outDir = '/home/z/my-project/public/perfumes';
  if (!fs.existsSync(outDir)) fs.mkdirSync(outDir, { recursive: true });

  const results = {};
  let found = 0;

  for (const p of PERFUMES) {
    process.stdout.write(`[${p.id}] ${p.q.slice(0, 40)}... `);
    try {
      const bingUrl = `https://www.bing.com/images/search?q=${encodeURIComponent(p.q)}`;
      const result = await zai.functions.invoke('page_reader', { url: bingUrl });
      const html = result.data?.html || '';
      const thumbs = extractBingThumbnails(html);
      if (thumbs.length === 0) {
        console.log('✗ no thumbnails');
        continue;
      }
      // Tenta baixar o primeiro thumbnail
      const dest = path.join(outDir, `${p.id}-real.jpg`);
      let downloaded = false;
      for (const thumb of thumbs.slice(0, 3)) {
        if (download(thumb, dest)) { downloaded = true; break; }
      }
      if (downloaded) {
        results[p.id] = `/perfumes/${p.id}-real.jpg`;
        found++;
        console.log(`✓ saved (${fs.statSync(dest).size} bytes)`);
      } else {
        console.log('✗ download failed');
      }
    } catch (e) {
      console.log(`✗ error: ${e.message?.slice(0, 60)}`);
    }
    await new Promise(r => setTimeout(r, 500));
  }

  fs.writeFileSync('/home/z/my-project/real-image-urls.json', JSON.stringify(results, null, 2));
  console.log(`\n=== SUMMARY: Found ${found}/${PERFUMES.length} real images ===`);
  console.log('Saved to /home/z/my-project/real-image-urls.json');
}

main().catch(console.error);
