/**
 * Busca imagens reais dos Brand Collection via Openverse API (Flickr, etc.).
 * Baixa, verifica com VLM e salva as imagens corretas.
 */
import fs from 'fs';
import path from 'path';
import { execSync } from 'child_process';

const OUT_DIR = '/home/z/my-project/public/perfumes';
const PERFUMES = [
  { id: 'bc-001', q: 'Allure Homme Sport Chanel perfume bottle' },
  { id: 'bc-002', q: 'Burberry London perfume bottle men' },
  { id: 'bc-003', q: 'Carolina Herrera CH Women perfume bottle' },
  { id: 'bc-004', q: 'Carolina Herrera CH Men perfume bottle' },
  { id: 'bc-005', q: 'Paco Rabanne 1 Million perfume bottle gold' },
  { id: 'bc-007', q: 'Dior Jadore perfume bottle' },
  { id: 'bc-008', q: 'Carolina Herrera 212 VIP Men perfume bottle' },
  { id: 'bc-010', q: 'Tom Ford Black Orchid perfume bottle' },
  { id: 'bc-012', q: 'Lancome La Vie Est Belle perfume bottle' },
  { id: 'bc-021', q: 'Chanel Coco Mademoiselle perfume bottle' },
  { id: 'bc-027', q: 'Dior Hypnotic Poison perfume bottle' },
  { id: 'bc-034', q: 'Carolina Herrera 212 VIP Rose perfume bottle' },
  { id: 'bc-070', q: 'Bleu de Chanel perfume bottle' },
  { id: 'bc-100', q: 'Dior Sauvage perfume bottle' },
  { id: 'bc-105', q: 'Paco Rabanne Lady Million perfume bottle' },
  { id: 'bc-116', q: 'Paco Rabanne Invictus perfume bottle' },
  { id: 'bc-126', q: 'Carolina Herrera Good Girl perfume bottle stiletto' },
  { id: 'bc-136', q: 'Jean Paul Gaultier Scandal perfume bottle' },
  { id: 'bc-159', q: 'YSL Libre perfume bottle' },
  { id: 'bc-181', q: 'Carolina Herrera Bad Boy perfume bottle' },
  { id: 'bc-247', q: 'Baccarat Rouge 540 MFK perfume bottle' },
  { id: 'bc-283', q: 'Dior Sauvage Elixir perfume bottle' },
];

function searchOpenverse(query) {
  try {
    const url = `https://api.openverse.org/v1/images/?q=${encodeURIComponent(query)}&page_size=3&mature=false`;
    const out = execSync(`curl -s -A "MimiMimos/1.0" --max-time 15 "${url}"`, { timeout: 20000, encoding: 'utf-8' });
    const data = JSON.parse(out);
    return (data.results || []).map(r => r.url).filter(Boolean);
  } catch { return []; }
}

function download(url, dest) {
  try {
    execSync(`curl -s -o "${dest}" --max-time 20 -A "MimiMimos/1.0 (contact@mimimimos.com)" -L "${url}"`, { timeout: 25000 });
    if (fs.existsSync(dest) && fs.statSync(dest).size > 5000) return true;
    if (fs.existsSync(dest)) fs.unlinkSync(dest);
    return false;
  } catch { return false; }
}

function verifyWithVLM(imgPath, perfumeName) {
  try {
    const out = execSync(`z-ai vision -p "Is this image a perfume bottle product photo? Answer ONLY 'yes' or 'no'." -i "${imgPath}" -o /tmp/vlm-check.json --no-thinking 2>/dev/null || echo '{}'`, { timeout: 30000, encoding: 'utf-8' });
    const data = JSON.parse(fs.readFileSync('/tmp/vlm-check.json', 'utf-8'));
    const content = (data.choices?.[0]?.message?.content || '').toLowerCase();
    return content.includes('yes');
  } catch { return false; }
}

async function main() {
  const results = {};
  let found = 0;

  for (const p of PERFUMES) {
    process.stdout.write(`[${p.id}] ${p.q.slice(0, 35)}... `);
    const urls = searchOpenverse(p.q);
    if (urls.length === 0) {
      console.log('✗ no results');
      continue;
    }
    let saved = false;
    for (const url of urls.slice(0, 3)) {
      const dest = path.join(OUT_DIR, `${p.id}-real.jpg`);
      if (download(url, dest)) {
        // Verify it's actually a perfume bottle
        if (verifyWithVLM(dest, p.q)) {
          results[p.id] = `/perfumes/${p.id}-real.jpg`;
          found++;
          saved = true;
          console.log(`✓ (${fs.statSync(dest).size} bytes)`);
          break;
        } else {
          fs.unlinkSync(dest);
          console.log('? not a perfume, trying next...');
        }
      }
    }
    if (!saved) console.log('✗ all candidates failed verification');
    await new Promise(r => setTimeout(r, 600));
  }

  fs.writeFileSync('/home/z/my-project/real-brand-images.json', JSON.stringify(results, null, 2));
  console.log(`\n=== SUMMARY: ${found}/${PERFUMES.length} real brand images found ===`);
}

main().catch(console.error);
