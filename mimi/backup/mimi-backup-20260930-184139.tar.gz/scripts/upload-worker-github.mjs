/**
 * Faz upload de todos os arquivos do projeto Mimi Mimos para a pasta mimi/ no GitHub.
 * Inclui: worker.js, app.js, logo, manifest, ícones, README.
 */
import fs from 'fs';
import path from 'path';

const TOKEN = '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';
const REPO = 'esaaraujo-lab/gdi_server';
const BRANCH = 'main';

async function uploadFile(githubPath, localPath, message) {
  const content = fs.readFileSync(localPath);
  const b64 = content.toString('base64');
  let sha = null;
  const checkRes = await fetch(`https://api.github.com/repos/${REPO}/contents/${githubPath}?ref=${BRANCH}`, {
    headers: { Authorization: `token ${TOKEN}`, Accept: 'application/vnd.github+json' },
  });
  if (checkRes.ok) {
    const data = await checkRes.json();
    sha = data.sha;
  }
  const res = await fetch(`https://api.github.com/repos/${REPO}/contents/${githubPath}`, {
    method: 'PUT',
    headers: { Authorization: `token ${TOKEN}`, Accept: 'application/vnd.github+json', 'Content-Type': 'application/json' },
    body: JSON.stringify({
      message: message || `mimi: add ${githubPath}`,
      content: b64,
      branch: BRANCH,
      ...(sha ? { sha } : {}),
    }),
  });
  const data = await res.json();
  return { ok: res.ok, status: res.status };
}

const README = `# Mimi Mimos — Haute Parfumerie (Cloudflare Worker)

Catálogo de perfumes importados e árabes: Brand Collection 25ml, Miniaturas Árabes Afeer e Decantes 5ml.

## Deploy no Cloudflare Workers

1. Acesse https://workers.cloudflare.com
2. Crie um novo Worker
3. Cole o conteúdo de \`worker.js\` no editor
4. Deploy

## Estrutura

- \`worker.js\` — Worker principal (HTML + API Pix + login admin + leads)
- \`app.js\` — Lógica frontend separada (opcional)
- \`perfumes/\` — Imagens dos produtos (34 fotos)
- \`logo-bottle.png\` — Logo do frasco
- \`icon-192.png\`, \`icon-512.png\` — Ícones PWA
- \`manifest.json\` — Manifest PWA

## APIs

- \`POST /api/pix\` — Gera BR Code Pix Copia e Cola + QR URL
- \`POST /api/admin-login\` — Autenticação admin (senha Base64)
- \`POST /api/leads\` — Captura leads "Avise-me"
- \`GET /api/products\` — Lista todos os produtos (JSON)
- \`GET /api/health\` — Health check

## Configuração

- Chave Pix: fabiana@araujo.eu.org
- WhatsApp: +55 11 95854-6078
- Senha Admin: F@b@180574 (hash Base64: RkBiQDE4MDU3NA==)
- Preços: Brand R$ 69,99 | Afeer R$ 79,99 | Decante R$ 39,99 (3 por R$ 100)

© ${new Date().getFullYear()} Mimi Mimos Parfumerie
`;

async function main() {
  const files = [
    { local: '/home/z/my-project/mimi-worker.js', github: 'mimi/worker.js', msg: 'mimi: add Cloudflare Worker (catalog + Pix API + admin login)' },
    { local: '/home/z/my-project/mimi-app.js', github: 'mimi/app.js', msg: 'mimi: add frontend app.js' },
    { local: '/home/z/my-project/public/logo-bottle.png', github: 'mimi/logo-bottle.png', msg: 'mimi: add logo (perfume bottle)' },
    { local: '/home/z/my-project/public/icon-192.png', github: 'mimi/icon-192.png', msg: 'mimi: add PWA icon 192' },
    { local: '/home/z/my-project/public/icon-512.png', github: 'mimi/icon-512.png', msg: 'mimi: add PWA icon 512' },
    { local: '/home/z/my-project/public/apple-touch-icon.png', github: 'mimi/apple-touch-icon.png', msg: 'mimi: add iOS touch icon' },
    { local: '/home/z/my-project/public/favicon-32.png', github: 'mimi/favicon-32.png', msg: 'mimi: add favicon' },
    { local: '/home/z/my-project/public/manifest.json', github: 'mimi/manifest.json', msg: 'mimi: add PWA manifest' },
  ];

  // README (conteúdo inline)
  fs.writeFileSync('/tmp/mimi-readme.md', README);
  files.push({ local: '/tmp/mimi-readme.md', github: 'mimi/README.md', msg: 'mimi: add README with deploy instructions' });

  let uploaded = 0, failed = 0;
  for (const f of files) {
    process.stdout.write(`${f.github}... `);
    const result = await uploadFile(f.github, f.local, f.msg);
    if (result.ok) { uploaded++; console.log('✓'); }
    else { failed++; console.log(`✗ (${result.status})`); }
    await new Promise(r => setTimeout(r, 400));
  }
  console.log(`\n=== Arquivos: ${uploaded} enviados, ${failed} falharam ===`);
}

main().catch(console.error);
