#!/usr/bin/env python3
"""Search FragranceX for each perfume and find its SKU -> build large image URL."""
import json, re, subprocess, os, sys

CACHE_DIR = "/home/z/my-project/scripts/tmp/pages"
os.makedirs(CACHE_DIR, exist_ok=True)

def fetch_page(url, cache_key):
    out_path = os.path.join(CACHE_DIR, f"{cache_key}.json")
    if os.path.exists(out_path) and os.path.getsize(out_path) > 1000:
        return out_path
    args = json.dumps({"url": url})
    cmd = ["z-ai", "function", "-n", "page_reader", "-a", args, "-o", out_path]
    try:
        res = subprocess.run(cmd, capture_output=True, text=True, timeout=120)
        if res.returncode != 0:
            return None
        return out_path
    except subprocess.TimeoutExpired:
        return None

def parse_search_results(json_path):
    """Return list of (alt_text, sku) tuples from a FragranceX search page."""
    try:
        with open(json_path) as f:
            d = json.load(f)
    except: return []
    html = d.get("data", {}).get("html", "")
    if not html: return []
    # Pattern: <img alt="X" src=".../sku/small/{SKU}.jpg">
    results = []
    # alt before src
    for m in re.finditer(r'<img[^>]+alt=["\']([^"\']+)["\'][^>]+src=["\']https?://img\.fragrancex\.com/images/products/sku/small/([^"\']+)["\']', html):
        results.append((m.group(1), m.group(2)))
    # src before alt
    for m in re.finditer(r'<img[^>]+src=["\']https?://img\.fragrancex\.com/images/products/sku/small/([^"\']+)["\'][^>]+alt=["\']([^"\']+)["\']', html):
        results.append((m.group(2), m.group(1)))
    return results

def check_url(url):
    try:
        res = subprocess.run(
            ["curl", "-sIL", "-o", "/dev/null", "-w", "%{http_code}", "--max-time", "20", url],
            capture_output=True, text=True, timeout=25
        )
        code = res.stdout.strip().split('\n')[-1]
        return code == "200", code
    except Exception as e:
        return False, str(e)

def best_sku_match(results, perfume_name):
    """Pick the best SKU whose alt text matches the perfume name."""
    perfume_lower = perfume_name.lower()
    # Score: number of perfume keywords that match alt text
    keywords = [k.lower() for k in perfume_name.split() if len(k) > 2]
    scored = []
    for alt, sku in results:
        alt_lower = alt.lower().replace("&gt;", " ").replace("&amp;", " ")
        # remove special chars
        alt_clean = re.sub(r'[^a-z0-9\s]', ' ', alt_lower)
        alt_words = set(alt_clean.split())
        # match by keywords present
        matches = sum(1 for k in keywords if k in alt_clean)
        # Bonus if all keywords match
        if matches == len(keywords) and len(keywords) > 0:
            scored.append((matches + 5, alt, sku))
        else:
            scored.append((matches, alt, sku))
    scored.sort(reverse=True)
    return scored

# Perfumes to find via FragranceX
TARGETS = {
    # Brand Collection
    "bc-001": "Allure Homme Sport Chanel",
    "bc-002": "Burberry London",
    "bc-003": "CH Women Carolina Herrera",
    "bc-004": "CH Men Carolina Herrera",
    "bc-005": "Paco Rabanne 1 Million",
    "bc-007": "Dior J adore",
    "bc-008": "212 VIP Men Carolina Herrera",
    "bc-010": "Tom Ford Black Orchid",
    "bc-012": "Lancome La Vie Est Belle",
    "bc-021": "Chanel Coco Mademoiselle",
    "bc-027": "Dior Hypnotic Poison",
    "bc-034": "212 VIP Rose Carolina Herrera",
    "bc-070": "Bleu de Chanel",
    "bc-100": "Dior Sauvage",
    "bc-105": "Paco Rabanne Lady Million",
    "bc-116": "Paco Rabanne Invictus",
    "bc-126": "Carolina Herrera Good Girl",
    "bc-136": "Jean Paul Gaultier Scandal",
    "bc-159": "Yves Saint Laurent Libre",
    "bc-181": "Carolina Herrera Bad Boy",
    "bc-247": "Maison Francis Kurkdjian Baccarat Rouge 540",
    "bc-283": "Dior Sauvage Elixir",
    # Non-Lattafa Arabic perfumes
    "af-04": "Orientica Royal Amber",
    "dec-01": "Al Wataniah Bareeq Al Dahab",
    "dec-04": "Maison Alhambra Royal Blend Nero",
    "dec-07": "Armaf Odyssey Dubai Chocolat",
    "dec-09": "Al Wataniah Watani Noir",
    "dec-11": "Al Wataniah Oud Mystery Intense",
    "dec-13": "Maison Alhambra Chants Tenderina",
    "dec-15": "Al Wataniah Rose Mystery Intense",
    "af-03": "Lattafa Yara Pink",
}

results = {}
for pid, name in TARGETS.items():
    print(f"\n=== {pid} ({name}) ===", flush=True)
    # URL encode name
    query = name.replace(" ", "+")
    url = f"https://www.fragrancex.com/search.html?search={query}"
    cache_key = f"fx-{pid}"
    out = fetch_page(url, cache_key)
    if not out:
        print(f"  fetch failed", flush=True)
        continue
    pairs = parse_search_results(out)
    if not pairs:
        print(f"  no results", flush=True)
        continue
    # Show top candidates
    scored = best_sku_match(pairs, name)
    print(f"  Top 5 candidates:", flush=True)
    for score, alt, sku in scored[:5]:
        print(f"    [{score}] alt='{alt[:60]}' sku={sku}", flush=True)
    if not scored:
        continue
    # Take top result
    best_score, best_alt, best_sku = scored[0]
    if best_score < 3:  # too low confidence
        print(f"  LOW confidence (score={best_score}); skipping", flush=True)
        continue
    img_url = f"https://img.fragrancex.com/images/products/sku/large/{best_sku}"
    ok, code = check_url(img_url)
    if ok:
        print(f"  -> {img_url} [200]", flush=True)
        results[pid] = img_url
    else:
        print(f"  -> {img_url} [{code}]", flush=True)

print("\n=== FINAL ===")
for k, v in results.items():
    print(f"  {k}: {v}")
print(f"\nTotal: {len(results)}/{len(TARGETS)}")

with open("/home/z/my-project/scripts/tmp/fragrancex-results.json", "w") as f:
    json.dump(results, f, indent=2)
