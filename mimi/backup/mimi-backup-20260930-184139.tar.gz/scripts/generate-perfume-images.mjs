// Generate luxury perfume bottle images for the Mimi Mimos catalog
// Uses z-ai-web-dev-sdk for image generation, sharp for format conversion/resizing

import ZAI from 'z-ai-web-dev-sdk';
import fs from 'fs';
import path from 'path';
import sharp from 'sharp';

const PERFUMES_DIR = '/home/z/my-project/public/perfumes';
const PUBLIC_DIR = '/home/z/my-project/public';
const TMP_DIR = '/home/z/my-project/scripts/tmp';

// Ensure directories exist
fs.mkdirSync(PERFUMES_DIR, { recursive: true });
fs.mkdirSync(TMP_DIR, { recursive: true });

// Shared luxury aesthetic tokens for consistency
const LUX_BG = 'deep obsidian black background, dark matte studio backdrop, faint golden rim lighting';
const LUX_STYLE = 'ultra-luxurious editorial product photography, high-end parfumerie catalog, dramatic cinematic lighting, soft golden rim light, fine art still life, ultra-detailed, photorealistic, 8k, depth of field, reflective polished black surface';
const BOTTLE_BASE = 'small elegant 25ml pocket-sized luxury glass perfume bottle, premium parfumerie packaging, gold-accented cap';

const IMAGE_JOBS = [
  // ----- 9 perfume bottle catalog images (square 1024x1024) -----
  {
    name: 'bc-001.jpg',
    size: '1024x1024',
    final: { format: 'jpg', quality: 92 },
    prompt: `A feminine luxury perfume bottle inspired by Carolina Herrera Good Girl, elegant curved stiletto-heel-shaped glass bottle with warm amber-pink liquid inside, glossy pinkish-amber tones, gold heel accent, ${LUX_BG}, ${LUX_STYLE}, ${BOTTLE_BASE}, sensual feminine mood, pink and amber color palette`,
  },
  {
    name: 'bc-002.jpg',
    size: '1024x1024',
    final: { format: 'jpg', quality: 92 },
    prompt: `A masculine luxury perfume bottle inspired by Dior Sauvage, sleek modern dark frosted glass bottle with cool blue-grey liquid inside, silver metallic cap, minimalist contemporary design, ${LUX_BG}, ${LUX_STYLE}, ${BOTTLE_BASE}, cool blue and steel silver color palette, refined masculine mood`,
  },
  {
    name: 'bc-312.jpg',
    size: '1024x1024',
    final: { format: 'jpg', quality: 92 },
    prompt: `An Arabic luxury oriental perfume bottle inspired by Lattafa Khamrah, ornate arabesque-decorated crystal bottle with intricate gold filigree, warm spiced amber liquid inside, rich golden and copper tones, oriental Middle Eastern design, ${LUX_BG}, ${LUX_STYLE}, ${BOTTLE_BASE}, opulent warm amber and copper color palette`,
  },
  {
    name: 'bc-086.jpg',
    size: '1024x1024',
    final: { format: 'jpg', quality: 92 },
    prompt: `A unisex niche luxury perfume bottle inspired by Baccarat Rouge 540, crystalline geometric faceted glass bottle with ruby-red crimson liquid inside, gold-trimmed red label, luminous translucent crystal facets, ${LUX_BG}, ${LUX_STYLE}, ${BOTTLE_BASE}, crimson red and gold color palette, exclusive niche mood`,
  },
  {
    name: 'bc-012.jpg',
    size: '1024x1024',
    final: { format: 'jpg', quality: 92 },
    prompt: `A feminine luxury perfume bottle inspired by Jean Paul Gaultier Scandal, sculpted female-silhouette glass bottle with golden honey-amber liquid inside, glossy curved female-form shape, gold bust cap, ${LUX_BG}, ${LUX_STYLE}, ${BOTTLE_BASE}, honey gold and amber color palette, sensual feminine mood`,
  },
  {
    name: 'bc-145.jpg',
    size: '1024x1024',
    final: { format: 'jpg', quality: 92 },
    prompt: `A masculine luxury perfume bottle inspired by Jacques Bogart Silver Scent, rectangular metallic silver-chrome glass bottle with brushed steel cap, bold architectural form, transparent silver-grey liquid, ${LUX_BG}, ${LUX_STYLE}, ${BOTTLE_BASE}, silver and steel grey color palette, sharp masculine mood`,
  },
  {
    name: 'bc-018.jpg',
    size: '1024x1024',
    final: { format: 'jpg', quality: 92 },
    prompt: `A feminine luxury perfume bottle inspired by Carolina Herrera 212 VIP Rosé, spherical rounded pink glass bottle with rosé champagne liquid inside, gold accent ring and cap, elegant party mood, ${LUX_BG}, ${LUX_STYLE}, ${BOTTLE_BASE}, rosé pink champagne color palette, glamorous feminine mood`,
  },
  {
    name: 'bc-204.jpg',
    size: '1024x1024',
    final: { format: 'jpg', quality: 92 },
    prompt: `An Arabic luxury perfume bottle inspired by Armaf Club de Nuit Intense, bold black geometric rectangular glass bottle with rich gold accents, dark smoky liquid inside, masculine oriental design, gold-embossed logo plate, ${LUX_BG}, ${LUX_STYLE}, ${BOTTLE_BASE}, black and gold color palette, powerful bold mood`,
  },
  {
    name: 'bc-320.jpg',
    size: '1024x1024',
    final: { format: 'jpg', quality: 92 },
    prompt: `An Arabic feminine luxury perfume bottle inspired by Lattafa Yara Powder, elegant soft-pink ornate glass bottle with powdery pink-violet liquid inside, delicate gold floral filigree accents, dreamy powdery oriental design, ${LUX_BG}, ${LUX_STYLE}, ${BOTTLE_BASE}, powdery pink and soft violet with gold color palette, romantic feminine mood`,
  },

  // ----- hero-ambient.jpg (wide 16:9-ish) -----
  {
    name: 'hero-ambient.jpg',
    size: '1440x720',
    final: { format: 'jpg', quality: 90 },
    prompt: `Atmospheric luxury perfume scene, single elegant 25ml glass perfume bottle floating in center, dark obsidian black background with dramatic golden light beams piercing through, swirling golden mist and floating glittering particles, soft volumetric god rays, ultra-luxurious editorial photography, cinematic mood, depth of field, reflective polished black marble surface, elegant and mysterious, high-end parfumerie brand campaign aesthetic, gold and obsidian color palette`,
  },

  // ----- og-cover.jpg (wide 1.91:1-ish) -----
  {
    name: 'og-cover.jpg',
    size: '1440x720',
    final: { format: 'jpg', quality: 90 },
    prompt: `Luxury social share cover image, single elegant 25ml glass perfume bottle with gold accents centered on obsidian black background, refined golden light glow around the bottle, sophisticated minimal composition with elegant empty space, gold dust particles, ultra-luxurious parfumerie branding aesthetic, high-end editorial photography, gold and obsidian black color palette, symmetrical composition`,
  },

  // ----- icons (square 1024x1024) -----
  {
    name: 'icon-512.png',
    size: '1024x1024',
    final: { format: 'png', resize: { width: 512, height: 512 } },
    prompt: `Luxury app icon, circular gold "M" monogram letter centered, polished obsidian black background, brushed gold metallic letterform, minimalist premium luxury branding, elegant serif-style letter, subtle golden glow, geometric circular gold ring border, ultra-clean, centered composition, no text other than the letter M`,
  },
  {
    name: 'icon-192.png',
    size: '1024x1024',
    final: { format: 'png', resize: { width: 192, height: 192 } },
    prompt: `Luxury app icon, circular gold "M" monogram letter centered, polished obsidian black background, brushed gold metallic letterform, minimalist premium luxury branding, elegant serif-style letter, subtle golden glow, geometric circular gold ring border, ultra-clean, centered composition, no text other than the letter M`,
  },
  {
    name: 'apple-touch-icon.png',
    size: '1024x1024',
    final: { format: 'png', resize: { width: 180, height: 180 }, flatten: true },
    prompt: `Luxury iOS app icon, circular gold "M" monogram letter centered, solid opaque obsidian black square background with no transparency, brushed gold metallic letterform, minimalist premium luxury branding, elegant serif-style letter, subtle golden glow, geometric circular gold ring border, ultra-clean, centered composition, no text other than the letter M`,
  },
];

const MAX_RETRIES = 3;

async function generateOne(zai, job, attempt = 1) {
  const tmpPng = path.join(TMP_DIR, job.name + '.raw.png');
  try {
    console.log(`▶ [${attempt}/${MAX_RETRIES}] Generating: ${job.name} (${job.size})`);
    const response = await zai.images.generations.create({
      prompt: job.prompt,
      size: job.size,
    });
    if (!response?.data?.[0]?.base64) {
      throw new Error('Invalid response from API (no base64)');
    }
    const buffer = Buffer.from(response.data[0].base64, 'base64');
    fs.writeFileSync(tmpPng, buffer);
    console.log(`  ✓ Raw PNG saved (${buffer.length} bytes)`);

    // Convert / resize
    const outDir = job.name.startsWith('bc-') ? PERFUMES_DIR : PUBLIC_DIR;
    const outPath = path.join(outDir, job.name);

    let img = sharp(tmpPng, { failOn: 'none' });
    if (job.final.resize) {
      img = img.resize({
        width: job.final.resize.width,
        height: job.final.resize.height,
        fit: 'cover',
        position: 'center',
      });
    }
    if (job.final.flatten) {
      img = img.flatten({ background: '#000000' });
    }
    if (job.final.format === 'jpg') {
      img = img.jpeg({ quality: job.final.quality || 90, mozjpeg: true, chromaSubsampling: '4:4:4' });
    } else {
      img = img.png({ compressionLevel: 9, quality: 90 });
    }
    await img.toFile(outPath);
    const stat = fs.statSync(outPath);
    console.log(`  ✓ Saved: ${outPath} (${stat.size} bytes)`);
    // Clean tmp
    fs.unlinkSync(tmpPng);
    return { success: true, path: outPath, bytes: stat.size };
  } catch (err) {
    console.error(`  ✗ Error on ${job.name}: ${err.message}`);
    if (fs.existsSync(tmpPng)) {
      try { fs.unlinkSync(tmpPng); } catch {}
    }
    if (attempt < MAX_RETRIES) {
      const wait = 2000 * attempt;
      console.log(`  ↻ Retrying in ${wait / 1000}s...`);
      await new Promise(r => setTimeout(r, wait));
      return generateOne(zai, job, attempt + 1);
    }
    return { success: false, name: job.name, error: err.message };
  }
}

async function main() {
  console.log('Initializing Z-AI SDK...');
  const zai = await ZAI.create();
  console.log(`Will process ${IMAGE_JOBS.length} image jobs.\n`);

  const results = [];
  for (const job of IMAGE_JOBS) {
    const r = await generateOne(zai, job);
    results.push({ name: job.name, ...r });
    // small delay to avoid rate-limit
    await new Promise(res => setTimeout(res, 600));
  }

  console.log('\n========== SUMMARY ==========');
  let okCount = 0;
  let failCount = 0;
  for (const r of results) {
    if (r.success) {
      console.log(`  ✓ ${r.name} → ${r.path} (${r.bytes} bytes)`);
      okCount++;
    } else {
      console.log(`  ✗ ${r.name} → FAILED: ${r.error}`);
      failCount++;
    }
  }
  console.log(`\nTotal: ${okCount} success, ${failCount} failed`);

  // Write machine-readable results file
  fs.writeFileSync(
    path.join(TMP_DIR, 'results.json'),
    JSON.stringify(results, null, 2)
  );

  // Clean up tmp dir if empty
  try {
    if (fs.readdirSync(TMP_DIR).length === 0) {
      fs.rmdirSync(TMP_DIR);
    }
  } catch {}

  process.exit(failCount > 0 ? 1 : 0);
}

main().catch(err => {
  console.error('Fatal:', err);
  process.exit(1);
});
