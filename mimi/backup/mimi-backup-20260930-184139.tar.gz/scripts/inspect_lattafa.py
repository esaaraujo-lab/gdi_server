#!/usr/bin/env python3
"""Search Lattafa USA Shopify catalog and pick EXACT match only."""
import json, re, os

# Load all pages
all_products = []
for page in [1, 2]:
    with open(f"/tmp/lattafa-products-p{page}.json") as f:
        d = json.load(f)
    all_products.extend(d.get("products", []))

print(f"Total products: {len(all_products)}")

# Build a lookup by exact handle
by_handle = {p.get("handle", "").lower(): p for p in all_products}
by_title = {p.get("title", "").lower(): p for p in all_products}

# Show all handles matching some keywords for inspection
print("\n=== LATTafa HANDLES WITH KEYWORDS ===")
KEYWORDS = ["yara", "fakhar", "khamrah", "asad", "qaed", "noble", "ameer", "amirat",
            "tharwah", "badee", "dukhan", "marrom", "bourbon", "oud"]
for p in all_products:
    handle = p.get("handle", "").lower()
    title = p.get("title", "")
    if any(k in handle for k in KEYWORDS):
        print(f"  {handle} | {title}")
