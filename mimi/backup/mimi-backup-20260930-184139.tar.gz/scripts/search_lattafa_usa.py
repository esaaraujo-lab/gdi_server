#!/usr/bin/env python3
"""Search Lattafa USA Shopify catalog for all needed perfumes."""
import json, re, os

# Load all pages
all_products = []
for page in [1, 2]:
    with open(f"/tmp/lattafa-products-p{page}.json") as f:
        d = json.load(f)
    all_products.extend(d.get("products", []))

print(f"Total products: {len(all_products)}")

# Build searchable index by title and handle
def search_all(queries):
    """Return list of products whose title/handle contains any query keyword."""
    results = []
    for p in all_products:
        text = (p.get("title", "") + " " + p.get("handle", "")).lower()
        # Check ALL keywords must match
        if all(q.lower() in text for q in queries):
            results.append(p)
    return results

# Define searches
SEARCHES = {
    # AFEER Arabic Miniatures
    "af-01-atheeri": [["aatheer"], ["atheeri"]],  # Afeer Atheeri / Lattafa Atheeri
    "af-02-asad": [["asad"]],  # Asad
    "af-03-yara-pink": [["yara", "pink"]],
    "af-07-fakhar-rose": [["fakhar", "rose"]],

    # Decantes Arabic
    "dec-02-asad-zanzibar": [["asad", "zanzibar"]],
    "dec-03-qaed-al-fursan": [["qaed", "fursan"], ["qaed"]],
    "dec-05-khamrah": [["khamrah"]],
    "dec-06-asad-marrom-bourbon": [["asad", "marrom"], ["marrom"], ["bourbon"]],
    "dec-08-dukhan": [["dukhan"]],
    "dec-10-badee-al-oud": [["badee", "oud"], ["badee"]],
    "dec-12-al-noble-ameer": [["noble", "ameer"], ["ameer"]],
    "dec-14-amirat-al-arab": [["amirat", "arab"], ["amirat"]],
    "dec-16-fakhar-rose-gold": [["fakhar", "rose", "gold"], ["fakhar", "gold"]],
    "dec-17-tharwah-gold": [["tharwah"], ["tharwa"]],
    "dec-18-yara-tous": [["yara", "tous"]],
}

def get_main_image(p):
    """Get the first main product image."""
    images = p.get("images", [])
    if images:
        return images[0].get("src", "")
    return ""

results = {}
for pid, query_groups in SEARCHES.items():
    print(f"\n=== {pid} ===")
    candidates = []
    for queries in query_groups:
        for p in search_all(queries):
            if p not in candidates:
                candidates.append(p)
    if not candidates:
        print("  NO MATCHES")
        continue
    # Print all candidates
    for p in candidates[:8]:
        title = p.get("title", "")
        handle = p.get("handle", "")
        img = get_main_image(p)
        print(f"  - {title} | {handle} | {img[:100] if img else 'NO IMAGE'}")
    # Pick best: exact match on handle preferred
    # Take first
    chosen = candidates[0]
    img = get_main_image(chosen)
    if img:
        results[pid] = img
        print(f"  CHOSEN: {chosen['title']} -> {img}")

print("\n=== FINAL RESULTS ===")
for k, v in results.items():
    print(f"  {k}: {v}")
print(f"\nTotal: {len(results)}/{len(SEARCHES)}")

# Save
os.makedirs("/home/z/my-project/scripts/tmp", exist_ok=True)
with open("/home/z/my-project/scripts/tmp/lattafa-usa-results.json", "w") as f:
    json.dump(results, f, indent=2)
print("\nSaved to lattafa-usa-results.json")
