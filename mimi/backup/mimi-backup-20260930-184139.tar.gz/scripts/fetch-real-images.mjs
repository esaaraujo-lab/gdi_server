/**
 * Busca URLs de imagens reais de perfumes via page_reader do z-ai SDK.
 * Testa múltiplos e-commerces para cada perfume.
 */
import ZAI from 'z-ai-web-dev-sdk';
import fs from 'fs';

const PERFUMES = [
  // Brand Collection
  { id: 'bc-001', name: 'Allure Homme Sport', brand: 'Chanel' },
  { id: 'bc-002', name: 'Burberry London', brand: 'Burberry' },
  { id: 'bc-003', name: 'CH Women', brand: 'Carolina Herrera' },
  { id: 'bc-004', name: 'CH Men', brand: 'Carolina Herrera' },
  { id: 'bc-005', name: '1 Million', brand: 'Paco Rabanne' },
  { id: 'bc-007', name: 'Jadore', brand: 'Dior' },
  { id: 'bc-008', name: '212 VIP Men', brand: 'Carolina Herrera' },
  { id: 'bc-010', name: 'Black Orchid', brand: 'Tom Ford' },
  { id: 'bc-012', name: 'La Vie Est Belle', brand: 'Lancome' },
  { id: 'bc-021', name: 'Coco Mademoiselle', brand: 'Chanel' },
  { id: 'bc-027', name: 'Hypnotic Poison', brand: 'Dior' },
  { id: 'bc-034', name: '212 VIP Rose', brand: 'Carolina Herrera' },
  { id: 'bc-070', name: 'Bleu de Chanel', brand: 'Chanel' },
  { id: 'bc-100', name: 'Sauvage', brand: 'Dior' },
  { id: 'bc-105', name: 'Lady Million', brand: 'Paco Rabanne' },
  { id: 'bc-116', name: 'Invictus', brand: 'Paco Rabanne' },
  { id: 'bc-126', name: 'Good Girl', brand: 'Carolina Herrera' },
  { id: 'bc-136', name: 'Scandal', brand: 'Jean Paul Gaultier' },
  { id: 'bc-159', name: 'Libre', brand: 'YSL' },
  { id: 'bc-181', name: 'Bad Boy', brand: 'Carolina Herrera' },
  { id: 'bc-247', name: 'Baccarat Rouge 540', brand: 'MFK' },
  { id: 'bc-283', name: 'Sauvage Elixir', brand: 'Dior' },
  // AFEER
  { id: 'af-02', name: 'Asad Lattafa', brand: 'Lattafa' },
  { id: 'af-03', name: 'Yara Pink Lattafa', brand: 'Lattafa' },
  { id: 'af-07', name: 'Fakhar Rose Lattafa', brand: 'Lattafa' },
  // Decantes árabes
  { id: 'dec-02', name: 'Asad Zanzibar Lattafa', brand: 'Lattafa' },
  { id: 'dec-03', name: 'Qaed Al Fursan Lattafa', brand: 'Lattafa' },
  { id: 'dec-05', name: 'Khamrah Lattafa', brand: 'Lattafa' },
  { id: 'dec-08', name: 'Dukhan Lattafa', brand: 'Lattafa' },
  { id: 'dec-10', name: 'Badee Al Oud For Glory Lattafa', brand: 'Lattafa' },
  { id: 'dec-13', name: 'Chants Tenderina Maison Alhambra', brand: 'Maison Alhambra' },
  { id: 'dec-18', name: 'Yara Tous Lattafa', brand: 'Lattafa' },
];

function extractImgUrls(html) {
  const urls = new Set();
  // src="https://...jpg"
  const re = /(?:src|data-src|data-original|data-lazy)="(https?:\/\/[^"]+\.(?:jpg|jpeg|png|webp)[^"]*)"/gi;
  let m;
  while ((m = re.exec(html)) !== null) urls.add(m[1]);
  return [...urls];
}

// Filtra imagens que parecem fotos de produto (não ícones/banners/logos)
function filterProductImages(urls, perfumeName) {
  const nameWords = perfumeName.toLowerCase().split(/\s+/).filter(w => w.length > 2);
  return urls.filter(u => {
    const lower = u.toLowerCase();
    // Exclui logos, ícones, banners, placeholders
    if (lower.includes('logo') || lower.includes('icon') || lower.includes('banner') ||
        lower.includes('placeholder') || lower.includes('sprite') || lower.includes('favicon') ||
        lower.includes('pixel') || lower.includes('blank') || lower.includes('loading'))
      return false;
    // Preferências: imagens grandes, CDNs de e-commerce
    const goodCdn = lower.includes('shopify') || lower.includes('media-amazon') ||
                    lower.includes('giftexpress') || lower.includes('fragrancenet') ||
                    lower.includes('fragrancex') || lower.includes('jomashop') ||
                    lower.includes('bigcommerce') || lower.includes('scene7') ||
                    lower.includes('akamaihd') || lower.includes('lattafa') ||
                    lower.includes('product');
    // Tamanho na URL
    const hasLarge = lower.match(/\d{3,4}x\d{3,4}|\/large\/|full|original/i);
    return goodCdn || hasLarge || nameWords.some(w => lower.includes(w));
  });
}

async function trySite(zai, url, perfumeId, perfumeName) {
  try {
    const result = await zai.functions.invoke('page_reader', { url });
    const html = result.data?.html || '';
    const urls = extractImgUrls(html);
    const filtered = filterProductImages(urls, perfumeName);
    if (filtered.length > 0) {
      console.log(`  ✓ ${perfumeId}: found ${filtered.length} candidates from ${url.slice(0,50)}`);
      return filtered[0]; // pega o primeiro
    }
    return null;
  } catch (e) {
    return null;
  }
}

async function main() {
  const zai = await ZAI.create();
  const results = {};
  let found = 0;

  for (const p of PERFUMES) {
    console.log(`\n[${p.id}] ${p.name} (${p.brand})`);
    const query = encodeURIComponent(`${p.name} ${p.brand} perfume`);

    // Testa múltiplas fontes em sequência
    const sources = [
      `https://www.fragrancenet.com/perfume/search?q=${query}`,
      `https://www.fragrancex.com/search.html?search=${query}`,
      `https://www.giftexpress.com/catalogsearch/result/?q=${query}`,
      `https://www.jomashop.com/search?q=${query}`,
      `https://www.amazon.com/s?k=${query}`,
    ];

    let foundUrl = null;
    for (const url of sources) {
      foundUrl = await trySite(zai, url, p.id, p.name);
      if (foundUrl) break;
      await new Promise(r => setTimeout(r, 500)); // throttle
    }

    if (foundUrl) {
      results[p.id] = foundUrl;
      found++;
      console.log(`  → ${foundUrl.slice(0, 100)}`);
    } else {
      console.log(`  ✗ no image found`);
    }
  }

  fs.writeFileSync('/home/z/my-project/real-image-urls.json', JSON.stringify(results, null, 2));
  console.log(`\n=== SUMMARY ===`);
  console.log(`Found ${found}/${PERFUMES.length} image URLs`);
  console.log('Saved to /home/z/my-project/real-image-urls.json');
}

main().catch(console.error);
