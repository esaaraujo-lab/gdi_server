#!/usr/bin/env python3
"""
Sincroniza o projeto Mimi Mimos com o GitHub (pasta mimi/ no repo gdi_server).
Envia: worker.js, imagens, logo, manifest, etc.
Uso: python3 scripts/sync-github.py [--message "commit message"]
"""
import json, base64, urllib.request, os, sys, time

TOKEN = os.environ.get('GITHUB_TOKEN', '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')
REPO = 'esaaraujo-lab/gdi_server'
BRANCH = 'main'
BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

def github_api(method, path, data=None):
    url = f'https://api.github.com/repos/{REPO}/contents/{path}?ref={BRANCH}'
    headers = {'Authorization': f'token {TOKEN}', 'Accept': 'application/vnd.github+json'}
    req = urllib.request.Request(url, headers=headers)
    try:
        resp = urllib.request.urlopen(req)
        return json.loads(resp.read())
    except:
        return None

def upload_file(github_path, local_path, message):
    with open(local_path, 'rb') as f:
        b64 = base64.b64encode(f.read()).decode()
    # Check if exists (get SHA)
    existing = github_api('GET', github_path)
    sha = existing.get('sha') if existing else None
    body = json.dumps({
        'message': message,
        'content': b64,
        'branch': BRANCH,
        **({'sha': sha} if sha else {})
    }).encode()
    req = urllib.request.Request(
        f'https://api.github.com/repos/{REPO}/contents/{github_path}',
        data=body, method='PUT',
        headers={'Authorization': f'token {TOKEN}', 'Accept': 'application/vnd.github+json', 'Content-Type': 'application/json'}
    )
    try:
        resp = urllib.request.urlopen(req)
        return True
    except Exception as e:
        print(f'  ✗ {github_path}: {str(e)[:80]}')
        return False

def main():
    message = 'mimi: sync project files'
    if '--message' in sys.argv:
        idx = sys.argv.index('--message')
        message = sys.argv[idx + 1] if idx + 1 < len(sys.argv) else message

    files_to_sync = [
        ('mimi/worker.js', f'{BASE_DIR}/mimi-worker.js', f'{message} — update worker.js'),
        ('mimi/logo-bottle.png', f'{BASE_DIR}/public/logo-bottle.png', f'{message} — update logo'),
        ('mimi/icon-192.png', f'{BASE_DIR}/public/icon-192.png', f'{message} — update icon'),
        ('mimi/icon-512.png', f'{BASE_DIR}/public/icon-512.png', f'{message} — update icon'),
        ('mimi/apple-touch-icon.png', f'{BASE_DIR}/public/apple-touch-icon.png', f'{message} — update icon'),
        ('mimi/favicon-32.png', f'{BASE_DIR}/public/favicon-32.png', f'{message} — update favicon'),
        ('mimi/manifest.json', f'{BASE_DIR}/public/manifest.json', f'{message} — update manifest'),
    ]

    # Add all perfume images
    perfumes_dir = f'{BASE_DIR}/public/perfumes'
    if os.path.isdir(perfumes_dir):
        for f in sorted(os.listdir(perfumes_dir)):
            if f.endswith(('.jpg', '.png', '.webp')):
                files_to_sync.append((f'mimi/perfumes/{f}', f'{perfumes_dir}/{f}', f'{message} — update {f}'))

    print(f'Syncing {len(files_to_sync)} files to GitHub...')
    uploaded = 0
    for github_path, local_path, msg in files_to_sync:
        if not os.path.exists(local_path):
            print(f'  [skip] {os.path.basename(local_path)} (not found)')
            continue
        fname = os.path.basename(local_path)
        process_msg = f'  {fname}... '
        if upload_file(github_path, local_path, msg):
            uploaded += 1
            print(process_msg + '✓')
        else:
            print(process_msg + '✗')
        time.sleep(0.4)  # throttle

    print(f'\n=== {uploaded}/{len(files_to_sync)} files synced to GitHub ===')
    print(f'Repo: https://github.com/{REPO}/tree/{BRANCH}/mimi')

if __name__ == '__main__':
    main()
