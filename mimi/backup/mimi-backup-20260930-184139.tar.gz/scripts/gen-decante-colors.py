#!/usr/bin/env python3
"""
Gera imagens de decantes com cores por gênero a partir do modelo base.
- Feminino: rosa/roxo/vermelho/magenta
- Masculino: preto/azul/cinza
- Unissex/Árabe: âmbar/dourado/marrom/bege
"""
from PIL import Image, ImageEnhance, ImageFilter
import os

MODEL = '/tmp/decante-model.png'
OUT_DIR = '/home/z/my-project/public/perfumes'
os.makedirs(OUT_DIR, exist_ok=True)

# Tint function: aplica uma cor sobre a imagem mantendo luminosidade
def tint_image(img, target_rgb, intensity=0.6):
    """Aplica tint sobre a imagem, preservando brilho/contraste."""
    r, g, b = img.split()
    # Converte para RGBA
    img_rgba = img.convert('RGBA')
    # Cria overlay com a cor alvo
    overlay = Image.new('RGBA', img.size, target_rgb + (0,))
    # Blend usando a luminosidade da imagem original como alpha
    gray = img.convert('L')
    # Aumenta contraste do grayscale para melhor definição
    gray = ImageEnhance.Contrast(gray).enhance(1.2)
    # Aplica a cor proporcional à luminosidade
    tinted = Image.merge('RGBA', (
        Image.eval(gray, lambda x: int(x * target_rgb[0] / 255 * intensity + (1-intensity) * 9)),  # mix com obsidian
        Image.eval(gray, lambda x: int(x * target_rgb[1] / 255 * intensity + (1-intensity) * 10)),
        Image.eval(gray, lambda x: int(x * target_rgb[2] / 255 * intensity + (1-intensity) * 15)),
        img_rgba.split()[3]
    ))
    return tinted

def add_gold_border(img, border_width=4):
    """Adiciona borda dourada."""
    gold = (212, 175, 55)
    overlay = Image.new('RGBA', img.size, (0,0,0,0))
    from PIL import ImageDraw
    draw = ImageDraw.Draw(overlay)
    draw.rectangle([0, 0, img.size[0]-1, border_width-1], fill=gold + (80,))
    draw.rectangle([0, img.size[1]-border_width, img.size[0]-1, img.size[1]-1], fill=gold + (80,))
    draw.rectangle([0, 0, border_width-1, img.size[1]-1], fill=gold + (80,))
    draw.rectangle([img.size[0]-border_width, 0, img.size[0]-1, img.size[1]-1], fill=gold + (80,))
    return Image.alpha_composite(img.convert('RGBA'), overlay)

DECANTES = [
    # Feminino (rosa/roxo/vermelho)
    ('dec-fem-01.jpg', (255, 105, 180), 'pink'),        # Pink
    ('dec-fem-02.jpg', (148, 87, 235), 'purple'),        # Purple
    ('dec-fem-03.jpg', (220, 20, 60), 'crimson'),       # Crimson
    ('dec-fem-04.jpg', (255, 183, 197), 'rose-gold'),   # Rose gold
    ('dec-fem-05.jpg', (255, 0, 255), 'magenta'),        # Magenta
    ('dec-fem-06.jpg', (255, 193, 203), 'champagne'),   # Pink champagne
    # Masculino (preto/azul)
    ('dec-masc-01.jpg', (30, 30, 35), 'black'),          # Black
    ('dec-masc-02.jpg', (25, 40, 100), 'navy'),          # Navy blue
    ('dec-masc-03.jpg', (60, 60, 70), 'charcoal'),      # Charcoal
    ('dec-masc-04.jpg', (20, 30, 80), 'midnight'),       # Midnight blue
    # Unissex/Árabe (neutros)
    ('dec-uni-01.jpg', (191, 143, 0), 'amber'),          # Amber
    ('dec-uni-02.jpg', (212, 175, 55), 'gold'),          # Gold
    ('dec-uni-03.jpg', (139, 90, 43), 'brown'),          # Brown
    ('dec-uni-04.jpg', (200, 180, 140), 'beige'),       # Beige
]

model_img = Image.open(MODEL).convert('RGB')
print(f'Model image: {model_img.size}')

for filename, color, name in DECANTES:
    out_path = os.path.join(OUT_DIR, filename)
    if os.path.exists(out_path):
        print(f'[skip] {filename}')
        continue
    # Apply tint
    tinted = tint_image(model_img, color, intensity=0.55)
    # Add gold border
    final = add_gold_border(tinted)
    # Convert to RGB and save as JPG
    final.convert('RGB').save(out_path, 'JPEG', quality=90)
    size_kb = os.path.getsize(out_path) // 1024
    print(f'[ok] {filename} ({name}, {size_kb}KB)')

print(f'\n=== {len(DECANTES)} decante images generated ===')
