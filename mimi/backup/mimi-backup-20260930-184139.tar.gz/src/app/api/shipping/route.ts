import { NextRequest, NextResponse } from "next/server";

export const runtime = "edge";

/**
 * API de Cálculo de Frete via Correios.
 *
 * GET /api/shipping?cep=01310100&weight=0.3&length=20&width=15&height=10
 *
 * Usa a API dos Correios (REST) para calcular PAC e SEDEX.
 * Em produção: cachear resultados por CEP para evitar rate limit.
 */

interface ShippingOption {
  code: number;
  name: string;
  price: number;
  days: number;
  error?: string;
}

const CORREIOS_URL =
  "https://ws.correios.com.br/calculador/CalcPrecoPrazo.aspx";

// Códigos de serviço dos Correios
const SERVICES = {
  PAC: "04510", // PAC sem contrato
  SEDEX: "04014", // SEDEX sem contrato
};

// CEP de origem da loja (São Paulo)
const ORIGIN_CEP = "01310100";

async function calcCorreios(
  service: string,
  cepDestino: string,
  weight: number,
  length: number,
  width: number,
  height: number
): Promise<ShippingOption> {
  const params = new URLSearchParams({
    sCepOrigem: ORIGIN_CEP,
    sCepDestino: cepDestino.replace(/\D/g, ""),
    nVlPeso: weight.toString(),
    nCdFormato: "1", // Caixa/Pacote
    nVlComprimento: length.toString(),
    nVlAltura: height.toString(),
    nVlLargura: width.toString(),
    nCdServico: service,
    nCdEmpresa: "",
    sDsSenha: "",
    nVlDiametro: "0",
    nVlValorDeclarado: "0",
    sCdMaoPropria: "n",
    StrRetorno: "xml",
  });

  try {
    const res = await fetch(`${CORREIOS_URL}?${params}`, {
      headers: { "User-Agent": "MimiMimos/1.0" },
    });
    const xml = await res.text();

    // Parse simples do XML
    const valorMatch = xml.match(/<Valor>([\d,.]+)<\/Valor>/);
    const prazoMatch = xml.match(/<PrazoEntrega>(\d+)<\/PrazoEntrega>/);
    const erroMatch = xml.match(/<MsgErro>([^<]+)<\/MsgErro>/);

    if (erroMatch && !valorMatch) {
      return {
        code: parseInt(service),
        name: service === SERVICES.PAC ? "PAC" : "SEDEX",
        price: 0,
        days: 0,
        error: erroMatch[1],
      };
    }

    const price = valorMatch
      ? parseFloat(valorMatch[1].replace(",", "."))
      : 0;
    const days = prazoMatch ? parseInt(prazoMatch[1]) : 0;

    return {
      code: parseInt(service),
      name: service === SERVICES.PAC ? "PAC" : "SEDEX",
      price,
      days,
    };
  } catch (e) {
    return {
      code: parseInt(service),
      name: service === SERVICES.PAC ? "PAC" : "SEDEX",
      price: 0,
      days: 0,
      error: "Erro ao conectar com os Correios",
    };
  }
}

export async function GET(req: NextRequest) {
  const url = new URL(req.url);
  const cep = url.searchParams.get("cep");
  const weight = parseFloat(url.searchParams.get("weight") || "0.3");
  const length = parseFloat(url.searchParams.get("length") || "20");
  const width = parseFloat(url.searchParams.get("width") || "15");
  const height = parseFloat(url.searchParams.get("height") || "10");

  if (!cep || cep.replace(/\D/g, "").length !== 8) {
    return NextResponse.json(
      {
        error: "CEP inválido. Informe 8 dígitos.",
        options: [],
      },
      { status: 400 }
    );
  }

  // Calcula PAC e SEDEX em paralelo
  const [pac, sedex] = await Promise.all([
    calcCorreios(SERVICES.PAC, cep, weight, length, width, height),
    calcCorreios(SERVICES.SEDEX, cep, weight, length, width, height),
  ]);

  // Adiciona opção de retirada na loja (frete grátis)
  const options: ShippingOption[] = [
    {
      code: 0,
      name: "Retirar na Loja",
      price: 0,
      days: 0,
    },
    pac,
    sedex,
  ];

  return NextResponse.json({
    cep,
    origin: ORIGIN_CEP,
    options,
  });
}
