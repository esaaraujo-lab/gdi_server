import type { Metadata, Viewport } from "next";
import { Cormorant_Garamond, Plus_Jakarta_Sans } from "next/font/google";
import "./globals.css";

const cormorant = Cormorant_Garamond({
  variable: "--font-cormorant",
  subsets: ["latin"],
  weight: ["400", "600", "700"],
  style: ["normal", "italic"],
  display: "swap",
});

const jakarta = Plus_Jakarta_Sans({
  variable: "--font-jakarta",
  subsets: ["latin"],
  weight: ["300", "400", "500", "600", "700"],
  display: "swap",
});

export const metadata: Metadata = {
  metadataBase: new URL("https://mimi-mimos.local"),
  title: "Mimi Mimos | Haute Parfumerie & Brand Collection 25ml",
  description:
    "Catálogo exclusivo de perfumes importados e árabes Brand Collection 25ml. O luxo das melhores fragrâncias do mundo na palma da sua mão.",
  keywords: [
    "perfumes importados",
    "perfumaria árabe",
    "Brand Collection",
    "25ml",
    "Mimi Mimos",
    "luxo",
    "Pix",
  ],
  authors: [{ name: "Mimi Mimos" }],
  applicationName: "Mimi Mimos",
  manifest: "/manifest.json",
  appleWebApp: {
    capable: true,
    statusBarStyle: "black-translucent",
    title: "Mimi Mimos",
  },
  icons: {
    icon: [
      { url: "/favicon-32.png", sizes: "32x32", type: "image/png" },
      { url: "/icon-192.png", sizes: "192x192", type: "image/png" },
      { url: "/icon-512.png", sizes: "512x512", type: "image/png" },
    ],
    apple: [{ url: "/apple-touch-icon.png", sizes: "180x180", type: "image/png" }],
    shortcut: ["/favicon-32.png"],
  },
  openGraph: {
    title: "Mimi Mimos | Haute Parfumerie & Brand Collection 25ml",
    description:
      "Catálogo exclusivo de perfumes importados e árabes Brand Collection 25ml. O luxo das melhores fragrâncias do mundo na palma da sua mão.",
    url: "/",
    siteName: "Mimi Mimos",
    images: [{ url: "/og-cover.jpg", width: 1344, height: 768, alt: "Mimi Mimos" }],
    type: "website",
    locale: "pt_BR",
  },
  twitter: {
    card: "summary_large_image",
    title: "Mimi Mimos | Haute Parfumerie",
    description: "Perfumes importados e árabes Brand Collection 25ml",
    images: ["/og-cover.jpg"],
  },
  formatDetection: { telephone: false },
};

export const viewport: Viewport = {
  themeColor: "#090a0f",
  width: "device-width",
  initialScale: 1,
  maximumScale: 1,
  userScalable: false,
  viewportFit: "cover",
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="pt-BR" suppressHydrationWarning>
      <head>
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="anonymous" />
        <link
          rel="stylesheet"
          href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css"
        />
      </head>
      <body
        className={`${cormorant.variable} ${jakarta.variable} antialiased bg-background text-foreground min-h-screen flex flex-col selection:bg-gold-500 selection:text-obsidian-950`}
      >
        {children}
      </body>
    </html>
  );
}
