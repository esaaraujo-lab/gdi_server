"use client";

import { useEffect } from "react";
import { AnnouncementBar } from "@/components/luxury/Header";
import Header from "@/components/luxury/Header";
import Hero from "@/components/luxury/Hero";
import FeaturedCarousel from "@/components/luxury/FeaturedCarousel";
import ScentMatcher from "@/components/luxury/ScentMatcher";
import CatalogGrid from "@/components/luxury/CatalogGrid";
import HowToUse from "@/components/luxury/HowToUse";
import SeasonalBanner from "@/components/luxury/SeasonalBanner";
import OlfactoryQuiz from "@/components/luxury/OlfactoryQuiz";
import ReferralSystem from "@/components/luxury/ReferralSystem";
import RecentlyViewed from "@/components/luxury/RecentlyViewed";
import CartDrawer from "@/components/luxury/CartDrawer";
import PixModal from "@/components/luxury/PixModal";
import NotifyModal from "@/components/luxury/NotifyModal";
import AdminAuthModal from "@/components/luxury/AdminAuthModal";
import AdminPanel from "@/components/luxury/AdminPanel";
import QuickViewModal from "@/components/luxury/QuickViewModal";
import FavoritesModal from "@/components/luxury/FavoritesModal";
import FloatingWhatsApp from "@/components/luxury/FloatingWhatsApp";
import CursorCanvas from "@/components/luxury/CursorCanvas";
import PwaInstallBanner from "@/components/luxury/PwaInstallBanner";
import NotificationManager from "@/components/luxury/NotificationManager";
import SiteFooter from "@/components/luxury/SiteFooter";
import ServiceWorkerRegister from "@/components/luxury/ServiceWorkerRegister";
import { useUI } from "@/lib/stores-combined";
import { Toaster } from "sonner";

export default function Home() {
  const setCartOpen = useUI((s) => s.setCartOpen);

  useEffect(() => {
    // PWA shortcut: ?cart=open
    const params = new URLSearchParams(window.location.search);
    if (params.get("cart") === "open") {
      setCartOpen(true);
    }
  }, [setCartOpen]);

  return (
    <>
      <CursorCanvas />
      <ServiceWorkerRegister />
      <Toaster
        position="top-right"
        toastOptions={{
          style: {
            background: "rgba(18,20,29,0.92)",
            border: "1px solid rgba(212,175,55,0.4)",
            color: "#fef9e7",
            backdropFilter: "blur(12px)",
          },
        }}
      />

      <div className="flex-grow flex flex-col">
        <AnnouncementBar />
        <Header />
        <main className="flex-grow">
          <Hero />
          <SeasonalBanner />
          <FeaturedCarousel />
          <ScentMatcher />
          <CatalogGrid />
          <HowToUse />
          <OlfactoryQuiz />
          <ReferralSystem />
          <RecentlyViewed />
        </main>
        <SiteFooter />
      </div>

      {/* Modals & Drawers */}
      <CartDrawer />
      <PixModal />
      <NotifyModal />
      <QuickViewModal />
      <FavoritesModal />
      <AdminAuthModal />
      <AdminPanel />
      <PwaInstallBanner />
      <NotificationManager />
      <FloatingWhatsApp />
    </>
  );
}
