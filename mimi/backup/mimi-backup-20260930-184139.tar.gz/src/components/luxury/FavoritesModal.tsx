"use client";

import { useStore, useUI } from "@/lib/stores-combined";
import { formatBRL } from "@/lib/pix";
import { playAtomizerSpraySound } from "@/lib/audio";
import { toast } from "sonner";
import { X, Heart, Trash2, SprayCan, MessageCircleWarning } from "lucide-react";

const IMG_FALLBACK =
  "https://placehold.co/400x500/12141d/d4af37?text=Mimi+Mimos+25ml";

export default function FavoritesModal() {
  const open = useUI((s) => s.favoritesOpen);
  const setOpen = useUI((s) => s.setFavoritesOpen);
  const favorites = useStore((s) => s.favorites);
  const products = useStore((s) => s.products);
  const toggleFavorite = useStore((s) => s.toggleFavorite);
  const addToCart = useStore((s) => s.addToCart);
  const openNotify = useUI((s) => s.openNotify);

  if (!open) return null;

  const favProducts = products.filter((p) => favorites.includes(p.id));

  return (
    <div className="fixed inset-0 z-[55] flex items-center justify-center p-4 bg-black/80 backdrop-blur-md">
      <div className="glass-panel-gold max-w-2xl w-full rounded-2xl p-6 relative border border-gold-500/40 shadow-2xl max-h-[85vh] overflow-y-auto">
        <button
          onClick={() => setOpen(false)}
          className="absolute top-4 right-4 text-gray-400 hover:text-white"
          aria-label="Fechar"
        >
          <X size={20} />
        </button>

        <div className="flex items-center gap-3 mb-5 border-b border-gold-500/20 pb-4">
          <div className="w-10 h-10 rounded-xl bg-red-500/15 border border-red-500/30 flex items-center justify-center text-red-400">
            <Heart size={20} className="fill-red-500" />
          </div>
          <div>
            <h3 className="font-serif-luxury text-xl font-bold text-white">
              Seus Favoritos
            </h3>
            <p className="text-[11px] text-gold-300">
              {favProducts.length}{" "}
              {favProducts.length === 1 ? "perfume salvo" : "perfumes salvos"} ♥
            </p>
          </div>
        </div>

        {favProducts.length === 0 ? (
          <div className="text-center py-12 text-gray-500">
            <Heart
              className="mx-auto mb-3 text-gold-500/20"
              size={42}
            />
            <p className="text-xs">
              Você ainda não favoritou nenhum perfume.
            </p>
            <p className="text-[11px] text-gray-600 mt-1">
              Toque no coração nos cards para salvar aqui.
            </p>
            <button
              onClick={() => setOpen(false)}
              className="mt-4 btn-gold px-6 py-2 rounded-full text-xs"
            >
              Explorar Catálogo
            </button>
          </div>
        ) : (
          <div className="space-y-3">
            {favProducts.map((p) => (
              <div
                key={p.id}
                className="glass-panel p-3 rounded-xl flex items-center gap-3 border border-gold-500/10 hover:border-gold-500/30 transition-colors"
              >
                { }
                <img
                  src={p.image}
                  onError={(e) => {
                    (e.target as HTMLImageElement).src = IMG_FALLBACK;
                  }}
                  alt={p.name}
                  className="w-14 h-14 object-cover rounded-lg bg-obsidian-950 shrink-0"
                />
                <div className="flex-grow min-w-0">
                  <h5 className="text-xs font-bold text-white truncate">
                    {p.name}
                  </h5>
                  <p className="text-[10px] text-gold-300 truncate">
                    {p.inspiration}
                  </p>
                  <p className="text-[10px] text-gray-500 mt-0.5">
                    {p.code} • {p.intensity}
                  </p>
                </div>
                <div className="text-right shrink-0 flex flex-col items-end gap-1.5">
                  <span className="text-xs font-serif-luxury font-bold text-gold-400">
                    {formatBRL(p.price)}
                  </span>
                  <div className="flex items-center gap-1.5">
                    {p.inStock ? (
                      <button
                        onClick={() => {
                          playAtomizerSpraySound();
                          addToCart(p);
                          toast.success(`${p.name} adicionado à sacola!`);
                        }}
                        className="btn-gold px-2.5 py-1 rounded-lg text-[10px] flex items-center gap-1"
                        aria-label="Adicionar à sacola"
                      >
                        <SprayCan size={11} />
                      </button>
                    ) : (
                      <button
                        onClick={() => {
                          setOpen(false);
                          openNotify(p);
                        }}
                        className="bg-emerald-700/30 border border-emerald-500/40 text-emerald-300 px-2.5 py-1 rounded-lg text-[10px]"
                        aria-label="Avise-me"
                      >
                        <MessageCircleWarning size={11} />
                      </button>
                    )}
                    <button
                      onClick={() => {
                        toggleFavorite(p.id);
                        toast.success("Removido dos favoritos.");
                      }}
                      className="text-red-400 hover:text-red-300 p-1"
                      aria-label="Remover dos favoritos"
                    >
                      <Trash2 size={13} />
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
