"use client";

interface LogoProps {
  size?: "sm" | "md" | "lg" | "xl";
  showSubtitle?: boolean;
  subtitle?: string;
  className?: string;
}

const SIZES = {
  sm: { badge: "w-10 h-10", title: "text-lg", subtitle: "text-[8px]" },
  md: { badge: "w-14 h-14", title: "text-2xl md:text-3xl", subtitle: "text-[9px]" },
  lg: { badge: "w-20 h-20", title: "text-3xl md:text-4xl", subtitle: "text-[11px]" },
  xl: { badge: "w-24 h-24", title: "text-4xl md:text-5xl", subtitle: "text-xs" },
};

/** Logo reutilizável: frasco de perfume (imagem processada) + texto MIMI MIMOS. */
export default function Logo({
  size = "md",
  showSubtitle = true,
  subtitle = "PERFUME STORE",
  className = "",
}: LogoProps) {
  const s = SIZES[size];
  return (
    <div className={`flex items-center gap-3 group ${className}`}>
      <div
        className={`${s.badge} rounded-full border-2 border-gold-500/50 flex items-center justify-center bg-obsidian-900/80 group-hover:border-gold-400 group-hover:shadow-lg group-hover:shadow-gold-500/20 transition-all overflow-hidden shrink-0`}
      >
        <img
          src="/logo-bottle.png"
          alt="Mimi Mimos — frasco de perfume"
          className="w-full h-full object-cover"
        />
      </div>
      <div className="flex flex-col">
        <span
          className={`font-serif-luxury ${s.title} font-bold tracking-wider gold-shimmer-text uppercase leading-none`}
        >
          Mimi Mimos
        </span>
        {showSubtitle && (
          <span
            className={`${s.subtitle} uppercase tracking-[0.25em] text-gold-300/70 mt-1`}
          >
            {subtitle}
          </span>
        )}
      </div>
    </div>
  );
}
