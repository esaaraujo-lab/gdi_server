"use client";

import { useMemo } from "react";
import { useStore, useUI } from "@/lib/stores-combined";
import { formatBRL } from "@/lib/pix";
import { playSoftChime } from "@/lib/audio";
import { Award, Star, ChevronRight } from "lucide-react";

const IMG_FALLBACK =
  "https://placehold.co/400x500/12141d/d4af37?text=Mimi+Mimos+25ml";

/** Carrossel horizontal dos perfumes mais bem avaliados (Top 4). */
export default function FeaturedCarousel() {
  const products = useStore((s) => s.products);
  const openQuickView = useUI((s) => s.openQuickView);

  const featured = useMemo(
    () =>
      [...products]
        .sort(
          (a, b) =>
            (b.rating || 0) - (a.rating || 0) ||
            (b.reviewCount || 0) - (a.reviewCount || 0)
        )
        .slice(0, 4),
    [products]
  );

  if (featured.length === 0) return null;

  return (
    <section
      id="featuredSection"
      className="py-10 px-4 sm:px-8 border-b border-gold-500/10 bg-gradient-to-b from-obsidian-950 to-transparent"
    >
      <div className="max-w-7xl mx-auto">
        <div className="flex items-center justify-between mb-5">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-gold-500/15 border border-gold-500/40 flex items-center justify-center text-gold-400">
              <Award size={20} />
            </div>
            <div>
              <h2 className="font-serif-luxury text-2xl md:text-3xl font-bold text-white leading-none">
                Curadoria Premium
              </h2>
              <p className="text-[11px] text-gold-300/70 uppercase tracking-widest mt-1">
                Os mais aclamados da temporada
              </p>
            </div>
          </div>
          <a
            href="#catalogSection"
            className="hidden sm:flex items-center gap-1 text-xs text-gold-300 hover:text-gold-200 transition-colors group"
          >
            Ver catálogo completo
            <ChevronRight
              size={14}
              className="group-hover:translate-x-0.5 transition-transform"
            />
          </a>
        </div>

        <div className="flex gap-4 overflow-x-auto pb-4 -mx-4 px-4 snap-x snap-mandatory scrollbar-luxury">
          {featured.map((p, i) => (
            <button
              key={p.id}
              onClick={() => {
                playSoftChime();
                openQuickView(p);
              }}
              className="group relative shrink-0 w-[260px] snap-start text-left"
            >
              <div className="relative rounded-2xl overflow-hidden border border-gold-500/20 group-hover:border-gold-400/60 transition-all shadow-2xl bg-obsidian-900">
                {/* Rank badge */}
                <div className="absolute top-3 left-3 z-10 w-8 h-8 rounded-full bg-gradient-to-br from-gold-400 to-gold-600 flex items-center justify-center text-obsidian-950 font-serif-luxury font-bold text-sm shadow-lg">
                  {i + 1}
                </div>

                {/* Image */}
                <div className="relative h-72 overflow-hidden">
                  { }
                  <img
                    src={p.image}
                    onError={(e) => {
                      (e.target as HTMLImageElement).src = IMG_FALLBACK;
                    }}
                    alt={p.name}
                    className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-obsidian-950 via-obsidian-950/20 to-transparent" />
                </div>

                {/* Info overlay */}
                <div className="absolute bottom-0 left-0 right-0 p-4">
                  <div className="flex items-center gap-1.5 mb-1">
                    <span className="text-[9px] uppercase tracking-wider font-bold px-2 py-0.5 rounded-full bg-gold-500/20 border border-gold-500/40 text-gold-200 backdrop-blur-sm">
                      {p.code}
                    </span>
                    <span className="flex items-center gap-0.5 text-[10px] text-gold-300 font-bold backdrop-blur-sm bg-obsidian-950/40 px-1.5 py-0.5 rounded-full">
                      <Star size={9} className="fill-gold-400" />
                      {p.rating?.toFixed(1)}
                    </span>
                  </div>
                  <h4 className="font-serif-luxury text-base font-bold text-white leading-snug line-clamp-1">
                    {p.name}
                  </h4>
                  <p className="text-[10px] text-gold-300/90 line-clamp-1 mb-1.5">
                    {p.inspiration}
                  </p>
                  <div className="flex items-center justify-between">
                    <span className="font-serif-luxury text-lg font-bold text-gold-400">
                      {formatBRL(p.price)}
                    </span>
                    <span className="text-[9px] uppercase tracking-wider text-gold-200/70 group-hover:text-gold-300 transition-colors flex items-center gap-0.5">
                      Ver detalhes
                      <ChevronRight size={10} />
                    </span>
                  </div>
                </div>
              </div>
            </button>
          ))}
        </div>
      </div>
    </section>
  );
}
