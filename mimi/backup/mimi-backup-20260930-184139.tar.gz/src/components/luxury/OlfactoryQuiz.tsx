"use client";

import { useState } from "react";
import { useStore, useUI } from "@/lib/stores-combined";
import { Wand2, X, ArrowRight, RotateCcw, Sparkles, Check } from "lucide-react";
import type { Perfume } from "@/lib/perfumes";

interface Question {
  id: number;
  text: string;
  options: {
    label: string;
    tags: string[];
    emoji: string;
  }[];
}

const QUESTIONS: Question[] = [
  {
    id: 1,
    text: "Qual desses aromas te atrai mais?",
    options: [
      { label: "Doce e quente (canela, baunilha)", tags: ["Baunilha", "Canela", "Gourmand"], emoji: "🍯" },
      { label: "Floral e delicado (rosa, jasmim)", tags: ["Rosa", "Jasmim", "Floral"], emoji: "🌸" },
      { label: "Amadeirado e intenso (oud, âmbar)", tags: ["Oud", "Âmbar", "Amadeirado"], emoji: "🪵" },
      { label: "Cítrico e fresco (limão, bergamota)", tags: ["Cítrico", "Fresco"], emoji: "🍋" },
    ],
  },
  {
    id: 2,
    text: "Para qual ocasião você usa mais perfume?",
    options: [
      { label: "Trabalho/dia a dia (sutil)", tags: ["Casual", "Cítrico"], emoji: "💼" },
      { label: "Festas e eventos (marcante)", tags: ["Gourmand", "Âmbar"], emoji: "🎉" },
      { label: "Encontros românticos (sensual)", tags: ["Rosa", "Baunilha"], emoji: "💕" },
      { label: "Uso diário versátil", tags: ["Âmbar", "Lavanda"], emoji: "🌟" },
    ],
  },
  {
    id: 3,
    text: "Qual estação prefere para usar perfume?",
    options: [
      { label: "Verão (fresco e leve)", tags: ["Cítrico", "Coco"], emoji: "☀️" },
      { label: "Inverno (quente e intenso)", tags: ["Oud", "Baunilha", "Canela"], emoji: "❄️" },
      { label: "Primavera (floral e alegre)", tags: ["Rosa", "Jasmim", "Floral"], emoji: "🌷" },
      { label: "Outono (amadeirado e aconchegante)", tags: ["Âmbar", "Patchouli", "Sândalo"], emoji: "🍂" },
    ],
  },
  {
    id: 4,
    text: "Qual estilo combina com você?",
    options: [
      { label: "Feminino e elegante", tags: ["Rosa", "Floral", "Baunilha"], emoji: "👗" },
      { label: "Masculino e ousado", tags: ["Couro", "Amadeirado", "Cítrico"], emoji: "🎩" },
      { label: "Árabe e exótico", tags: ["Oud", "Âmbar", "Gourmand"], emoji: "🌙" },
      { label: "Unissex e moderno", tags: ["Âmbar", "Lavanda"], emoji: "✨" },
    ],
  },
];

export default function OlfactoryQuiz() {
  const products = useStore((s) => s.products);
  const openQuickView = useUI((s) => s.openQuickView);
  const [open, setOpen] = useState(false);
  const [current, setCurrent] = useState(0);
  const [answers, setAnswers] = useState<string[][]>([]);
  const [results, setResults] = useState<Perfume[] | null>(null);

  const selectAnswer = (tags: string[]) => {
    const newAnswers = [...answers, tags];
    setAnswers(newAnswers);
    if (current < QUESTIONS.length - 1) {
      setCurrent(current + 1);
    } else {
      // Calcula resultado
      const allTags = newAnswers.flat();
      const scored = products
        .map((p) => {
          const productTags = (p.tags || []).map((t) => t.toLowerCase());
          const noteTags = `${p.notesTopo} ${p.notesCoracao} ${p.notesFundo}`
            .toLowerCase();
          let score = 0;
          allTags.forEach((tag) => {
            const tagLower = tag.toLowerCase();
            if (productTags.some((t) => t.includes(tagLower))) score += 3;
            if (noteTags.includes(tagLower)) score += 2;
          });
          return { product: p, score };
        })
        .filter((s) => s.score > 0)
        .sort((a, b) => b.score - a.score)
        .slice(0, 3);
      setResults(scored.map((s) => s.product));
    }
  };

  const reset = () => {
    setCurrent(0);
    setAnswers([]);
    setResults(null);
  };

  return (
    <>
      {/* Botão para abrir o quiz */}
      <section className="py-8 px-4 max-w-7xl mx-auto">
        <button
          onClick={() => {
            reset();
            setOpen(true);
          }}
          className="w-full glass-panel-gold rounded-2xl p-6 border border-gold-500/40 hover:border-gold-400/60 transition-all group flex items-center justify-between gap-4"
        >
          <div className="flex items-center gap-4">
            <div className="w-12 h-12 rounded-xl bg-gold-500/20 border border-gold-500/40 flex items-center justify-center text-gold-300 group-hover:scale-110 transition-transform shrink-0">
              <Wand2 size={24} />
            </div>
            <div className="text-left">
              <h3 className="font-serif-luxury text-xl font-bold text-white">
                Encontre Seu Perfume Ideal
              </h3>
              <p className="text-xs text-gray-400 mt-0.5">
                Quiz olfativo personalizado — 4 perguntas rápidas
              </p>
            </div>
          </div>
          <ArrowRight className="text-gold-400 group-hover:translate-x-1 transition-transform shrink-0" />
        </button>
      </section>

      {/* Modal do Quiz */}
      {open && (
        <div className="fixed inset-0 z-[75] flex items-center justify-center p-4 bg-black/85 backdrop-blur-md">
          <div className="glass-panel max-w-lg w-full rounded-2xl p-6 relative border border-gold-500/40 shadow-2xl max-h-[90vh] overflow-y-auto">
            <button
              onClick={() => setOpen(false)}
              className="absolute top-4 right-4 text-gray-400 hover:text-white"
              aria-label="Fechar"
            >
              <X size={20} />
            </button>

            {!results ? (
              <>
                <div className="flex items-center gap-2 mb-4">
                  <Wand2 className="text-gold-400" size={20} />
                  <span className="text-[10px] uppercase tracking-widest text-gold-300/70">
                    Quiz Olfativo {current + 1}/{QUESTIONS.length}
                  </span>
                </div>
                {/* Progress bar */}
                <div className="w-full h-1.5 bg-obsidian-800 rounded-full mb-6 overflow-hidden">
                  <div
                    className="h-full bg-gradient-to-r from-gold-500 to-gold-300 transition-all duration-500"
                    style={{
                      width: `${((current + 1) / QUESTIONS.length) * 100}%`,
                    }}
                  />
                </div>

                <h3 className="font-serif-luxury text-xl font-bold text-white mb-4">
                  {QUESTIONS[current].text}
                </h3>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  {QUESTIONS[current].options.map((opt, i) => (
                    <button
                      key={i}
                      onClick={() => selectAnswer(opt.tags)}
                      className="text-left p-3 rounded-xl bg-obsidian-800/60 border border-gold-500/20 hover:border-gold-400/50 hover:bg-gold-500/10 transition-all group"
                    >
                      <span className="text-2xl block mb-1">{opt.emoji}</span>
                      <span className="text-xs text-white font-medium">
                        {opt.label}
                      </span>
                    </button>
                  ))}
                </div>

                {current > 0 && (
                  <button
                    onClick={() => {
                      setCurrent(current - 1);
                      setAnswers(answers.slice(0, -1));
                    }}
                    className="mt-4 text-xs text-gray-400 hover:text-white flex items-center gap-1"
                  >
                    <RotateCcw size={11} /> Voltar
                  </button>
                )}
              </>
            ) : (
              <>
                <div className="text-center mb-5">
                  <div className="w-14 h-14 rounded-full bg-gold-500/20 border border-gold-500/40 flex items-center justify-center mx-auto mb-3 text-gold-400">
                    <Sparkles size={28} />
                  </div>
                  <h3 className="font-serif-luxury text-2xl font-bold text-white">
                    Seus Perfumes Ideais!
                  </h3>
                  <p className="text-xs text-gray-400 mt-1">
                    Baseado nas suas respostas, selecionamos 3 fragrâncias
                    perfeitas para você
                  </p>
                </div>

                <div className="space-y-3">
                  {results.map((p, i) => (
                    <button
                      key={p.id}
                      onClick={() => {
                        openQuickView(p);
                        setOpen(false);
                      }}
                      className="w-full flex items-center gap-3 p-3 rounded-xl bg-obsidian-800/60 border border-gold-500/20 hover:border-gold-400/50 transition-all text-left group"
                    >
                      <div className="w-8 h-8 rounded-full bg-gold-500/20 border border-gold-500/40 flex items-center justify-center text-gold-400 font-bold text-sm shrink-0">
                        {i + 1}
                      </div>
                      <img
                        src={p.image}
                        alt={p.name}
                        className="w-12 h-12 object-cover rounded-lg bg-obsidian-950 shrink-0"
                      />
                      <div className="flex-grow min-w-0">
                        <h4 className="text-xs font-bold text-white truncate">
                          {p.name}
                        </h4>
                        <p className="text-[10px] text-gold-300/80 truncate">
                          {p.inspiration}
                        </p>
                        <div className="flex items-center gap-1 mt-0.5">
                          {(p.tags || []).slice(0, 2).map((t) => (
                            <span
                              key={t}
                              className="text-[9px] bg-gold-400/10 text-gold-300 border border-gold-400/20 rounded px-1 py-0.5"
                            >
                              #{t}
                            </span>
                          ))}
                        </div>
                      </div>
                      <ArrowRight
                        size={14}
                        className="text-gold-400 group-hover:translate-x-1 transition-transform shrink-0"
                      />
                    </button>
                  ))}
                </div>

                <button
                  onClick={reset}
                  className="mt-5 w-full btn-gold py-2.5 rounded-xl text-xs uppercase tracking-wider flex items-center justify-center gap-2"
                >
                  <RotateCcw size={13} /> Refazer Quiz
                </button>
              </>
            )}
          </div>
        </div>
      )}
    </>
  );
}
