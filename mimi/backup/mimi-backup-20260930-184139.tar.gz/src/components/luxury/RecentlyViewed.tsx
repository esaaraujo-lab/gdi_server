"use client";

import { useStore, useUI } from "@/lib/stores-combined";
import { formatBRL } from "@/lib/pix";
import { Eye } from "lucide-react";

const IMG_FALLBACK =
  "https://placehold.co/400x500/12141d/d4af37?text=Mimi+Mimos+25ml";

export default function RecentlyViewed() {
  const recentlyViewed = useStore((s) => s.recentlyViewed);
  const products = useStore((s) => s.products);
  const openQuickView = useUI((s) => s.openQuickView);

  // Remove o produto atual se já estiver no catálogo, mostra até 4 vistos recentemente
  const recent = recentlyViewed
    .map((id) => products.find((p) => p.id === id))
    .filter((p): p is NonNullable<typeof p> => Boolean(p))
    .slice(0, 4);

  if (recent.length === 0) return null;

  return (
    <section
      id="recentlyViewedSection"
      className="py-10 px-4 sm:px-8 max-w-7xl mx-auto border-t border-gold-500/10"
    >
      <div className="flex items-center gap-2 mb-5">
        <Eye className="text-gold-400" size={18} />
        <h3 className="font-serif-luxury text-xl font-bold text-white">
          Vistos Recentemente
        </h3>
        <span className="text-[10px] uppercase tracking-wider text-gold-300/60 border border-gold-500/20 px-2 py-0.5 rounded-full">
          Sua jornada olfativa
        </span>
      </div>

      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        {recent.map((p) => (
          <button
            key={p.id}
            onClick={() => openQuickView(p)}
            className="glass-panel rounded-xl p-3 border border-gold-500/10 hover:border-gold-400/40 transition-all text-left group"
          >
            <div className="relative w-full h-28 rounded-lg overflow-hidden mb-2 bg-obsidian-950">
              { }
              <img
                src={p.image}
                onError={(e) => {
                  (e.target as HTMLImageElement).src = IMG_FALLBACK;
                }}
                alt={p.name}
                className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
              />
              <span className="absolute top-1 left-1 text-[9px] uppercase tracking-wider bg-obsidian-950/80 text-gold-200 px-1.5 py-0.5 rounded-full">
                {p.code}
              </span>
            </div>
            <h4 className="text-[11px] font-bold text-white truncate">
              {p.name}
            </h4>
            <p className="text-[10px] text-gold-300 truncate">{p.inspiration}</p>
            <span className="text-xs font-serif-luxury font-bold text-gold-400 mt-1 block">
              {formatBRL(p.price)}
            </span>
          </button>
        ))}
      </div>
    </section>
  );
}
