"use client";

import { useState } from "react";
import { useStore, useUI } from "@/lib/stores-combined";
import { formatBRL } from "@/lib/pix";
import type { Perfume, ProductCategory, ProductGender } from "@/lib/perfumes";
import {
  DEFAULT_PRICE_BRAND,
  DEFAULT_PRICE_AFEER,
  DEFAULT_PRICE_DECANTE,
} from "@/lib/perfumes";
import { toast } from "sonner";
import {
  Store,
  Sliders,
  Trash2,
  Plus,
  Save,
  Phone,
  Eraser,
  Crown,
} from "lucide-react";

type Tab = "products" | "add" | "pix" | "leads";

export default function AdminPanel() {
  const open = useUI((s) => s.adminPanelOpen);
  const setOpen = useUI((s) => s.setAdminPanelOpen);
  const products = useStore((s) => s.products);
  const leads = useStore((s) => s.leads);
  const pixConfig = useStore((s) => s.pixConfig);
  const globalDefaultPrice = useStore((s) => s.globalDefaultPrice);

  const updateProductPrice = useStore((s) => s.updateProductPrice);
  const toggleStock = useStore((s) => s.toggleStock);
  const deleteProduct = useStore((s) => s.deleteProduct);
  const addProduct = useStore((s) => s.addProduct);
  const applyGlobalPrice = useStore((s) => s.applyGlobalPrice);
  const clearLeads = useStore((s) => s.clearLeads);
  const savePixConfig = useStore((s) => s.savePixConfig);

  const [tab, setTab] = useState<Tab>("products");
  const [globalPrice, setGlobalPrice] = useState(globalDefaultPrice.toFixed(2));

  // add product form
  const [form, setForm] = useState({
    code: "",
    name: "",
    inspiration: "",
    category: "BRAND" as ProductCategory,
    gender: "UNISSEX" as ProductGender,
    price: DEFAULT_PRICE_BRAND,
    image: "",
    tags: "",
    notesTopo: "",
    notesCoracao: "",
    notesFundo: "",
    description: "",
    family: "",
    intensity: "Eau de Parfum",
    fixation: "8 a 10h",
    rating: 5,
    reviewCount: 0,
    season: "",
    occasion: "",
  });

  // pix form
  const [pixForm, setPixForm] = useState(pixConfig);

  if (!open) return null;

  const tabs: { id: Tab; label: string }[] = [
    { id: "products", label: "Produtos & Preços" },
    { id: "add", label: "Incluir Novo Perfume" },
    { id: "pix", label: "Configuração Pix (OpenFinance)" },
    { id: "leads", label: `Leads WhatsApp (${leads.length})` },
  ];

  const handleAdd = (e: React.FormEvent) => {
    e.preventDefault();
    if (!form.code || !form.name || !form.image) {
      toast.error("Preencha código, nome e imagem.");
      return;
    }
    const priceDefault =
      form.category === "AFEER"
        ? DEFAULT_PRICE_AFEER
        : form.category === "DECANTE"
        ? DEFAULT_PRICE_DECANTE
        : DEFAULT_PRICE_BRAND;
    const newObj: Perfume = {
      id:
        form.category === "AFEER"
          ? "af-"
          : form.category === "DECANTE"
          ? "dec-"
          : "bc-" + Date.now(),
      code: form.code,
      name: form.name,
      inspiration: form.inspiration || form.name,
      category: form.category,
      gender: form.gender,
      price: Number(form.price) || priceDefault,
      inStock: true,
      image: form.image,
      tags: form.tags
        ? form.tags.split(",").map((t) => t.trim()).filter(Boolean)
        : [],
      notesTopo: form.notesTopo || "Notas refrescantes",
      notesCoracao: form.notesCoracao || "Acorde floral e especiarias",
      notesFundo: form.notesFundo || "Madeiras nobres e Âmbar",
      description: form.description || "Fragrância exclusiva da curadoria.",
      family: form.family || "Floral Amadeirado",
      intensity: form.intensity,
      fixation: form.fixation,
      rating: Number(form.rating) || 5,
      reviewCount: Number(form.reviewCount) || 0,
      season: form.season || "Dia-Noite / O ano todo",
      occasion: form.occasion || "Casual, Uso diário",
    };
    addProduct(newObj);
    setForm({
      ...form,
      code: "",
      name: "",
      inspiration: "",
      image: "",
      tags: "",
      notesTopo: "",
      notesCoracao: "",
      notesFundo: "",
      description: "",
      family: "",
      season: "",
      occasion: "",
    });
    setTab("products");
    toast.success("Novo perfume cadastrado com sucesso!");
  };

  const handleGlobalPrice = () => {
    const p = parseFloat(globalPrice);
    if (!p || p <= 0) {
      toast.error("Preço inválido.");
      return;
    }
    applyGlobalPrice(p);
    toast.success(`Preço global de ${formatBRL(p)} aplicado a todos!`);
  };

  const handleSavePix = (e: React.FormEvent) => {
    e.preventDefault();
    savePixConfig(pixForm);
    toast.success("Configurações Pix e WhatsApp salvas!");
  };

  return (
    <div className="fixed inset-0 z-[70] bg-obsidian-950 overflow-y-auto">
      <div className="max-w-6xl mx-auto p-4 sm:p-8 safe-top">
        {/* Admin Top Bar */}
        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center border-b border-gold-500/20 pb-4 mb-6 gap-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-gold-500/20 border border-gold-500/40 flex items-center justify-center text-gold-400">
              <Sliders size={20} />
            </div>
            <div>
              <h2 className="font-serif-luxury text-2xl font-bold text-white">
                Painel do Administrador — Mimi Mimos
              </h2>
              <p className="text-xs text-gray-400">
                Gerenciamento completo do catálogo, preços, estoque e Pix
              </p>
            </div>
          </div>

          <button
            onClick={() => setOpen(false)}
            className="btn-gold px-5 py-2 rounded-xl text-xs uppercase flex items-center gap-2"
          >
            <Store size={14} />
            <span>Voltar à Loja</span>
          </button>
        </div>

        {/* Tabs */}
        <div className="flex gap-2 border-b border-gold-500/10 mb-6 overflow-x-auto pb-2">
          {tabs.map((t) => (
            <button
              key={t.id}
              onClick={() => setTab(t.id)}
              className={`px-4 py-2 rounded-xl text-xs font-semibold whitespace-nowrap transition-all ${
                tab === t.id
                  ? "bg-gold-500 text-obsidian-950"
                  : "bg-obsidian-900 text-gray-300 border border-gold-500/20 hover:border-gold-500/50"
              }`}
            >
              {t.label}
            </button>
          ))}
        </div>

        {/* TAB 1: Products */}
        {tab === "products" && (
          <div className="space-y-6">
            <div className="glass-panel p-4 rounded-xl flex flex-col sm:flex-row justify-between items-center gap-4">
              <div>
                <h4 className="text-sm font-bold text-white">
                  Preço Padrão Global
                </h4>
                <p className="text-xs text-gray-400">
                  Alterar o valor de todos os perfumes simultaneamente.
                </p>
              </div>
              <div className="flex items-center gap-3">
                <span className="text-xs text-gold-400 font-bold">R$</span>
                <input
                  type="number"
                  step="0.01"
                  value={globalPrice}
                  onChange={(e) => setGlobalPrice(e.target.value)}
                  className="w-28 bg-obsidian-900 border border-gold-500/30 rounded-xl py-1.5 px-3 text-xs text-white"
                />
                <button
                  onClick={handleGlobalPrice}
                  className="btn-gold px-4 py-1.5 rounded-xl text-xs flex items-center gap-1.5"
                >
                  <Save size={12} /> Aplicar a Todos
                </button>
              </div>
            </div>

            <div className="glass-panel rounded-xl overflow-x-auto">
              <table className="w-full text-left text-xs text-gray-300 min-w-[720px]">
                <thead className="bg-obsidian-900 text-gold-300 uppercase tracking-wider text-[10px] border-b border-gold-500/20">
                  <tr>
                    <th className="p-3">Perfume / Código</th>
                    <th className="p-3">Inspiração</th>
                    <th className="p-3">Categoria</th>
                    <th className="p-3">Preço</th>
                    <th className="p-3">Estoque</th>
                    <th className="p-3 text-right">Ações</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-gold-500/10">
                  {products.map((p) => (
                    <tr key={p.id} className="hover:bg-obsidian-900/40">
                      <td className="p-3 font-bold text-white">
                        <div className="flex items-center gap-2">
                          { }
                          <img
                            src={p.image}
                            alt={p.name}
                            className="w-8 h-8 rounded object-cover"
                          />
                          <span>
                            {p.name} ({p.code})
                          </span>
                        </div>
                      </td>
                      <td className="p-3 text-gold-300">{p.inspiration}</td>
                      <td className="p-3 uppercase text-[10px] text-gray-400">
                        {p.category}
                      </td>
                      <td className="p-3">
                        <input
                          type="number"
                          step="0.01"
                          value={p.price}
                          onChange={(e) =>
                            updateProductPrice(p.id, parseFloat(e.target.value))
                          }
                          className="w-20 bg-obsidian-900 border border-gold-500/30 rounded py-1 px-2 text-xs text-gold-400 font-bold"
                        />
                      </td>
                      <td className="p-3">
                        <button
                          onClick={() => {
                            toggleStock(p.id);
                            toast.success(`Estoque de ${p.code} atualizado.`);
                          }}
                          className={`px-2.5 py-1 rounded-full text-[10px] font-bold border ${
                            p.inStock
                              ? "bg-emerald-500/20 text-emerald-400 border-emerald-500/30"
                              : "bg-red-500/20 text-red-400 border-red-500/30"
                          }`}
                        >
                          {p.inStock ? "Em Estoque" : "Esgotado"}
                        </button>
                      </td>
                      <td className="p-3 text-right">
                        <button
                          onClick={() => {
                            if (
                              confirm(
                                "Excluir este perfume do catálogo definitivamente?"
                              )
                            ) {
                              deleteProduct(p.id);
                              toast.success("Perfume removido.");
                            }
                          }}
                          className="text-red-400 hover:underline text-xs"
                          aria-label="Excluir"
                        >
                          <Trash2 size={14} />
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {/* TAB 2: Add */}
        {tab === "add" && (
          <div className="glass-panel p-6 rounded-2xl max-w-2xl mx-auto">
            <h3 className="font-serif-luxury text-2xl font-bold text-white mb-4 flex items-center gap-2">
              <Plus className="text-gold-400" size={20} />
              Adicionar Novo Brand Collection (25ml)
            </h3>
            <form onSubmit={handleAdd} className="space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-[11px] text-gray-400 mb-1">
                    Código Brand Collection
                  </label>
                  <input
                    type="text"
                    value={form.code}
                    onChange={(e) => setForm({ ...form, code: e.target.value })}
                    placeholder="Ex: #350"
                    required
                    className="w-full bg-obsidian-900 border border-gold-500/30 rounded-xl py-2 px-3 text-xs text-white"
                  />
                </div>
                <div>
                  <label className="block text-[11px] text-gray-400 mb-1">
                    Nome do Perfume
                  </label>
                  <input
                    type="text"
                    value={form.name}
                    onChange={(e) => setForm({ ...form, name: e.target.value })}
                    placeholder="Ex: Brand Collection #350"
                    required
                    className="w-full bg-obsidian-900 border border-gold-500/30 rounded-xl py-2 px-3 text-xs text-white"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-[11px] text-gray-400 mb-1">
                    Inspiração (marca original)
                  </label>
                  <input
                    type="text"
                    value={form.inspiration}
                    onChange={(e) =>
                      setForm({ ...form, inspiration: e.target.value })
                    }
                    placeholder="Ex: Good Girl (Carolina Herrera)"
                    className="w-full bg-obsidian-900 border border-gold-500/30 rounded-xl py-2 px-3 text-xs text-white"
                  />
                </div>
                <div>
                  <label className="block text-[11px] text-gray-400 mb-1">
                    Coleção
                  </label>
                  <select
                    value={form.category}
                    onChange={(e) => {
                      const cat = e.target.value as ProductCategory;
                      const defPrice =
                        cat === "AFEER"
                          ? DEFAULT_PRICE_AFEER
                          : cat === "DECANTE"
                          ? DEFAULT_PRICE_DECANTE
                          : DEFAULT_PRICE_BRAND;
                      setForm({
                        ...form,
                        category: cat,
                        price: defPrice,
                      });
                    }}
                    className="w-full bg-obsidian-900 border border-gold-500/30 rounded-xl py-2 px-3 text-xs text-white"
                  >
                    <option value="BRAND">💎 Brand Collection (25ml)</option>
                    <option value="AFEER">🌙 Miniatura Árabe Afeer</option>
                    <option value="DECANTE">🧪 Decante (5ml)</option>
                  </select>
                </div>
                <div>
                  <label className="block text-[11px] text-gray-400 mb-1">
                    Gênero
                  </label>
                  <select
                    value={form.gender}
                    onChange={(e) =>
                      setForm({
                        ...form,
                        gender: e.target.value as ProductGender,
                      })
                    }
                    className="w-full bg-obsidian-900 border border-gold-500/30 rounded-xl py-2 px-3 text-xs text-white"
                  >
                    <option value="FEMININO">Feminino</option>
                    <option value="MASCULINO">Masculino</option>
                    <option value="ARABE">Árabe</option>
                    <option value="UNISSEX">Unissex</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div>
                  <label className="block text-[11px] text-gray-400 mb-1">
                    Preço (R$)
                  </label>
                  <input
                    type="number"
                    step="0.01"
                    value={form.price}
                    onChange={(e) =>
                      setForm({ ...form, price: parseFloat(e.target.value) })
                    }
                    required
                    className="w-full bg-obsidian-900 border border-gold-500/30 rounded-xl py-2 px-3 text-xs text-white"
                  />
                </div>
                <div>
                  <label className="block text-[11px] text-gray-400 mb-1">
                    Família Olfativa
                  </label>
                  <input
                    type="text"
                    value={form.family}
                    onChange={(e) =>
                      setForm({ ...form, family: e.target.value })
                    }
                    placeholder="Ex: Floral Amadeirado"
                    className="w-full bg-obsidian-900 border border-gold-500/30 rounded-xl py-2 px-3 text-xs text-white"
                  />
                </div>
                <div>
                  <label className="block text-[11px] text-gray-400 mb-1">
                    Intensidade
                  </label>
                  <select
                    value={form.intensity}
                    onChange={(e) =>
                      setForm({ ...form, intensity: e.target.value })
                    }
                    className="w-full bg-obsidian-900 border border-gold-500/30 rounded-xl py-2 px-3 text-xs text-white"
                  >
                    <option value="Eau de Parfum">Eau de Parfum</option>
                    <option value="Eau de Toilette">Eau de Toilette</option>
                    <option value="Extrait de Parfum">Extrait de Parfum</option>
                    <option value="Eau de Parfum Intense">Eau de Parfum Intense</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-[11px] text-gray-400 mb-1">
                  URL da Imagem do Perfume{" "}
                  <span className="text-gray-500 normal-case">
                    (ex: /perfumes/nome.jpg ou https://…)
                  </span>
                </label>
                <input
                  type="text"
                  value={form.image}
                  onChange={(e) =>
                    setForm({ ...form, image: e.target.value })
                  }
                  placeholder="/perfumes/seu-perfume.jpg"
                  required
                  className="w-full bg-obsidian-900 border border-gold-500/30 rounded-xl py-2 px-3 text-xs text-white"
                />
              </div>

              <div>
                <label className="block text-[11px] text-gray-400 mb-1">
                  Descrição do perfume
                </label>
                <textarea
                  value={form.description}
                  onChange={(e) =>
                    setForm({ ...form, description: e.target.value })
                  }
                  placeholder="Descrição sensorial da fragrância..."
                  rows={2}
                  className="w-full bg-obsidian-900 border border-gold-500/30 rounded-xl py-2 px-3 text-xs text-white"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div>
                  <label className="block text-[10px] text-gold-300 mb-1">
                    Notas de Topo
                  </label>
                  <input
                    type="text"
                    value={form.notesTopo}
                    onChange={(e) =>
                      setForm({ ...form, notesTopo: e.target.value })
                    }
                    placeholder="Ex: Bergamota, Amêndoa"
                    className="w-full bg-obsidian-900 border border-gold-500/30 rounded-xl py-2 px-3 text-xs text-white"
                  />
                </div>
                <div>
                  <label className="block text-[10px] text-gold-300 mb-1">
                    Notas de Coração
                  </label>
                  <input
                    type="text"
                    value={form.notesCoracao}
                    onChange={(e) =>
                      setForm({ ...form, notesCoracao: e.target.value })
                    }
                    placeholder="Ex: Jasmim, Tuberosa"
                    className="w-full bg-obsidian-900 border border-gold-500/30 rounded-xl py-2 px-3 text-xs text-white"
                  />
                </div>
                <div>
                  <label className="block text-[10px] text-gold-300 mb-1">
                    Notas de Fundo
                  </label>
                  <input
                    type="text"
                    value={form.notesFundo}
                    onChange={(e) =>
                      setForm({ ...form, notesFundo: e.target.value })
                    }
                    placeholder="Ex: Baunilha, Fava Tonka"
                    className="w-full bg-obsidian-900 border border-gold-500/30 rounded-xl py-2 px-3 text-xs text-white"
                  />
                </div>
              </div>

              <div>
                <label className="block text-[11px] text-gray-400 mb-1">
                  Tags (separadas por vírgula)
                </label>
                <input
                  type="text"
                  value={form.tags}
                  onChange={(e) =>
                    setForm({ ...form, tags: e.target.value })
                  }
                  placeholder="Ex: Baunilha, Oud, Floral, Gourmand"
                  className="w-full bg-obsidian-900 border border-gold-500/30 rounded-xl py-2 px-3 text-xs text-white"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-[10px] text-gold-300 mb-1">
                    Estação / Clima
                  </label>
                  <input
                    type="text"
                    value={form.season}
                    onChange={(e) =>
                      setForm({ ...form, season: e.target.value })
                    }
                    placeholder="Ex: Noite / Outono-Inverno"
                    className="w-full bg-obsidian-900 border border-gold-500/30 rounded-xl py-2 px-3 text-xs text-white"
                  />
                </div>
                <div>
                  <label className="block text-[10px] text-gold-300 mb-1">
                    Ocasião
                  </label>
                  <input
                    type="text"
                    value={form.occasion}
                    onChange={(e) =>
                      setForm({ ...form, occasion: e.target.value })
                    }
                    placeholder="Ex: Festa, Eventos sociais"
                    className="w-full bg-obsidian-900 border border-gold-500/30 rounded-xl py-2 px-3 text-xs text-white"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-[10px] text-gold-300 mb-1">
                    Avaliação (0 a 5)
                  </label>
                  <input
                    type="number"
                    step="0.1"
                    min="0"
                    max="5"
                    value={form.rating}
                    onChange={(e) =>
                      setForm({ ...form, rating: parseFloat(e.target.value) })
                    }
                    className="w-full bg-obsidian-900 border border-gold-500/30 rounded-xl py-2 px-3 text-xs text-white"
                  />
                </div>
                <div>
                  <label className="block text-[10px] text-gold-300 mb-1">
                    Nº de Avaliações
                  </label>
                  <input
                    type="number"
                    min="0"
                    value={form.reviewCount}
                    onChange={(e) =>
                      setForm({ ...form, reviewCount: parseInt(e.target.value) })
                    }
                    className="w-full bg-obsidian-900 border border-gold-500/30 rounded-xl py-2 px-3 text-xs text-white"
                  />
                </div>
              </div>

              <button
                type="submit"
                className="w-full btn-gold py-3 rounded-xl text-xs uppercase font-bold tracking-wider flex items-center justify-center gap-2"
              >
                <Plus size={14} /> Cadastrar Perfume no Catálogo
              </button>
            </form>
          </div>
        )}

        {/* TAB 3: Pix */}
        {tab === "pix" && (
          <div className="glass-panel p-6 rounded-2xl max-w-xl mx-auto space-y-4">
            <h3 className="font-serif-luxury text-2xl font-bold text-white mb-2 flex items-center gap-2">
              <Crown className="text-gold-400" size={20} />
              Configurar Chave Pix & Recebedor
            </h3>
            <p className="text-xs text-gray-400">
              Esta chave será usada para gerar o QR Code dinâmico e código Pix
              Copia e Cola no checkout (OpenFinance).
            </p>

            <form onSubmit={handleSavePix} className="space-y-4">
              <div>
                <label className="block text-[11px] text-gray-400 mb-1">
                  Chave Pix (CNPJ, CPF, Email ou Celular)
                </label>
                <input
                  type="text"
                  value={pixForm.key}
                  onChange={(e) =>
                    setPixForm({ ...pixForm, key: e.target.value })
                  }
                  placeholder="Ex: mimimimos.vendas@pix.com.br"
                  required
                  className="w-full bg-obsidian-900 border border-gold-500/30 rounded-xl py-2.5 px-3 text-xs text-white"
                />
              </div>
              <div>
                <label className="block text-[11px] text-gray-400 mb-1">
                  Nome do Beneficiário / Razão Social
                </label>
                <input
                  type="text"
                  value={pixForm.name}
                  onChange={(e) =>
                    setPixForm({ ...pixForm, name: e.target.value })
                  }
                  placeholder="Ex: Mimi Mimos Perfumaria LTDA"
                  required
                  className="w-full bg-obsidian-900 border border-gold-500/30 rounded-xl py-2.5 px-3 text-xs text-white"
                />
              </div>
              <div>
                <label className="block text-[11px] text-gray-400 mb-1">
                  Cidade do Beneficiário
                </label>
                <input
                  type="text"
                  value={pixForm.city}
                  onChange={(e) =>
                    setPixForm({ ...pixForm, city: e.target.value })
                  }
                  placeholder="Ex: SAO PAULO"
                  required
                  className="w-full bg-obsidian-900 border border-gold-500/30 rounded-xl py-2.5 px-3 text-xs text-white"
                />
              </div>
              <div>
                <label className="block text-[11px] text-gray-400 mb-1">
                  Link do Grupo VIP no WhatsApp (Avise-me)
                </label>
                <input
                  type="url"
                  value={pixForm.whatsappGroup}
                  onChange={(e) =>
                    setPixForm({ ...pixForm, whatsappGroup: e.target.value })
                  }
                  placeholder="https://chat.whatsapp.com/..."
                  required
                  className="w-full bg-obsidian-900 border border-gold-500/30 rounded-xl py-2.5 px-3 text-xs text-white"
                />
              </div>

              <button
                type="submit"
                className="w-full btn-gold py-3 rounded-xl text-xs uppercase font-bold tracking-wider flex items-center justify-center gap-2"
              >
                <Save size={14} /> Salvar Configurações Pix
              </button>
            </form>
          </div>
        )}

        {/* TAB 4: Leads */}
        {tab === "leads" && (
          <div className="glass-panel p-6 rounded-2xl">
            <div className="flex justify-between items-center mb-4">
              <h3 className="font-serif-luxury text-2xl font-bold text-white flex items-center gap-2">
                <Phone className="text-gold-400" size={18} />
                Lista de Contatos “Avise-me” (WhatsApp)
              </h3>
              <button
                onClick={() => {
                  if (
                    confirm(
                      "Deseja limpar todo o histórico de cadastros do WhatsApp?"
                    )
                  ) {
                    clearLeads();
                    toast.success("Histórico de leads limpo.");
                  }
                }}
                className="text-xs text-red-400 hover:underline flex items-center gap-1"
              >
                <Eraser size={12} /> Limpar Histórico
              </button>
            </div>
            <p className="text-xs text-gray-400 mb-4">
              Clientes que solicitaram aviso para produtos esgotados no estoque.
            </p>

            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs text-gray-300 min-w-[640px]">
                <thead className="bg-obsidian-900 text-gold-300 uppercase tracking-wider text-[10px]">
                  <tr>
                    <th className="p-3">Data</th>
                    <th className="p-3">Nome</th>
                    <th className="p-3">Telefone / WhatsApp</th>
                    <th className="p-3">Perfume Desejado</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-gold-500/10">
                  {leads.length === 0 ? (
                    <tr>
                      <td
                        colSpan={4}
                        className="p-4 text-center text-gray-500"
                      >
                        Nenhum lead capturado até o momento.
                      </td>
                    </tr>
                  ) : (
                    leads.map((l, i) => (
                      <tr key={i} className="hover:bg-obsidian-900/40">
                        <td className="p-3 text-gray-400">{l.date}</td>
                        <td className="p-3 font-bold text-white">{l.name}</td>
                        <td className="p-3 text-emerald-400 font-bold">
                          {l.phone}
                        </td>
                        <td className="p-3 text-gold-300">{l.product}</td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
