"use client";

import { create } from "zustand";
import { persist, createJSONStorage } from "zustand/middleware";
import {
  INITIAL_PRODUCTS,
  DEFAULT_PRICE_BRAND,
  DEFAULT_PRICE_AFEER,
  DEFAULT_PRICE_DECANTE,
  type Perfume,
  type ProductCategory,
} from "./perfumes";

export interface PixConfig {
  key: string;
  name: string;
  city: string;
  whatsappGroup: string;
}

export interface Lead {
  date: string;
  name: string;
  phone: string;
  product: string;
}

export interface CartItem extends Perfume {
  qty: number;
}

interface StoreState {
  products: Perfume[];
  cart: CartItem[];
  leads: Lead[];
  favorites: string[];
  recentlyViewed: string[];
  globalDefaultPrice: number;
  pixConfig: PixConfig;
  isAdmin: boolean;
  // cart actions
  addToCart: (product: Perfume) => void;
  changeQty: (id: string, delta: number) => void;
  removeFromCart: (id: string) => void;
  clearCart: () => void;
  cartCount: () => number;
  cartSubtotal: () => number;
  cartDecanteCount: () => number;
  cartHasDecantePromo: () => boolean;
  // favorites
  toggleFavorite: (id: string) => void;
  isFavorite: (id: string) => boolean;
  // recently viewed
  pushRecentlyViewed: (id: string) => void;
  // product/admin actions
  updateProductPrice: (id: string, price: number) => void;
  toggleStock: (id: string) => void;
  deleteProduct: (id: string) => void;
  addProduct: (p: Perfume) => void;
  applyGlobalPrice: (price: number) => void;
  // leads
  addLead: (lead: Lead) => void;
  clearLeads: () => void;
  // pix config
  savePixConfig: (config: PixConfig) => void;
  // admin
  setAdmin: (v: boolean) => void;
}

/** Normaliza um perfume garantindo todos os campos (migração de schema antigo). */
function normalizePerfume(p: Partial<Perfume> & { id: string }): Perfume {
  const ref =
    INITIAL_PRODUCTS.find((init) => init.id === p.id) || ({} as Perfume);
  // Detecta schema antigo (category era "feminino"|"masculino"|"arabe"|"unissex")
  const oldCat = p.category as string | undefined;
  const isNewSchema =
    oldCat === "BRAND" || oldCat === "AFEER" || oldCat === "DECANTE";
  const category: ProductCategory = isNewSchema
    ? (oldCat as ProductCategory)
    : ref.category ?? "BRAND";

  // Mapeia campos antigos para novos se necessário
  const gender =
    p.gender ??
    (oldCat === "feminino"
      ? "FEMININO"
      : oldCat === "masculino"
      ? "MASCULINO"
      : oldCat === "arabe"
      ? "ARABE"
      : "UNISSEX") ??
    ref.gender ??
    "UNISSEX";
  const tags = p.tags ?? ref.tags ?? [];
  const priceDefault =
    category === "AFEER"
      ? DEFAULT_PRICE_AFEER
      : category === "DECANTE"
      ? DEFAULT_PRICE_DECANTE
      : DEFAULT_PRICE_BRAND;

  return {
    id: p.id,
    code: p.code ?? ref.code ?? "",
    name: p.name ?? ref.name ?? "",
    inspiration: p.inspiration ?? ref.inspiration ?? "",
    category,
    gender,
    price: typeof p.price === "number" ? p.price : ref.price ?? priceDefault,
    inStock: p.inStock ?? ref.inStock ?? true,
    image: p.image ?? ref.image ?? "",
    tags,
    notesTopo: p.notesTopo ?? ref.notesTopo ?? "",
    notesCoracao: p.notesCoracao ?? ref.notesCoracao ?? "",
    notesFundo: p.notesFundo ?? ref.notesFundo ?? "",
    description: p.description ?? ref.description ?? "",
    family: p.family ?? ref.family ?? "",
    intensity: p.intensity ?? ref.intensity ?? "Eau de Parfum",
    fixation: p.fixation ?? ref.fixation ?? "8 a 10h",
    rating: typeof p.rating === "number" ? p.rating : ref.rating ?? 5,
    reviewCount:
      typeof p.reviewCount === "number" ? p.reviewCount : ref.reviewCount ?? 0,
    season: p.season ?? ref.season ?? "",
    occasion: p.occasion ?? ref.occasion ?? "",
  };
}

/** Merge persistido + estado atual, normalizando produtos para o schema novo. */
function mergePersisted(
  persisted: unknown,
  currentState: StoreState
): StoreState {
  if (!persisted || typeof persisted !== "object") return currentState;
  const p = persisted as Partial<StoreState>;
  const mergedProducts = Array.isArray(p.products)
    ? p.products.map(normalizePerfume)
    : currentState.products;
  return {
    ...currentState,
    ...p,
    products: mergedProducts,
    favorites: Array.isArray(p.favorites) ? p.favorites : [],
    recentlyViewed: Array.isArray(p.recentlyViewed) ? p.recentlyViewed : [],
    leads: Array.isArray(p.leads) ? p.leads : [],
  };
}

export const useStore = create<StoreState>()(
  persist(
    (set, get) => ({
      products: INITIAL_PRODUCTS,
      cart: [],
      leads: [],
      favorites: [],
      recentlyViewed: [],
      globalDefaultPrice: DEFAULT_PRICE_BRAND,
      pixConfig: {
        key: "fabiana@araujo.eu.org",
        name: "FABIANA ARAUJO",
        city: "SAO PAULO",
        whatsappGroup: "https://wa.me/5511958546078",
      },
      isAdmin: false,

      addToCart: (product) =>
        set((state) => {
          const existing = state.cart.find((i) => i.id === product.id);
          if (existing) {
            return {
              cart: state.cart.map((i) =>
                i.id === product.id ? { ...i, qty: i.qty + 1 } : i
              ),
            };
          }
          return { cart: [...state.cart, { ...product, qty: 1 }] };
        }),
      changeQty: (id, delta) =>
        set((state) => {
          const item = state.cart.find((i) => i.id === id);
          if (!item) return {};
          const newQty = item.qty + delta;
          if (newQty <= 0) {
            return { cart: state.cart.filter((i) => i.id !== id) };
          }
          return {
            cart: state.cart.map((i) => (i.id === id ? { ...i, qty: newQty } : i)),
          };
        }),
      removeFromCart: (id) =>
        set((state) => ({ cart: state.cart.filter((i) => i.id !== id) })),
      clearCart: () => set({ cart: [] }),
      cartCount: () => get().cart.reduce((acc, i) => acc + i.qty, 0),
      cartSubtotal: () => {
        // Decante promo: 3 decantes por R$ 100,00
        let total = 0;
        let decanteCount = 0;
        get().cart.forEach((item) => {
          if (item.category === "DECANTE") {
            decanteCount += item.qty;
          } else {
            total += item.price * item.qty;
          }
        });
        if (decanteCount > 0) {
          const combos = Math.floor(decanteCount / 3);
          const remainder = decanteCount % 3;
          total += combos * 100.0 + remainder * DEFAULT_PRICE_DECANTE;
        }
        return total;
      },
      cartDecanteCount: () =>
        get().cart
          .filter((i) => i.category === "DECANTE")
          .reduce((acc, i) => acc + i.qty, 0),
      cartHasDecantePromo: () => {
        const count = get()
          .cart.filter((i) => i.category === "DECANTE")
          .reduce((acc, i) => acc + i.qty, 0);
        return count >= 3;
      },

      toggleFavorite: (id) =>
        set((state) => ({
          favorites: state.favorites.includes(id)
            ? state.favorites.filter((f) => f !== id)
            : [...state.favorites, id],
        })),
      isFavorite: (id) => get().favorites.includes(id),

      pushRecentlyViewed: (id) =>
        set((state) => ({
          recentlyViewed: [
            id,
            ...state.recentlyViewed.filter((r) => r !== id),
          ].slice(0, 8),
        })),

      updateProductPrice: (id, price) =>
        set((state) => ({
          products: state.products.map((p) =>
            p.id === id ? { ...p, price } : p
          ),
        })),
      toggleStock: (id) =>
        set((state) => ({
          products: state.products.map((p) =>
            p.id === id ? { ...p, inStock: !p.inStock } : p
          ),
        })),
      deleteProduct: (id) =>
        set((state) => ({ products: state.products.filter((p) => p.id !== id) })),
      addProduct: (p) =>
        set((state) => ({ products: [p, ...state.products] })),
      applyGlobalPrice: (price) =>
        set((state) => ({
          globalDefaultPrice: price,
          products: state.products.map((p) => ({ ...p, price })),
        })),

      addLead: (lead) =>
        set((state) => ({ leads: [...state.leads, lead] })),
      clearLeads: () => set({ leads: [] }),

      savePixConfig: (config) => set({ pixConfig: config }),
      setAdmin: (v) => set({ isAdmin: v }),
    }),
    {
      name: "mimi-mimos-storage",
      storage: createJSONStorage(() => localStorage),
      merge: (persisted, current) =>
        mergePersisted(persisted, current as StoreState),
      partialize: (state) => ({
        products: state.products,
        leads: state.leads,
        favorites: state.favorites,
        recentlyViewed: state.recentlyViewed,
        globalDefaultPrice: state.globalDefaultPrice,
        pixConfig: state.pixConfig,
      }),
    }
  )
);
