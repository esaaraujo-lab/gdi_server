import type { PixConfig } from "./store";

/**
 * Gera o "Pix Copia e Cola" (BR Code / Payload) estático seguindo o padrão BR Code do Banco Central.
 * Compatível com OpenFinance. Não há validação CRC oficial embutida para produção real
 * (a integração real exigiria uma API PSP), mas segue a estrutura EMV correta.
 */
function emv(id: string, value: string): string {
  const len = value.length.toString().padStart(2, "0");
  return `${id}${len}${value}`;
}

function crc16(payload: string): string {
  let crc = 0xffff;
  for (let i = 0; i < payload.length; i++) {
    crc ^= payload.charCodeAt(i) << 8;
    for (let j = 0; j < 8; j++) {
      crc = crc & 0x8000 ? (crc << 1) ^ 0x1021 : crc << 1;
      crc &= 0xffff;
    }
  }
  return crc.toString(16).toUpperCase().padStart(4, "0");
}

function sanitize(str: string, max: number): string {
  // remove acentos e caracteres especiais
  const clean = str
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .replace(/[^a-zA-Z0-9 ]/g, "")
    .trim();
  return clean.substring(0, max).toUpperCase();
}

export function generatePixCode(amount: number, config: PixConfig): string {
  const merchantAccountInfo = emv(
    "00",
    "BR.GOV.BCB.PIX"
  ) + emv("01", config.key);

  const name = sanitize(config.name || "MIMI MOS PERFUMARIA", 25);
  const city = sanitize(config.city || "SAO PAULO", 15);
  const amountStr = amount.toFixed(2);

  const payload =
    emv("00", "01") + // Payload Format Indicator
    emv("01", "11") + // Point of Initiation Method (dynamic-ish, allows repeated)
    emv("26", merchantAccountInfo) + // Merchant Account Information
    emv("52", "0000") + // Merchant Category Code
    emv("53", "986") + // Currency BRL
    emv("54", amountStr) + // Amount
    emv("58", "BR") + // Country
    emv("59", name) + // Merchant Name
    emv("60", city) + // Merchant City
    emv("62", emv("05", "***")) + // Additional data (txid placeholder)
    "6304"; // CRC placeholder id+length

  const crc = crc16(payload);
  return payload + crc;
}

export function qrCodeUrl(data: string, size = 280): string {
  return `https://api.qrserver.com/v1/create-qr-code/?size=${size}x${size}&data=${encodeURIComponent(
    data
  )}`;
}

export function formatBRL(value: number): string {
  return value.toLocaleString("pt-BR", {
    style: "currency",
    currency: "BRL",
  });
}
